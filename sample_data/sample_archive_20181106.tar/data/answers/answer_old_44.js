const hello = (name = 'John Doe') => console.log("Hello, " + name + ".")

hello("George Washington");
hello();


//////////////////////////////////////////////////////////////////////////



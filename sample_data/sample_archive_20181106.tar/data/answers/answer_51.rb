az = [*('a'..'z')]
az.sort! {|x,y| x<=>y} # Note, this specifies when x and y are swapped.
                       # If x > y, x<=>y = 1, so x and y are swapped, with the
                       # resulting sorting of y, x.
puts az[0] # 'a'
az.sort! {|x,y| y<=>x} # Ditto.
puts az[0] # 'z'
az.sort!
puts az[0] # 'a'
puts 'a' <=> 'b' # -1
32.upto(126).each {|n| print "#{n.chr} "}
puts ''
puts "#{33.chr}<=>#{124.chr}"
puts 33.chr<=>124.chr # -1
# first

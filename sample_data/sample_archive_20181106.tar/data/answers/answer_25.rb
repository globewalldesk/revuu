dog_breeds = {Lassie: 'Collie', Rex: 'German Shepherd', Bobo: 'Poodle'}
dog_breeds.default = 'mutt'
['Lassie', 'Fifi', 'Bobo', 'Rex', 'Happy'].each do |name|
  puts "#{name}: #{dog_breeds[name.to_sym]}"
end

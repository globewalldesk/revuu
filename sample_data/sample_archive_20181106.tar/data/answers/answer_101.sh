echo Listing opt:
ls /opt
echo Creating foo...
sudo touch /opt/foo
echo Listing opt with foo:
ls -l /opt
echo Removing foo...
sudo rm /opt/foo
echo Listing opt for the last time...
ls -l /opt

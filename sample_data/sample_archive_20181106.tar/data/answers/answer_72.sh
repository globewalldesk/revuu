echo ''
ls -lrt ..
echo ''
ls -lart ..
echo ''
ls -larth ..
echo ''
ls -larth ../*.json
echo ''
ls -larthR ../../*/*.rb

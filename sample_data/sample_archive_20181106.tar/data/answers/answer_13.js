var num = 10;

num = 1;
num2 = (num++ * 10 + 1);
console.log(num2);

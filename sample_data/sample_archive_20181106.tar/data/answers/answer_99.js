class Book {
  constructor(first, last) {
    this._first = first;
    this._last = last;
  }
  set first(first) {
    this._first = first;
  }
  set last(last) {
    this._last = last;
  }
  get fullname() {
    return `${this._first} ${this._last}`;
  }
}
const epic = new Book('Jack', 'London');
console.log(epic.fullname);
epic.first = 'Leo';
epic.last = 'Tolstoy';
console.log(epic.fullname);

class Book {
  constructor(fullname) {
    this.fullname = fullname;
  }
}
const epic = new Book('Jack London');
console.log(epic.fullname);
epic.fullname = 'Leo Tolstoy';
console.log(epic.fullname);

class Volume {
  constructor(firstname, lastname) {
    this._firstname = firstname;
    this._lastname = lastname;
  }
  set firstname(name) {
    this._firstname = name;
  }
  set lastname(name) {
    this._lastname = name;
  }
  get fullname() {
    return (this._firstname + ' ' + this._lastname);
  }
}

const book = new Volume('Fyodor', 'Dostoyevsky');
console.log(book.fullname);
book.firstname = 'Ayn';
book.lastname = 'Rand';
console.log(book.fullname);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


class Book {
  constructor(firstname, lastname) {
    this._firstname = firstname;
    this._lastname = lastname;
  }
  get fullname() {
    return `${this._firstname} ${this._lastname}`;
  }
  set firstname(name) {
    this._firstname = name;
  }
  set lastname(name) {
    this._lastname = name;
  }
}
const epic = new Book('Jack', 'London');
console.log(epic.fullname);   // Change this to epic.writer.
epic.firstname = 'Leo';  // Change this too.
epic.lastname = 'Tolstoy';
console.log(epic.fullname);   // Change this too.



console.log(' ')
//////////////////////////////////////////////////////////////////////////



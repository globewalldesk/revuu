ps aux | grep 'ruby'

print "Hello world!";


print("\n")
#####################################


print("Hello, world!")



print("\n")
#####################################



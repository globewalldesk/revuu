echo "hello, world" > foo.txt
cat foo.txt > bar.txt
echo here is foo
cat foo.txt
echo here is bar
cat bar.txt
ls -lah *.txt
qrm foo.txt bar.txt
ls -lah *.txt



echo '<--spacer-->'
#####################################



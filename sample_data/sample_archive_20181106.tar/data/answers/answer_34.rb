size = File.stat("../../revuu.rb").size
puts "#{size} bytes"
puts "#{(size/1024.0).round} KB"
puts "#{(size/1024.0)} KB"
puts "#{(size/1024.0).round(2)} KB"

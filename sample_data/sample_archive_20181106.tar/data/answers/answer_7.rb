cube = Proc.new {|x| x**3}
p cube.call(3)
lquad = lambda {|x| x**4}
p lquad.call(7)
lsix = -> (x){x**6}
p lsix.call(13)

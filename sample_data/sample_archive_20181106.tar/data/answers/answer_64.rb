p Dir["*"]

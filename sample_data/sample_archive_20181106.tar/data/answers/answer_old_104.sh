pwd
cd ..
pwd
cd ..
pwd
cd ..
pwd
cd -



echo '<--spacer-->'
#####################################



ps aux | grep ruby



echo '<--spacer-->'
#####################################



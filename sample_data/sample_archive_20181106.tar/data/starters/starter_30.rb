activities = Hash.new('fun')
puts activities[:fred]

// Rewrite this Ruby in JavaScript.

def count_args(*args)
  puts "You passed #{args.length} to this function."
end

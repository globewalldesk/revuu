friends = ['Jack', 'Jill', 'Sam']

def yo(???, <??? three variables>)
  [???].each { |friend| puts "???, #{friend}!" }
end

# Call yo

arr = ['a', 'b', 'c', 'd']


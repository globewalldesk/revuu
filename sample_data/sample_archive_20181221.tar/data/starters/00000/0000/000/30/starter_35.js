let i = 'i global scope';
var j = 'j global scope'

function checkScope() {
"use strict";
  if (true) {
    console.log("i in block is: ", i);
  }
  console.log("i in function is: ", i);
}
checkScope();

console.log("i out of function is: ", i);
console.log("j out of function is: ", j);

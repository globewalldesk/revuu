require 'sinatra'
require './lib/movie'
require './lib/movie_store'
enable :sessions

store = MovieStore.new('movies.yml')

get('/movies') do
  @movies = store.all
  erb :index
end

get('/movies/new') do |*user_message|
  @user_message = session[:secret] if session[:secret]
  session[:secret] = "" # clear message after being used
  erb :new
end

post('/movies/create') do
  @movie = Movie.new
  user_message = "<p style='color:red'><i>#{@movie.title}</i> saved.</p>"
  session[:secret] = user_message
  store.save(@movie)
  redirect '/movies/new'
end

get('/movies/:id') do
  id = params['id'].to_i
  @movie = store.find(id)
  erb :show
end

require 'yaml/store'

class MovieStore

  def initialize(file_name)
    @store = YAML::Store.new(file_name)
  end

  def all
    @store.transaction do
      @store.roots.map { |id| @store[id] }
    end # the mapped array is returned by the block and thus by .transaction
  end

  # saves a new movie to the YAML store
  def save(movie)
    @store.transaction do
      unless (movie.id) # unless there's an ID for this particular saved movie
        highest_id = @store.roots.max || 0
        movie.id = highest_id + 1
      end
      @store[movie.id] = movie
    end
  end

  def find(id)
    @store.transaction do
      @store[id]
    end
  end

end

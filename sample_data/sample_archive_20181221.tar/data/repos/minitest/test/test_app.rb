require 'minitest/autorun'
require './lib/app'
include DatePrettifier

class AppTest < Minitest::Test
  def test_prettify_timestamp
    assert_equal("2 weeks from now", prettify_timestamp("2018-12-24T21:17:50-05:00",
      "2018-12-07T21:17:50-05:00"))
    assert_instance_of(String,prettify_timestamp("2018-12-24T21:17:50-05:00"))
    assert_kind_of(String,prettify_timestamp("2018-12-24T21:17:50-05:00"))
    assert_raises("TypeError") {prettify_timestamp(123)}
  end
end

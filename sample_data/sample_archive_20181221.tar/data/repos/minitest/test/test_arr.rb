require 'minitest/autorun'
require './lib/arr'
include ArrayStuff

class ArrTest < Minitest::Test
  def setup
    @arr = arr_thang
  end

  def test_arr_thang
    [0,1,5,10,11].each do |n|
      case n
      when 0,11
        refute_includes(@arr,n)
      when 1,5,10
        assert_includes(@arr,n)
      end
    end
  end
end

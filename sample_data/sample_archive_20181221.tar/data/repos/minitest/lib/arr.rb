module ArrayStuff
  def arr_thang
    Array.new(10) {|x| x+1}
  end
end

console.log(timestamp);

for(var i = 1; true; i++) {

  if (Math.ceil(Math.random()*10) == 0) {
    console.log("Holy crap! I saw a zero after this many tries: " + i);
    break;
  }
  if (i%1000000000 == 0)
    console.log();
}

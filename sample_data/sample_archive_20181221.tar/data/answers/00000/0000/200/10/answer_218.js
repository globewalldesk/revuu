const hallo = function() {
  console.log("Hello!");
}

const yo = hallo;
yo();
console.log(yo.name);

hallo.info = "Moar info!";
yo.info = "something else";
console.log(yo.info);
console.log(hallo.info);

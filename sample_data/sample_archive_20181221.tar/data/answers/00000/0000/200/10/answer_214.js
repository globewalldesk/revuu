const spot = [73, 32, 112, 111, 117, 114, 101, 100, 32, 115, 112, 111, 116, 32,
              114, 101, 109, 111, 118, 101, 114, 32, 111, 110, 32, 109, 121,
              32, 100, 111, 103, 46, 46, 46, 110, 111, 119, 32, 104, 101, 39,
              115, 32, 103, 111, 110, 101, 46];
// What's that in a string?
const message = spot.map((x) => String.fromCharCode(x)).join('');
console.log(message);
console.log(String.fromCharCode(...spot));

const hw = "Hello world!";
// What's the corresponding character code array?
const hwArr = hw.split('').map((c) => c.charCodeAt(0));
console.log(`[${hwArr.join(', ')}]`)
console.log(hwArr.map((x) => String.fromCharCode(x)).join(''));

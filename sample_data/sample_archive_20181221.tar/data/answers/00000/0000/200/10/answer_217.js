for(let i=1; i<=2; i = Math.round((0.1 + i)*1e12) / 1e12) {
  console.log(i);
}

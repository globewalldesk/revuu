const buff = "Buffalo buffalo Buffalo buffalo buffalo buffalo Buffalo buffalo.";
console.log(buff.indexOf("buffalo"));
console.log(buff.lastIndexOf("buffalo"));
console.log(buff.indexOf("buffalo", 10));

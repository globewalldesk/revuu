var obj = {foo: "bar"};
console.log(obj);
for(let n=1; n<=2; n = Math.round((0.1 + n) * 1e12) / 1e12) {
  console.log(n.toPrecision(2));
}



console.log(' ')
//////////////////////////////////////////////////////////////////////////



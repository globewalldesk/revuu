#include <stdio.h>

#define IN  1
#define OUT 0

int main() {
    // initialize array of word lengths
    int ndigit[21];
    for(int i = 0; i < 21; i++)
        ndigit[i] = 0;
    int wlength = 0;
    int state = OUT;
    char c;

    // iterate over user input
    while ((c = getchar()) != EOF) {
        // split into words
        if(c == ' ' || c == '\n' || c == '\t') {
            if(state == IN) {
                // increment array[length] for a word (when it's finished)
                ++ndigit[wlength];
                wlength = 0;
            }
            state = OUT;
        } else if(state == OUT) {
            // increment word length
            ++wlength;
            state = IN;
        } else {        // I.e., state == IN, so we're in a word, so increment.
            ++wlength;
        }
    }
    if( !(c == ' ' || c == '\n' || c == '\t') )
        ++ndigit[wlength];
    // print results
    printf("\n");
    for(int i = 1; i <= 20; ++i) {
        printf("%2d: ", i);
        for(int j = 0; j < ndigit[i]; ++j) {
            printf("x");
        }
        printf("\n");
    }
}

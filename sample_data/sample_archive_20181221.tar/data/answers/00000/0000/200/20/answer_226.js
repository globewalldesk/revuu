const n = -5;
console.log(Math.abs(n));

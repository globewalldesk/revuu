const now = new Date();
console.log(now); // Timestamp, sort of human-readable.
console.log(now.toDateString());
console.log(now.getTime());



console.log(' ')
//////////////////////////////////////////////////////////////////////////


const date = new Date();
console.log(date); // Timestamp, sort of readable; in UTC.
console.log(date.toDateString());
console.log(date.getTime());



console.log(' ')
//////////////////////////////////////////////////////////////////////////



const arr = ['paul', 'DuPaul', 'Paul', 'epaulette', 'Pauline', 'paul'];

console.log(arr.filter((w)=> w.match(/^paul$/i) ));

arr = [
  "    So much whitespace         ",
  " \ndon't know if I can\t\t",
  "               handle it.\n\n\t\t"
]

function getRidOfWhitespace(ary) {
  ary.forEach((s) =>
    console.log(s.trim()) // Do something!
  );
}

getRidOfWhitespace(arr);

const now = new Date();
console.log(now); // Timestamp
console.log(now.toDateString());
console.log(now.getTime());

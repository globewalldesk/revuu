const a = "Hello world"; // 4; d
const b = "pflug";       // 1; u
// Character at index:
console.log(a.charAt(4)); // o
console.log(b.charAt(1)); // f
// How do you return the given character?
console.log(a.charAt(10));
console.log(b.charAt(3));
// Shorter way to do the latter:
console.log(a[10]);
console.log(b[3]);

const num = 4.78547233174091;
console.log(num.toFixed(2));
console.log(Math.round(num));



console.log(' ')
//////////////////////////////////////////////////////////////////////////


const num = 4.78547233174091;
console.log(num.toFixed(2));
console.log(Math.round(num));



console.log(' ')
//////////////////////////////////////////////////////////////////////////


const num = 4.78547233174091;
console.log(num.toFixed(2));
console.log(Math.round(num));



console.log(' ')
//////////////////////////////////////////////////////////////////////////



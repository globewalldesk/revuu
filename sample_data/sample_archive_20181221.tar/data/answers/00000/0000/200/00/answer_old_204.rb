system ("psql tysql")


puts ''
#####################################



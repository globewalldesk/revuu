names = [
  { firstname: 'John', lastname: 'Doe' },
  { firstname: 'Jane', lastname: 'Roe' },
  { firstname: 'Jack', lastname: 'Sprat' },
  { firstname: 'Holly', lastname: 'Golightly' },
  { firstname: 'Santa', lastname: 'Claus' }
]
def print_arr_of_h(ah)
  ah.each {|h| printf("%-10s %-10s\n", h[:firstname], h[:lastname]) }
end

names.sort! do |x,y|
  x[:firstname] <=> y[:firstname]
end
print_arr_of_h names
puts

names.sort! do |x,y|
  x[:lastname] <=> y[:lastname]
end
print_arr_of_h names
puts

names = names.sort_by {|x| x[:firstname]}
print_arr_of_h names
puts

names = names.sort_by {|x| x[:lastname]}
print_arr_of_h names

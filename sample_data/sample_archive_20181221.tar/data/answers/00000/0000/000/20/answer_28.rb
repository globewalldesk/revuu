friends = ['Jack', 'Jill', 'Sam']

def yo(greet, p1, p2, p3)
  [p1,p2,p3].each { |friend| puts "#{greet}, #{friend}!" }
end

yo('Yo', *friends)

arr = ['a', 'b', 'c', 'd']
first, *the_rest = arr
puts "I really like #{first}, but as to #{the_rest.join(", ")}...they're OK."

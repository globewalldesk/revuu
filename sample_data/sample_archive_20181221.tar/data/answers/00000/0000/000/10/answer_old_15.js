['99', '2.3', '23a', 'xyz'].forEach(function(x) {
  const addition = isNaN(x) ? 'is not' : 'is';
  console.log(`${x} ${addition} numeric.`);
});

[99, 2.3, '2.3a', 'xyz'].forEach(function(x) {
  const intg = Number.isInteger(x) ? 'is' : 'is not';
  console.log(`${x} ${intg} an integer.`);
});



console.log(' ')
//////////////////////////////////////////////////////////////////////////


['99', '2.3', '23a', 'xyz'].forEach( function(x) {
  is_numic = isNaN(x) ? 'is not' : 'is';
  console.log(`${x} ${is_numic} numeric.`);
});

// Reports on the "integer" status of each element.
function IntTester(arr) {
  arr.forEach( function(x) {
    is_int = Number.isInteger(x) ? 'is' : `is a ${typeof x}, not`;
    console.log(`${JSON.stringify(x)} ${is_int} an integer.`);
  });
}

IntTester(['99', '23a', 'xyz']);

IntTester([99, 2.3, '2.3a', 'xyz']);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


['99', '2.3', '2.3a', 'xyz'].forEach((s) =>
  console.log(`${s} ${isNaN(s) ? 'is not' : 'is'} numeric.`)
);

console.log();

['99', '2.3', '2.3a', 'xyz'].forEach((s) =>
  console.log(`'${s}' ${Number.isInteger(s) ? 'is' : 'is not'} an integer.`)
);

console.log();

[99, 2.3, '2.3a', 'xyz'].forEach((s) =>
  console.log(`${s} ${Number.isInteger(s) ? 'is' : 'is not'} an integer.`)
);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


arr = ['99', '23a', 'xyz']
arr.forEach((s) => console.log(`'${s}' ${isNaN(s) ? 'is not' : 'is'} numeric.`));


console.log(' ')
//////////////////////////////////////////////////////////////////////////


const arr = ['99', '23a', 'xyz'];
arr.forEach(s => console.log(s + (isNaN(s) ? " is not" : " is") + " numeric." ));


console.log(' ')
//////////////////////////////////////////////////////////////////////////


var arr = ['99', '23a', 'xyz'];

arr.forEach(x => 
  console.log(x + (isNaN(x) ? " is not " : " is ") + "numeric.") );


//////////////////////////////////////////////////////////////////////////


var ans = ['99', '23a', 'xyz'];

ans.forEach(x =>
  console.log("x " + (isNaN(x) ? 'is not' : 'is') + " numeric.") );



//////////////////////////////////////////////////////////////////////////



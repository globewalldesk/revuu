console.log(`Band-Aid\u00AE 98.6\u00B0F`);
console.log(`Band-Aid\xAE 98.6\xB0F`);
// NOTE! \u takes four digits, but is in hex, not decimal!
// \x also is in hex, but takes only two digits.

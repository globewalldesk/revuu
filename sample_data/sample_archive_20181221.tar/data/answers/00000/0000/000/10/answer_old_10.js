const johnDoe = {
  firstName: "John",
  lastName: "Doe",
  greet() {console.log(`Hi, I'm ${this.firstName} ${this.lastName}.`)}
};
johnDoe.greet();



console.log(' ')
//////////////////////////////////////////////////////////////////////////


let johnDoe = {};
johnDoe.firstName = 'John';
johnDoe.lastName = 'Doe';
johnDoe.greet = function() {
  console.log("Hi, I'm " + this.firstName + " " + this.lastName + ".")
}
johnDoe.greet();


console.log(' ')
//////////////////////////////////////////////////////////////////////////


var johnDoe = {};
johnDoe.firstName = 'John';
johnDoe.lastName = 'Doe';
johnDoe.greet = function() {
  console.log("Hi, I'm " + this.firstName + " " + this.lastName + ".");
}

johnDoe.greet();



//////////////////////////////////////////////////////////////////////////


var johnDoe = {};
johnDoe.firstName = 'John';
johnDoe.lastName = 'Doe';
johnDoe.greet = function() {
  console.log("Hi, I'm " + this.firstName + " " + this.lastName + "!");
}
johnDoe.greet();



//////////////////////////////////////////////////////////////////////////



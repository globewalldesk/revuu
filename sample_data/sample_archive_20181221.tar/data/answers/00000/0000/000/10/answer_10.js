const johnDoe = {
  firstName: "John",
  lastName: "Doe",
  greet() {
    console.log("Hi, I'm " + this.firstName + " " + this.lastName + ".")
  }
}
johnDoe.greet();

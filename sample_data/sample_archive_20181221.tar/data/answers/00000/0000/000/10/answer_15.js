['99', '2.3', '23a', 'xyz'].forEach((s) =>
  console.log(`${s} ${isNaN(s) ? 'is not' : 'is'} numeric.`)
);
[99, 2.3, '2.3a', 'xyz'].forEach((x) =>
  console.log(`${x} ${Number.isInteger(x) ? 'is' : 'is not'} an integer.`)
);

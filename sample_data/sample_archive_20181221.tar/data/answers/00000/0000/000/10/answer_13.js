//a
var num = 10;
console.log(++num - 10); // 1
num = 10;
console.log(num++ - 10); // 0

//b
num = 1;
console.log(--num + 10); // 10

//c
num = 1;
num2 = (num++ * 10 + 1);
console.log(num);   // 2
console.log(num2);  // 11

arr = [*(-10..10)]
neg = []
zero = []
pos = []
arr.each do |x|
  case x <=> 0
  when -1
    neg << x
  when 0
    zero << x
  when 1
    pos << x
  end
end
puts "Negative: #{neg.inspect}"
puts "Zero: #{zero.inspect}"
puts "Positive: #{pos.inspect}"



puts ''
#####################################


arr = *(-10..10)
pos = []
saame = []
neg = []
arr.each do |n|
  case 0 <=> n
  when 1
    neg << n
  when 0
    saame << n
  when -1
    pos << n
  end
end
p neg
p saame
p pos


puts ''
#####################################


arr  = *(-10..10)
pos = []
neg = []
arr.each do |n|
  case n <=> 0
  when 1
    pos << n
  when -1
    neg << n
  end
end
p pos
p neg



puts ''
#####################################



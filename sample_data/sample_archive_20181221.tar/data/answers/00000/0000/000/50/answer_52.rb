arr = Array.new(10)
p arr
arr2 = Array.new(10, true)
p arr2
arr3 = Array.new(10) {|x| x}
p arr3

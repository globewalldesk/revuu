puts "#{8212.chr('utf-8')} \u2014 #{[8212].pack('U')}"
# #chr 'utf-8' encoding as well as 'U' packing both use the decimal UTF-8 code.
# But the \u escape character uses the hex version of the code.

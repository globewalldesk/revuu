const Ooby = {adventure: 'space', bouncy: true};
Object.freeze(Ooby);
console.log(Ooby.adventure);
Ooby.adventure = 'underwater';
console.log(Ooby.adventure);

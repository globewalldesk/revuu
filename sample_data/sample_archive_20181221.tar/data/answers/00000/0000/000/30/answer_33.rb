require 'json'
config = {'lang' => 'Ruby', 'text_editor' => 'Pico'}
File.write("./config.json", config.to_json)
raw_data = File.read("./config.json")
settings = JSON.parse(raw_data)
puts settings['lang']

let i = 'global scope';
var j = 'global scope'

function checkScope() {
"use strict";
  if (true) {
    let i = 'block scope'; // toggle this between 'let' and 'var' to see diff.
    console.log("i in block is: ", i);
  }
  console.log("i in function is: ", i);
}
checkScope();


// raises error; 'let' disallows redeclaration
console.log("i out of function is: ", i);
// let i = 'global scope again'; // uncomment this out to show the issue
console.log("i out of function is: ", i);

// 'var' permits redeclaration
console.log("j out of function is: ", j);
var j = 'global scope again';
console.log("j out of function is: ", j);

require 'date'
now = DateTime.now
p now.to_s
fut = now + 7
puts "In a week it will be #{fut.strftime("%-m/%-d/%Y")}."
twohours = now + (2/24.0)
puts "In two hours it will be #{twohours.strftime("%l:%M %p")}."



puts ''
#####################################


require 'date'
now = DateTime.now
p now.to_s
now += 7
p now.to_s
puts "In a week it will be #{now.strftime("%-m/%-d/%Y")}."
twohrs = DateTime.now + (2/24.0)
puts "In two hours it will be #{twohrs.strftime("%-l:%M %P")}."



puts ''
#####################################


require 'date'
moment = DateTime.now
p moment.to_s
moment += 7
puts "In a week it will be #{moment.strftime("%-m/%-d/%Y")}."
moment2 = DateTime.now + (2.0/24)
puts "In two hours it will be #{moment2.strftime("%-H:%M %p")}."


puts ''
#####################################


require 'date'

now = DateTime.now
puts now.to_s

date = (now + 7).strftime("%-m/%-d/%Y")
puts "In a week it will be #{date}."
time = (now + 2/24.0).strftime("%-I:%M %p")
puts "In two hours it will be #{time}."



puts ''
#####################################



let tenEmpty = Array(10)
console.log(tenEmpty);
tenEmpty[3] = 'three'
console.log(tenEmpty);
let onetoten = [...Array(10).keys()];
console.log(onetoten);
let onetotenNew = [...new Array(10).keys()];
console.log(onetotenNew);
let nudderOnetoten = Array.from(Array(10).keys());
console.log(nudderOnetoten);

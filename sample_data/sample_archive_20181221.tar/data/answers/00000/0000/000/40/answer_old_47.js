const tenEmpty = Array(10);
console.log(tenEmpty);
tenEmpty[3] = 'three';
console.log(tenEmpty);
const onetoten = [...Array(10).keys()];
console.log(onetoten);
const onetotenNew = [...new Array(10).keys()];
console.log(onetotenNew);
const nudderOnetoten = Array.from(Array(10).keys())
console.log(nudderOnetoten);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


tenEmpty = new Array(10);
console.log(tenEmpty);
onetoten = [...Array(10).keys()]
console.log(onetoten);
onetotenNew = [...new Array(10).keys()]
console.log(onetotenNew);
nudderOnetoten = Array.from(Array(10).keys())
console.log(nudderOnetoten);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


const plain = Array(10)
const arr = [...Array(10).keys()];
const newArr = [...new Array(10).keys()];
const newerArr = Array.from(new Array(10).keys());
console.log(plain);
console.log(arr);
console.log(newArr);
console.log(newerArr);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


console.log([...Array(10).keys()]);
console.log([...new Array(10).keys()]);
console.log(Array.from(Array(10).keys()));



console.log(' ')
//////////////////////////////////////////////////////////////////////////


console.log([...Array(10).keys()]);
console.log([...new Array(10).keys()]);
console.log(Array.from(Array(10).keys()));



console.log(' ')
//////////////////////////////////////////////////////////////////////////


console.log([...Array(10).keys()])


console.log(' ')
//////////////////////////////////////////////////////////////////////////


console.log([...Array(10).keys()])



console.log(' ')
//////////////////////////////////////////////////////////////////////////


console.log([...Array(10).keys()]);


console.log(' ')
//////////////////////////////////////////////////////////////////////////


console.log([...Array(10).keys()]);


//////////////////////////////////////////////////////////////////////////


console.log(
  arr = [         // The spread operator works within an array, etc.
    ...Array(10). // Simply generates a blank array 10 elements long.
                  // The spread operator converts an empty object into an array.
    keys()        // Returns the indexes of the array instead of 10 'undefined'.
  ]
);


//////////////////////////////////////////////////////////////////////////
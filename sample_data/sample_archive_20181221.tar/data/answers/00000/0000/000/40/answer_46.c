#include <stdio.h>

int main() {
    char    c =   'c';
    int     i =   123;
    float   f =   3.14;
    long double  ld =   3453245938439.31;
    short   si =  32767;
    long    li =  2147483647;
    printf("%c\t%i\t%f\n", c, i, f);
    printf("%Lf\t%hi\t%li\n", ld, si, li);
}

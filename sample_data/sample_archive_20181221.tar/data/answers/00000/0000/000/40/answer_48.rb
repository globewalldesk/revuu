require 'date'
now = DateTime.now
puts now
now += 7
a_week = now.strftime("%-m/%-d/%Y")
puts "In a week it will be #{a_week}."
now += 2/24.0
two_hours = now.strftime("%-l:%M %p")
puts "In two hours it will be #{two_hours}."

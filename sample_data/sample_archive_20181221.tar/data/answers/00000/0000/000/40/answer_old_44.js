const hello = (x='John Doe') => console.log("Hello, " + x + ".");
hello("George Washington");
hello();


console.log(' ')
//////////////////////////////////////////////////////////////////////////


const hello = (name = 'John Doe') => console.log("Hello, " + name + ".")

hello("George Washington");
hello();


//////////////////////////////////////////////////////////////////////////



class Animal
  attr_accessor :name, :living

  def initialize(name)
    @name = name
    @living = true
  end

  def makes_noise
    puts "#{@name} growls!"
  end
end
leo = Animal.new('Leo')
leo.makes_noise

class Cat < Animal

  def makes_noise
    super
    puts "Then #{@name} meows, and #{@living ? 'is' : 'is not'} alive!"
  end

end
morris = Cat.new("Morris")
morris.makes_noise
morris.living = false
morris.makes_noise

p morris.instance_variables

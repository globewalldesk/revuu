puts "The top-level program being executed is #{$PROGRAM_NAME} or #{$0}."
puts "The program executing this very line, however, is #{__FILE__}."

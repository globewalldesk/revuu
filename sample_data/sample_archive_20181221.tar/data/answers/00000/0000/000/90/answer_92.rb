p File.readlines(__FILE__)[-1]
puts 'This is a file I am enjoying reading, to be honest.'
puts 'And now you have come to the end of it. Too bad!'

cubed = Proc.new {|x| x**3}
puts cubed.call(3)
fourth = lambda {|x| x**4}
puts fourth.call(7)
sixth = -> (x) {x**6}
puts sixth.call(13)



puts ''
#####################################


cube = Proc.new {|x| x**3}
p cube.call(3)
lquad = lambda {|x| x**4}
p lquad.call(7)
lsix = -> (x){x**6}
p lsix.call(13)



puts ''
#####################################


cuber = Proc.new {|x| x**3}
puts cuber.call(3)
quadder = lambda {|x| x**4}
puts quadder.call(7)
sixer = -> (x) { x**6}
puts sixer.call(13)


puts ''
#####################################


cubed = Proc.new {|x| x**3}
puts cubed.call(3)
fourth = lambda {|x| x**4}
puts fourth.call(7)
sixth = -> (x) {x**6}
puts sixth.call(13)



puts ''
#####################################


cube = Proc.new {|x| x**3 }
puts cube.call(3) # 27
tothefourth = lambda {|x| x**4}
puts tothefourth.call(7)
tothesixth = -> (x) { x**6}
puts tothesixth.call(13)



###########################################################################



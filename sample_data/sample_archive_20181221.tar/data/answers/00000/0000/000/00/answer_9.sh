curl -L http://larrysanger.org/ > temp.tmp
ls temp.tmp
echo "

This is another line." >> temp.tmp
tail temp.tmp
rm temp.tmp
ls temp.tmp

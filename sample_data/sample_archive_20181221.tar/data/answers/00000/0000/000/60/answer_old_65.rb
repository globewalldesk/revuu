str = "hello world"
# Replace the following with something even shorter.
p str.chars



puts ''
#####################################


str = "hello world"
# Replace the following with something even shorter.
p str.split('')
p str.chars


puts ''
#####################################


str = "hello world"
# Replace the following with something even shorter.
p str.split('')
p str.chars



puts ''
#####################################


str = "hello world"
# Replace the following.
p str.chars



puts ''
#####################################


str = "hello world"
p str.split('')
p str.chars


puts ''
#####################################



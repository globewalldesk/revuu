zip -q starters.zip -r ../../../../../starters
ls -l *.zip
unzip -q starters.zip -d starters
ls -lR starters
rm -rf starters
rm starters.zip
ls -Rl
ls -l *.zip

require 'date'
p (DateTime.instance_methods & Time.instance_methods).length
p (DateTime.new.methods & Time.new.methods).length

ps aux | grep ruby



echo '<--spacer-->'
#####################################


ps aux | grep 'ruby'


echo '<--spacer-->'
#####################################


ps aux | grep 'ruby'



echo '<--spacer-->'
#####################################


ps aux | grep ruby



echo '<--spacer-->'
#####################################



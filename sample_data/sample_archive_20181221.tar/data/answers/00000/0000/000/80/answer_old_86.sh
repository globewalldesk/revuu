less ../../../../sonnets.txt



echo '<--spacer-->'
#####################################


less sonnets.txt



echo '<--spacer-->'
#####################################


less sonnets.txt



echo '<--spacer-->'
#####################################


less sonnets.txt


echo '<--spacer-->'
#####################################



nhash = Hash.new(0)
1_000_000.times do |n|
  nums = []
  10.times { n = rand(10) + 1; raise "Non-integer spotted" unless n.integer?; nhash[n] += 1  }
end
p nhash.sort_by{|k,v|k}

class SortedArray < Array
  def initialize(arr)
    self << arr
    super
    self.sort!
  end
end

fun = SortedArray.new(['fiddle', 'program', 'movies'])
p fun
p fun.reverse!

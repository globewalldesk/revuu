#include <stdio.h>
#define   UPPER   300
#define   LOWER   0
#define   STEP    20
int main() {
    float fahr;

    for (fahr = LOWER; fahr <= UPPER; fahr = fahr + STEP)
        printf("%-3.0f\t%1.2f\n", fahr, (5.0/9) * (fahr-32));
}

echo "From fairest creature we desire increase" > shake.txt
echo "That thereby beauty's rose might never die," >> shake.txt
cat shake.txt
rm shake.txt
ls shake.txt



echo '<--spacer-->'
#####################################


echo "From fairest creatures we desire increase," > foo.txt
echo "That thereby beauty's rose might never die," >> foo.txt
cat foo.txt
rm foo.txt



echo '<--spacer-->'
#####################################


echo "From fairest creatures we desire increase," > poem.txt
echo "That thereby beauty's rose might never die," >> poem.txt
cat poem.txt
ls -ltr poem.txt
rm poem.txt
ls -ltr poem.txt



echo '<--spacer-->'
#####################################



echo "hello, world" > foo.txt
cat foo.txt > bar.txt
cat foo.txt
cat bar.txt
ls -lh
rm foo.txt bar.txt
ls -lh
pwd



echo '<--spacer-->'
#####################################


echo "hello, world" > foo.txt
cat foo.txt > copy.txt
echo file contents:
cat foo.txt
cat copy.txt
ls -l foo.txt copy.txt
rm foo.txt copy.txt
ls -l foo.txt copy.txt



echo '<--spacer-->'
#####################################


echo "hello, world" > foo.txt
cat foo.txt > bar.txt
echo foo.txt:
cat foo.txt
echo bar.txt:
cat bar.txt
ls -lah foo.txt bar.txt
rm foo.txt bar.txt
ls -lah foo.txt bar.txt



echo '<--spacer-->'
#####################################


echo "hello, world" > foo.txt
cat foo.txt > bar.txt
echo here is foo
cat foo.txt
echo here is bar
cat bar.txt
ls -lah *.txt
qrm foo.txt bar.txt
ls -lah *.txt



echo '<--spacer-->'
#####################################



echo 'hello, world' > foo.txt
cat foo.txt > bar.txt
cat foo.txt
cat bar.txt
rm foo.txt bar.txt
ls foo.txt bar.txt

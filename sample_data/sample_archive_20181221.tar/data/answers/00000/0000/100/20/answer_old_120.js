str = 'hello world';
str = 'hello world';
console.log(str.substring(0,5)); // 'hello'
console.log(str.substr(0,5)); // 'hello'
console.log(str.substring(3,5)); // 'lo'
console.log(str.substr(3,2)); // 'lo'
console.log(str.substring(6,11)); // 'world'
console.log(str.substr(6,5)); // 'world'



console.log(' ')
//////////////////////////////////////////////////////////////////////////


str = 'hello world';
str = 'hello world';
console.log(str.substring(0,5)); // 'hello'
console.log(str.substr(0,5)); // 'hello'
console.log(str.substring(3,5)); // 'lo'
console.log(str.substr(3,2)); // 'lo'
console.log(str.substring(6)); // 'world'
console.log(str.substr(6,11)); // 'world'



console.log(' ')
//////////////////////////////////////////////////////////////////////////


str = 'hello world';
console.log(str.substring(3,5));  // arg 2 of substring() is the index just
                                  // before which to stop copying.
console.log(str.substr(3,2));     // arg 2 of substr() is the number of
                                  // characters to copy.
console.log(str.substring(0,5));
console.log(str.substr(0,5));
console.log(str.substring(6,11));
console.log(str.substr(6,5));



console.log(' ')
//////////////////////////////////////////////////////////////////////////



arr = %w(foo bar baz)
p arr

let html = 'html';
let poet = 'E.E. Cummings';
let title = 'the big sleep';

console.log(html.toUpperCase());
console.log(poet.toLowerCase());
console.log(title.split(' ').map((w) => w[0].toUpperCase() + w.slice(1)).join(' '));

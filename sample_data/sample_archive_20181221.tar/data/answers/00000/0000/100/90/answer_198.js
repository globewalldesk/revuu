const Prez = function(name, accomplishments) { return {name, accomplishments,
  print() {
    console.log(this);
  }}
};

const george = new Prez('George Washington', ['first prez', 'first general']);
george.print();
const cal = new Prez('Calvin Coolidge', ['admirably doing nothing']);
cal.print();

let george = {
  name: 'George Washington',
  accomplishment: ['first prez', 'first general'],
  print() {
    console.log(this);
  }
}
george.print();



console.log(' ')
//////////////////////////////////////////////////////////////////////////


const george = {
  name: 'George Washington',
  accomplishments: ['first prez', 'first general'],
  print() {
    for (i in this) {
      console.log(`${i}: ${this[i]}`);
    }
  }
};
george.print();



console.log(' ')
//////////////////////////////////////////////////////////////////////////



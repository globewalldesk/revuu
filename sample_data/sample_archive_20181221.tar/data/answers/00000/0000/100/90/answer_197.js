let num = '123';
let abc = 'abc';
console.log(num + abc);
console.log(num.concat(abc));
console.log(num += abc);

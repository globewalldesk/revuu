let html = 'html';
let poet = 'E.E. Cummings';
let title = 'the big sleep';

function capitalize(str) {
  let words = str.split(' ');
  words = words.map((word) => word[0].toUpperCase() + word.slice(1));
  return words.join(' ');
}

console.log(html.toUpperCase());
console.log(poet.toLowerCase());
console.log(capitalize(title));



console.log(' ')
//////////////////////////////////////////////////////////////////////////


let usa = 'u.s.a.';
let poet = 'E.E. Cummings';
let title = 'the big sleep';
usa = usa.toUpperCase();
poet = poet.toLowerCase();
title = title.split(" ")
             .map((w) => w[0].toUpperCase() + w.slice(1))
             .join(" ");
console.log(usa);
console.log(poet);
console.log(title);



console.log(' ')
//////////////////////////////////////////////////////////////////////////



const Rectangle = function(height, width) { return {height, width,
  calcArea() {
    return height * width;
  }}
}

rect = new Rectangle(3,4);
console.log("rect's area = " + rect.calcArea());



console.log(' ')
//////////////////////////////////////////////////////////////////////////


function Rectangle(height, width) { return { height, width,
  calcArea() {
    return (height * width);
  }
}}
const rect = new Rectangle(6, 4);
console.log(rect.calcArea());



console.log(' ')
//////////////////////////////////////////////////////////////////////////



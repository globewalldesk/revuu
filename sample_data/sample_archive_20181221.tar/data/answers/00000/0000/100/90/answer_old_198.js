function Prez(name, accomplishments) {return {name, accomplishments,
    print() {
      console.log(this);
    }}}

george = new Prez('George Washington', ['first prez', 'first general']);
george.print();
abe = new Prez('Abraham Lincoln', ['kept country together', 'freed slaves']);
abe.print();


console.log(' ')
//////////////////////////////////////////////////////////////////////////


const Prez = function(name, accomplishments) {return {
  name,
  accomplishments,
  print() {
    for (i in this) {
      console.log(`${i}: ${this[i]}`);
    }
  }}
};
george = new Prez("George Washington", ['this', 'that']);
george.print();

trump = new Prez("Donald Trump", ['pissing people off', 'deregulating']);
trump.print();



console.log(' ')
//////////////////////////////////////////////////////////////////////////



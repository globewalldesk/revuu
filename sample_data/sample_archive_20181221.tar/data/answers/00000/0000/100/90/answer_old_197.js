let abc = 'abc';
let num = '123';
console.log(abc + num);
console.log(abc.concat(num));
abc += num;
console.log(abc);



console.log(' ')
//////////////////////////////////////////////////////////////////////////



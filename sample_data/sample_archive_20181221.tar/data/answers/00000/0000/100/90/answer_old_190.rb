arr = %w(foo bar baz)
p arr



puts ''
#####################################


arr = %w(foo bar baz) # Also called a percent string.
p arr



puts ''
#####################################



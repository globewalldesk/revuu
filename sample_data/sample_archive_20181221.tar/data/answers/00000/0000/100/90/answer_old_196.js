let johnDoe = {};
johnDoe.firstName = 'John';
johnDoe.lastName = 'Doe';
johnDoe.greet = function() {
  console.log("Hi, I'm " + this.firstName + " " + this.lastName + ".")
}

for(i in johnDoe) {
  console.log(`${i}: ${johnDoe[i]}`);
}
console.log(johnDoe);

const hallo = function() {
  console.log("Hello!");
}

const yo = hallo;
yo();
console.log(yo.name);
console.log(hallo.name);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


let johnDoe = {};
johnDoe.firstName = 'John';
johnDoe.lastName = 'Doe';
johnDoe.greet = function() {
  console.log("Hi, I'm " + this.firstName + " " + this.lastName + ".")
}
for (i in johnDoe) {
  console.log(`${i}: ${johnDoe[i]}`);
}

console.log(johnDoe);



console.log(' ')
//////////////////////////////////////////////////////////////////////////



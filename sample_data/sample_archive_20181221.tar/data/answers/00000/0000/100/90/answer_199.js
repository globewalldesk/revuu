const Rectangle = function(height, width) {
  return {height, width,
    calcArea() {
      return (this.height * this.width);
    }
  }
}
const rectum = new Rectangle(2,3);
console.log(rectum.calcArea());

const george = {
  name: 'George Washington',
  accomplishment: ['first prez', 'first general'],
  print() {
    console.log(this);
  }
}
george.print();

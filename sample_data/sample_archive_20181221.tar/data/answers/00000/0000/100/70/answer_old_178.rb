employees = %w{Jones Smith Abbott Collins Howard Iverson Zemba Evans O'Toole
               Miller Sanger Davidson Reed Johnson Franke Culbertson Collins
               Duck Edwards Forsythe Williams Sharon}
p employees.find_all {|x| x[0].between?('C', 'E')}.sort



puts ''
#####################################


employees = %w{Jones Smith Abbott Collins Howard Iverson Zemba Evans O'Toole
               Miller Sanger Davidson Reed Johnson Franke Culbertson Collins
               Duck Edwards Forsythe Williams Sharon Bartels Boop}
p employees

employees_c_e = employees.find_all {|x| x[0].between?('C', 'E')}.sort
p employees_c_e



puts ''
#####################################



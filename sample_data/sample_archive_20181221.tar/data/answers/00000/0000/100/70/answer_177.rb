dots = %w{... ..  ........... ............. .... .. ... ...... . .......}
arrs = [[1, 2, 3, 4], [1], [], [1,2], [1,2,3,4,5,6,7,8]]

module Comparable
  def <=>(other)
    if self > other
      1
    elsif self < other
      -1
    elsif self == other
      0
    end
  end
end

puts dots.sort_by(&:length)
arrs.sort_by(&:length).each {|a| p a}

dots = %w{... ..  ........... ............. .... .. ... ...... . .......}
arrs = [[1, 2, 3, 4], [1], [], [1,2], [1,2,3,4,5,6,7,8]]

module Comparable
  def <=>(other)
    if self.length > other.length
      1
    elsif self.length < other.length
      -1
    else
      0
    end
  end
end

puts dots.sort!
p arrs.sort!



puts ''
#####################################


module Comparable
  def <=>(other)
    if self.length > other.length
      1
    elsif self.length < other.length
      -1
    elsif self.length == other.length
      0
    end
  end
end

dots = %w{... ..  ........... ............. .... .. ... ...... . .......}
puts dots.sort


puts ''
#####################################


module Comparable
  def <=>(other)
    if self.length > other.length
      1
    elsif other.length > self.length
      -1
    elsif self.length == other.length
      0
    end
  end
end

dots = %w{... ..  ........... ............. .... .. ... ...... . .......}
dots.sort!.reverse!
puts dots



puts ''
#####################################



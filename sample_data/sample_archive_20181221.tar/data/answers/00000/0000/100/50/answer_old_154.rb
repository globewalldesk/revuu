class Person
  attr_accessor :name, :age, :nationality

  def initialize(name, age:, nationality: 'American')
    @name = name
    @age = age
    @nationality = nationality
  end

  def profile
    puts "Name: " + @name
    puts "Age: " + @age
    puts "Nationality: " + @nationality
  end
end

# Create...
mama = Person.new('Rita', age:'not telling', nationality:'none of your business')
papa = Person.new('Larry', age:'50')

# Call...
mama.profile
papa.profile

extinct_animals = {
"Passenger Pigeon" => 1914,
"Tasmanian Tiger" => 1936,
"Eastern Hare Wallaby" => 1890,
"Dodo" => 1662,
"Pyrenean Ibex" => 2000,
"West African Black Rhinoceros" => 2011,
"Laysan Crake" => 1923
}
extinct_animals.map!{|hash,key| hash[key] -= 3}
p extinct_animals



puts ''
#####################################


class Person
  attr_accessor :name, :age, :nationality

  def initialize(name, sex:, nationality: 'American')
    @name = name
    @sex = sex
    @nationality = nationality
  end

  def profile
    puts "Name: " + @name
    puts "Sex: " + @sex
    puts "Nationality: " + @nationality
  end
end

# Create...
fred = Person.new("Fred Flintstone", sex: 'male', nationality: "Venusian")

# Call...
fred.profile



puts ''
#####################################


class Person
  attr_accessor :name, :sex, :nationality

  def initialize(name, sex:, nationality: 'American')
    @name = name
    @sex = sex
    @nationality = nationality
  end

  def profile
    puts "Name: " + @name
    puts "Sex: " + @sex
    puts "Nationality: " + @nationality
  end
end

larry = Person.new('Sanger', sex: 'male', nationality: "Martian")
larry.profile



puts ''
#####################################



arr = (1..10).to_a
evens, odds = arr.partition(&:even?)
p evens, odds

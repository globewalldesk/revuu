str1 = "Revuu is the best!"
str2 = "Version 3.3"
puts str1.ljust(30) + str2
puts str1 + str2.rjust(30)
printf("%-30s%s\n", str1, str2)
printf("%s%30s", str1, str2)



puts ''
#####################################


str1 = "Revuu is the best!"
str2 = "Version 3.3"
puts str1.ljust(30) + str2
puts str1 + str2.rjust(30)
printf("%-30s%s\n", str1, str2)
printf("%s%30s\n", str1, str2)



puts ''
#####################################


str1 = "Revuu is the best!"
str2 = "Version 3.3"
puts str1.ljust(30, '-') + str2
puts str1 + str2.rjust(30, '*')
printf("%-30s%s\n", str1, str2)
printf("%s%30s\n", str1, str2)



puts ''
#####################################



arr = [1, '1', 2, '2', 3, '3']
p arr.collect(&:next)
p arr.select {|n| n.class == Integer}



puts ''
#####################################


arr = [1, 'a', 2, 'b', 3, 'c']
p arr.collect(&:next)
p arr.select {|n| n.class == Integer}



puts ''
#####################################



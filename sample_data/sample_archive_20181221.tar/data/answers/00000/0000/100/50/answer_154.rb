class Person
  attr_accessor :name, :age, :nationality

  def initialize(name, age:, nationality: 'American' )
    @name = name
    @age = age.to_s
    @nationality = nationality
  end

  def profile
    puts "Name: " + @name
    puts "Age: " + @age
    puts "Nationality: " + @nationality
  end
end

# Create...
joebob = Person.new("Joe Bob Bojangles", age: 29)

# Call...
joebob.profile

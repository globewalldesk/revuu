class Person
  attr_accessor :name, :age, :occupation

  def initialize(name, data)
    @name = name
    @age = data[:age]
    @occupation = data[:occupation]
  end

  def resume
    puts "Name: " + @name
    puts "Age: " + @age
    puts "Occupation: " + @occupation
  end
end

dude = Person.new('Lebowski', age: '48', occupation: 'Dude')
dude.resume

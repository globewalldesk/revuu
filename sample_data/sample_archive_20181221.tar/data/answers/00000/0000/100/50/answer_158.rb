lengths = Hash.new do |hash,key|
  key = key.to_s unless key.is_a? String
  hash[key] = key.length
end

lengths['abc'] = 3
lengths[:alpha] = true
lengths[:updated] = false
lengths['apple']
lengths['melon']
lengths['zucchini']
lengths['Jehosaphat']

p lengths

foods = Hash.new do |hash, key|
  if key =~ /^[a-zA-Z]$/
    hash[key.downcase] = []
  elsif key =~ /^([a-zA-Z])[\w ]+$/
    i = $1.downcase
    p key, i
    hash[i] = [] unless hash[i]
    p hash[i]
    hash[i] << key
  end
end

foods['c']
foods['c'].concat(['cucumber', 'carrot', 'coffee'])
foods['l']
foods['s'].concat(['squash', 'sesame seeds', 'sandwich'])
foods['avocado']
foods['apple']
foods['gourd']
foods['steak']
foods['eggs']
foods['Big Mac']
foods['Burger King Whopper']

p foods.sort_by{|k,v|k}

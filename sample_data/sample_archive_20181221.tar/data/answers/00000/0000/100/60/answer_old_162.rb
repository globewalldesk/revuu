ARR = [1, 2, 3]
p ARR
ARR[0] = 4
ARR[1] = 5
ARR[2] = 6
p ARR
ARR.freeze
puts ARR.frozen?
begin
  ARR << 7
rescue Exception => err
  puts "Boo! #{err.message} in #{err.class}"
end
p ARR

# The thing I had trouble with here is that I forgot that you can reassign
# a frozen constant; Ruby will complain, not because it's frozen, but because
# it's a constant. Ruby will actually prevent you from *modifying* a frozen
# variable, as pushing to an array. Reassigning is OK.



puts ''
#####################################


ARR = [1, 2, 3]
p ARR
ARR[0] = 4
ARR[1] = 5
ARR[2] = 6
p ARR
ARR.freeze
begin
  p ARR << 7
rescue RuntimeError => err
  puts "#{err.class}: rescued error '#{err.message}'"
ensure
  puts "ARR = #{ARR.inspect}"
end



puts ''
#####################################


ARR = [1, 2, 3]
p ARR
ARR[0] = 4
ARR[1] = 5
ARR[2] = 6
p ARR
ARR.freeze
begin
  ARR << 7
rescue RuntimeError => err
  puts "#{err.class}: #{err.message}"
ensure
  p ARR
end



puts ''
#####################################


ARR = [1, 2, 3]
p ARR
ARR[0] = 4
ARR[1] = 5
ARR[2] = 6
p ARR
ARR.freeze
puts ARR.frozen?
begin
  ARR[0] = 7
rescue StandardError => e
  puts "Didn't work: #{e.class} reported '#{e}'"
ensure
  p ARR
end



puts ''
#####################################



ARR = [1, 2, 3]
p ARR
ARR.freeze
begin
  ARR << 4
rescue => err
  puts "Error of type '#{err.class}':\n    #{err.message}"
end
p ARR

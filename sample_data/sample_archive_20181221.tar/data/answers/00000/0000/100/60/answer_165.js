console.log(Math.floor(Math.random()*10 + 1));

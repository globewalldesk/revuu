module Bipedal
  def two_legs(name)
    puts "#{name} has exactly two limbs used for walking."
  end
end

class Person
  def two_legs(name)
    puts "#{name} has two human legs."
  end
end

class Boy < Person
  include Bipedal
  attr_accessor :name
  def initialize(name)
    @name = name
  end

  # (2) Add a basic #two_legs method calling super. What will be printed?
  # "Eddie has exactly two limbs..."
  #def two_legs
  #  super(@name)
  #end
  # (3) Add clever #two_legs method for Boy that will call the *other* version.
  def two_legs
    method(:two_legs).super_method.super_method.call(@name)
  end
end

# (1a) Make a Boy & call two_legs on it.
eddie = Boy.new('Eddie')
eddie.two_legs
# (1b) What will be printed? "Eddie has exactly two limbs..."

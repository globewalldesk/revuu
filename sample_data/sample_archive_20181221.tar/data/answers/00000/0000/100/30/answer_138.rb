def car_reporter(car)
  puts "Make: " + car.make
  puts "Model: " + car.model
  puts "Year: " + car.year
end

Car = Struct.new(:make, :model, :year)

mine = Car.new("Toyota", "Highlander", "2018")
car_reporter(mine);

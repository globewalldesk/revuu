A = [1, 2, 3, 4]
B = [2, 3, 3, 4, 5, 6]
C = ['Beetlejuice']
D = [:a, :b, :c]
E = [:d, :e, :f]
F = ['a', 'b', 'c', 'd', 'e']
G = ['b', 'd']
p A&B # [2,3,4]
p C*3 # ['Beetlejuice', 'Beetlejuice', 'Beetlejuice']
p D+E # [:a, :b, :c, :d, :e, :f]
p F-G # ['a', 'c', 'e']



puts ''
#####################################


A = [1, 2, 3, 4]
B = [2, 3, 3, 4, 5, 6]
C = ['Beetlejuice']
D = [:a, :b, :c]
E = [:d, :e, :f]
F = ['a', 'b', 'c', 'd', 'e']
G = ['b', 'd']

p A & B
p C * 3
p D + E
p F - G



puts ''
#####################################


A = [1, 2, 3, 3, 4]
B = [2, 3, 3, 4, 5, 6]
C = ['Beetlejuice']
D = [:a, :b, :c]
E = [:d, :e, :f]
F = ['a', 'b', 'c', 'd', 'e']
G = ['b', 'd']

p F-G
p D+E
p A&B
p C*3


puts ''
#####################################


A = [1, 2, 3, 4]
B = [2, 3, 3, 4, 5, 6]
C = ['Beetlejuice']
D = [:a, :b, :c]
E = [:d, :e, :f]
F = ['a', 'b', 'c', 'd', 'e']
G = ['b', 'd']
p D + E
p A & B
p C * 3
p F - G



puts ''
#####################################



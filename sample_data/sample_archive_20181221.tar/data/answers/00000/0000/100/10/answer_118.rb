module KlassModule
  def speak
    puts 'Woof! Woof!'
  end
end

class Klass
  extend KlassModule
  include KlassModule
end

Klass.speak
Klass.new.speak

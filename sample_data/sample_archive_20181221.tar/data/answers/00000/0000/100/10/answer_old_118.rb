module KlassModule
  def speak
    puts 'Woof! Woof!'
  end
end

class Klass
  extend KlassModule
  include KlassModule
end

Klass.speak
Klass.new.speak



puts ''
#####################################


module KlassModule
  def speak
    puts 'Woof! Woof!'
  end
end

class Klass
  include KlassModule
end

Klass.new.speak

count = 0



puts ''
#####################################


module KlassModule
  def speak
    puts 'Woof! Woof!'
  end
end

class Klass
  extend KlassModule
end

Klass.speak



puts ''
#####################################


module KlassModule
  def speak
    puts 'Woof! Woof!'
  end
end

class Klass
  extend KlassModule
end

Klass.speak



puts ''
#####################################


module KlassModule
  def speak
    puts 'Woof! Woof!'
  end
end

class Klass
  extend KlassModule
end

Klass.speak



puts ''
#####################################



function funkShun() {
  console.log("I can't actually access your new property easily...");
}
funkShun.prop = "foo bar";
funkShun();
console.log(funkShun.prop);

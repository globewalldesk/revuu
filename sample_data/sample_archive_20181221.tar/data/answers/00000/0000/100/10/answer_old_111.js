const a = () => console.log("Foo bar a!");
const b = () => console.log("Foo bar b!");
const square = (x) => console.log(x * x);
const funks = [a, b, square];
funks.forEach((funk) => funk(3));



console.log(' ')
//////////////////////////////////////////////////////////////////////////


const plusTwo = (x) => x + 2
const timesTwo = (x) => x * 2
const divByTwo = (x) => x / 2
const fnArr = [plusTwo, timesTwo, divByTwo];
fnArr.forEach((fn) => console.log(fn(6)));


console.log(' ')
//////////////////////////////////////////////////////////////////////////


const plusTwo = (x) => x + 2
const timesTwo = (x) => x * 2
const divByTwo = (x) => x / 2
const fnArr = [plusTwo, timesTwo, divByTwo];
fnArr.forEach((fn) => console.log(fn(6)));


console.log(' ')
//////////////////////////////////////////////////////////////////////////


const two = function(x) {
  if (typeof x == 'number') {
    return (x * 2);
  } else if (typeof x == 'string') {
    return x += x;
  }
}

const antiCapitalize = function(str) {
  str = str.toUpperCase();
  stry = str.split('');
  stry[stry.length - 1] = stry[stry.length - 1].toLowerCase();
  return stry.join('');
}

const isPal = (x) => x == x.split('').reverse().join('');

const ary = [two, antiCapitalize, isPal];
ary.forEach((fun) => console.log(fun('five')));



console.log(' ')
//////////////////////////////////////////////////////////////////////////



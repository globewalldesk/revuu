arr = ['eeeee!', 'bb', 'aaa', 'the eagle has landed', 'hello', 'zed', 'goll dang']

p arr.min_by {|e| e.length}
p arr.min
p arr.min_by {|e| e.chars.count{|c| c=~/[Ee]/}}
p arr.max_by {|e| e.length}
p arr.max
p arr.max_by {|e| e.chars.count{|c| c=~/[Ee]/}}
p arr.minmax_by {|e| e.length}
p arr.minmax
p arr.minmax_by {|e| e.chars.count{|c| c=~/[Ee]/}}
p arr.sort_by {|x| x.length}
p arr.sort
p arr.sort_by {|e| e.chars.count{|c| c=~/[Ee]/}}



puts ''
#####################################


arr = ['eeeee!', 'bb', 'aaa', 'the eagle has landed', 'hello', 'zed', 'goll dang']

puts arr.min_by {|x| x.length}
puts arr.min
puts arr.min_by {|x| x.split(//).count('e') }
puts

puts arr.max_by {|x| x.length}
puts arr.max
puts arr.max_by {|x| x.split(//).count('e') }
puts

p arr.minmax_by {|x| x.length}
p arr.minmax
p arr.minmax_by {|x| x.split(//).count('e') }
puts

p arr.sort {|x,y| x.length <=> y.length}
p arr.sort
p arr.sort {|x,y| x.split(//).count('e') <=> y.split(//).count('e') }



puts ''
#####################################


arr = ['eeeee!', 'bb', 'aaa', 'the eagle has landed', 'hello', 'zed', 'goll dang']

puts arr.min_by {|x| x.length}
puts arr.min_by {|x| x}
puts arr.min_by {|x| x.split('').count('e')}
puts
puts arr.max_by {|x| x.length}
puts arr.max_by {|x| x}
puts arr.max_by {|x| x.split('').count('e')}
puts
p arr.minmax {|x| x.length}
p arr.minmax {|x,y| x <=> y}
p arr.minmax {|x| x.split('').count('e')}
puts
p arr.sort {|x,y| x.length <=> y.length}
p arr.sort {|x,y| x <=> y}
p arr.sort {|x,y| x.split('').count('e') <=> y.split('').count('e')}



puts ''
#####################################


arr = ['eeeee!', 'be', 'aaa', 'the eagle has landed', 'hello', 'zed', 'goll dang']
puts "Minimums:"
puts "Length: " + arr.min_by {|x| x.length}
puts "Alpha order: " + arr.min_by {|x| x}
puts "Number of e's: " + arr.min_by {|x| x.chars.count{|n| n == 'e'}}
puts "Maximums:"
puts "Length: " + arr.max_by {|x| x.length}
puts "Alpha order: " + arr.max_by {|x| x}
puts "Number of e's: " + arr.max_by {|x| x.chars.count{|n| n == 'e'}}
puts "Minimums and maximums:"
puts "Length: " + arr.minmax_by {|x| x.length}.to_s
puts "Alpha order: " + arr.minmax_by {|x| x}.to_s
puts "Number of e's: " + arr.minmax_by {|x| x.chars.count{|n| n == 'e'}}.to_s
puts "Sorted by test:"
p arr.sort {|x,y| x.length <=> y.length}
p arr.sort
p arr.sort {|x,y| x.chars.count{|n| n == 'e'} <=> y.chars.count{|n| n == 'e'}}



puts ''
#####################################


arr = ['eeeee!', 'bb', 'aaa', 'the eagle has landed', 'hello', 'zed', 'goll dang']
puts "length: " + arr.sort {|x,y| x.length <=> y.length}.inspect
puts "alpha: " + arr.sort {|x,y| x<=>y}.inspect
puts "number of e: " + arr.sort {|x| x.split('').count{|l| l == 'e'}}.inspect



puts ''
#####################################



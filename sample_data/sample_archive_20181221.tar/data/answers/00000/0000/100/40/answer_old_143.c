#include <stdio.h>

int main() {
    int c, nl, cc;
    nl = 1;
    cc = 0;
    while((c = getchar()) != EOF) {
        if(c == '\n') {
          ++nl;
        } else {
          ++cc;
        }
    }
    if(c == '\n') ++nl;
    printf("\n=================\n%d lines\n%d characters\n", nl, cc);
}

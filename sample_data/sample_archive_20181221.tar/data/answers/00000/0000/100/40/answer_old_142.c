#include <stdio.h>

int main() {
  double nc;
  while (getchar() != EOF) {++nc;}
  printf("\n==============\n%.0f characters\n", nc);
}

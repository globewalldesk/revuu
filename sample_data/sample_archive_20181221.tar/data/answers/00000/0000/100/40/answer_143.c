#include <stdio.h>

int main() {
    int c, nl, cc;
    nl = 1;
    cc = 0;
    while((c = getchar()) != EOF) {
        if(c == '\n') {
          ++nl;
        } else {
          ++cc;
        }
    }
    if(c == '\n') ++nl;
    printf("\n=================\n%d characters\n%d lines\n", cc, nl);
}

ARR = [1, 2, 3]
ARR.freeze
begin
  p ARR << 4
rescue => err
  puts "#{err.class}: rescued error '#{err.message}'"
ensure
  puts "ARR = #{ARR.inspect}"
end
p ARR



puts ''
#####################################


ARR = [1, 2, 3]
ARR.freeze
begin
  p ARR << 4
rescue => err
  puts "#{err.class}: rescued error '#{err.message}'"
ensure
  puts "ARR = #{ARR.inspect}"
end
p ARR



puts ''
#####################################



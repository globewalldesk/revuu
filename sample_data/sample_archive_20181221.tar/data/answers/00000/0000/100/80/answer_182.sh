ls -R ..

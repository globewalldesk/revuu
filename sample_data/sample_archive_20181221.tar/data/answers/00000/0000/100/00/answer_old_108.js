function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function sleepy() {
  console.log("Yoo!!");
  await sleep(2000);
  console.clear();
  console.log("Cleared!");
}
sleepy();



console.log(' ')
//////////////////////////////////////////////////////////////////////////


console.log('foo');
console.clear();
console.log("cleared what was formerly printed");



console.log(' ')
//////////////////////////////////////////////////////////////////////////


console.log("whoo!");
console.clear();
console.log("Cleared it.");



console.log(' ')
//////////////////////////////////////////////////////////////////////////


console.log("yo");
console.clear();
console.log("I cleared it!");


console.log(' ')
//////////////////////////////////////////////////////////////////////////


console.log('cannot see this');
console.clear();
console.log("You can see this!");



console.log(' ')
//////////////////////////////////////////////////////////////////////////



cd ../../../../../..
find . -path "./data" -prune -o -name "*.rb"

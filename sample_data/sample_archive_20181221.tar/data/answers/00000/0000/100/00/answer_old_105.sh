pwd; mkdir 'foo'; cd foo; pwd; touch bar; ls; cd -; rm -rf foo; ls foo && rm foo/bar



echo '<--spacer-->'
#####################################


pwd; mkdir 'foo'; cd foo; pwd; touch bar; ls; cd -; rm -rf foo && ls foo && rm foo/bar



echo '<--spacer-->'
#####################################


pwd && mkdir 'foo' && cd foo && pwd && touch bar && ls && cd - && rm -rf foo && ls foo && rm foo/bar



echo '<--spacer-->'
#####################################



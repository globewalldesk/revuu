ls -lh */ */*/
mkdir -p foo/bar
ls -lhR
rm -rf foo
ls -lh */ */*/

console.log("something");
console.clear();
console.log("something else");

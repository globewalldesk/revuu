cd ~
pwd

let str = "abcde";
let strnum = "abc123";
let numstr = "123abc";
let fltstr = "9.85x";
let flt = "9.85";
let flt2 = 9.99;
let int = 1;

// Part A: convert to float
console.log(str);
console.log(strnum);
console.log(numstr);
console.log(fltstr);
console.log(flt);
console.log(flt2);
console.log(int);

// Part B: convert to integer
console.log(str);
console.log(strnum);
console.log(numstr);
console.log(fltstr);
console.log(flt);
console.log(flt2);
console.log(int);

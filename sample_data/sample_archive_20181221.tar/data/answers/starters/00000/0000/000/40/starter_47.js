console.log(tenEmpty);
console.log(tenEmpty);
console.log(onetoten);
console.log(onetotenNew);
console.log(nudderOnetoten);

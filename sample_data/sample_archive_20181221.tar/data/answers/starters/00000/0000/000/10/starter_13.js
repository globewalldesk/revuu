//a
var num = 10;


//b


//c
num = 1;
num2 = (num++ * 10 + 1);
//console.log(num);   //
//console.log(num2);  //

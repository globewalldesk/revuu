puts "I am the first line."
puts "I am the second line."
puts "I am the third line."

const person = {
  name: 'John Doe',
  sayHello: function() {
    return "Hello! My name is " + this.name + ".";
  }
};
console.log(person.sayHello());

#include <stdio.h>

int main() {
    int c, nl;
    nl = 1;
    while((c = getchar()) != EOF) {
        if(c == '\n')
            ++nl;
    }
    if(c == '\n') ++nl;
    printf("\n=================\n%d lines\n", nl);
}

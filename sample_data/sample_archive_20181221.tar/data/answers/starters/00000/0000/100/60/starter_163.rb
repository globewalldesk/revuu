def encode(str)

end

def decode(str)

end

str = "The quick brown fox jumped over the lazy dog."
puts str
encoded_str = encode(str)
puts encoded_str
decoded_str = decode(encoded_str)
puts decoded_str

let html = 'html';
let poet = 'E.E. Cummings';
let title = 'the big sleep';

console.log(html);
console.log(poet);
console.log(title);
#include <stdio.h>

#define IN  1 /* inside word */
#define OUT 0 /* outside word */

/* count lines, words, and characters in input */
int main() {
    int c, nl, nw, nc, state;

    nl = nw = nc = 0;
    while((c = getchar()) != EOF) {
        ++nc;
        if(c == '\n')
            ++nl;
        if(c == ' ' || c == '\n' || c == '\t')
        else if() {
            ++nw;
        }
    }
    printf("\n===========\n%d newlines, %d words, %d characters\n", nl, nw, nc);
}

leaders = {
  Pericles: 'Athens',
  "Marcus Aurelius": 'Rome',
  "Genghis Khan": 'Mongolia',
  "George Washington": 'United States',
  Hitler: 'Germany',
  "Pol Pot": 'Cambodia'
}
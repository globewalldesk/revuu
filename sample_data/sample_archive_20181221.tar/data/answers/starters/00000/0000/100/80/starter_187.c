#include <stdio.h>

int main() {
    int c, first;
    while ((c = getchar()) != EOF) {
        /* Print a newline after the user's input. */
        if(first == 0) {
          printf("\n");
          first = 1;
        }
        /* do something here */
    }
}

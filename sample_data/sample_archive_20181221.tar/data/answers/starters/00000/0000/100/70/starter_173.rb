myf   =  1.9
yourf = -1.9
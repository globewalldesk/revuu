arr = [1, 4, 'four', 6, 2, 7, 11, 'foo?']

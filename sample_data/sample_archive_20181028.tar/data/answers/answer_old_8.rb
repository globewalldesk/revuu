str = "Encyclopaedias make me feel so anaemic that I need anaesthesia."
puts str.gsub!('ae', 'e')



###########################################################################



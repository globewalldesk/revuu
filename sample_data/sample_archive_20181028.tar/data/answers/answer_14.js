console.log("Band-Aid\u00AE 98.6\u00B0F"); // Unicode = 16-bit hex
console.log("Band-Aid\xAE 98.6\xB0F");     // Hex = 8-bit hex
console.log("\u0048\u0049");
console.log("\x48\x49");

const words = {
  'fallacious': 'not logically valid',
  'omniscient': 'all-knowing',
  'axiomatic': 'taken for granted in a deductive system'
};

const {'fallacious': f, 'omniscient': o, 'axiomatic': x} = words;

var multipleChoice = (a, b, c) =>
  console.log("What is the definition of 'fallacious'?\n(a) " + a + "\n(b) " +
    b + "\n(c) " + c);

multipleChoice(f,o,x);
console.log("")

// rewrite multipleChoice slightly here
multipleChoice = ({'fallacious':a, 'omniscient':b, 'axiomatic':c}) =>  // edit this
  console.log("What is the definition of 'fallacious'?\n(a) " + a + "\n(b) " +
    b + "\n(c) " + c);

multipleChoice(words);
console.log("")

const motion = {
  start: { x: 0, y: 0},
  beginning: {x: 1, y: 3},
  middle: {x: 3, y: 10},
  almostend: {x: 6, y: 11},
  end: {x: 10, y: 12}
};

// startx and starty code
const {start: {x: startX}, end: {y: startY}} = motion;
console.log(startX, startY);

// x array code
const {
  beginning:  {x: bX},
  middle:     {x: mX},
  almostend:  {x: aX},
  end:        {x: eX}
} = motion;
const xVals = [startX, bX, mX, aX, eX];
console.log(xVals);

// destructure the x array two ways
const [st, be] = xVals;
const [aa, , cc, , ee] = xVals
console.log(st, be);
console.log(aa, cc, ee);

// finally, use the rest operator on the x array
const [aaa, bbb, ...the_rest] = xVals;
console.log(the_rest);

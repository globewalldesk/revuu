bytes = File.stat("../../revuu.rb").size
puts bytes
kb = bytes/1024.0
puts kb
puts kb.round
puts kb.round(2)

var num = 10;
console.log(num++ - 10); // 0
num = 10;
console.log(++num - 10); // 1
num = 1;
console.log(--num + 10); // 10
num = 1;
num2 = (num++ * 10 + 1);
console.log(num2);       // 11



console.log(' ')
//////////////////////////////////////////////////////////////////////////


var myNum = 10;
console.log(myNum++ - 10); // 0
console.log(myNum);        // 11
myNum = 10;
console.log(++myNum - 10); // 1
console.log(myNum);        // 11
myNum = 1;
console.log(--myNum + 10); // 10
num = 1
num2 = (num++ * 10 + 1);
console.log(num2);         // 11



//////////////////////////////////////////////////////////////////////////



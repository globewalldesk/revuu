echo "From fairest creatures we desire increase," > poem.txt
echo "That thereby beauty's rose might never die," >> poem.txt
cat poem.txt
ls -ltr poem.txt
rm poem.txt
ls -ltr poem.txt

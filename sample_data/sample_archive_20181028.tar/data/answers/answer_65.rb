str = "hello world"
# Replace the following.
p str.chars

const createCar = (make, model, year) => ({make,model,year});
console.log(createCar('Toyota', 'Highlander', 2018)); // returns a proper object

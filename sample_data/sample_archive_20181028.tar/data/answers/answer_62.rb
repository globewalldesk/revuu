class Array
  def map_odd
    self.map.each_with_index {|x,i| i.odd? ? yield(x) : x}
  end
end

az = [*('a'..'g')]
nums = [*(1..10)]
p az.map_odd(&:upcase)
p nums.map_odd(&:*)

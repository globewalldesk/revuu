words = {
  'fallacious': 'not logically valid',
  'omniscient': 'all-knowing',
  'axiomatic': 'taken for granted in a deductive system'
};

const {fallacious: word1, omniscient: word2, axiomatic: word3} = words;

var multipleChoice = (a, b, c) =>
  console.log("What is the definition of 'fallacious'?\n(a) " + a + "\n(b) " +
    b + "\n(c) " + c);

multipleChoice(word1, word2, word3);

// rewrite multipleChoice slightly here
multipleChoice = ({fallacious: a, omniscient: b, axiomatic: c}) =>  // edit this
  console.log("What is the definition of 'fallacious'?\n(a) " + a + "\n(b) " +
    b + "\n(c) " + c);

multipleChoice(words);

const motion = {
  start: { x: 0, y: 0},
  beginning: {x: 1, y: 3},
  middle: {x: 3, y: 10},
  almostend: {x: 6, y: 11},
  end: {x: 10, y: 12}
};

// startx and starty code
const {start: {x: startX, y: startY}} = motion;
printCoords = (x,y) => console.log(x, y);
printCoords(startX, startY);

// x array code
const { beginning: {x: beginX},
        middle: {x: middleX},
        almostend: {x: almostendX},
        end: {x: endX}
      } = motion;
const xArray = [startX, beginX, middleX, almostendX, endX];
console.log(xArray);

// destructure the x array two ways
const [a, b] = xArray;
console.log(a, b);
const [x, , y, , z] = xArray;
console.log(x,y,z);

// finally, use the rest operator on the x array
const [p, q, ...the_rest] = xArray;
console.log(the_rest);



console.log(' ')
//////////////////////////////////////////////////////////////////////////



class MyClass
  class << self
    def class_number; 5; end

    def class_number_deux; 2; end

    def create_with_num
      # Type here
    end
  end

  attr_accessor :number

  def initialize(args)
    # Type here
  end

  def instance_number; 10; end

  def my_sum
    # Type here
  end

end

def global_number; 10; end
# Type here

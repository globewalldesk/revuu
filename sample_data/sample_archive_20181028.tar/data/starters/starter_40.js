const LoveMyFunction = function() {
  return "This is really nice function, isn't it?"
}

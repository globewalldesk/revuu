function createCar (make, model, year) {
  make: make,
  model: model,
  year: year
};
console.log(createCar('Toyota', 'Highlander', 2018)); // returns a proper object
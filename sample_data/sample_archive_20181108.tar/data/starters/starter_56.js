const Faves = { fruit: 'apple', music: 'Irish trad', prog_lang: 'Ruby' };
const fruit = Faves.fruit;
const music = Faves.music;
const prog_lang = Faves.prog_lang;

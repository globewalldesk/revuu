a = nil
until a == 'q'
  print "Enter a numeric sort of string for fun! "
  a = gets.chomp
end

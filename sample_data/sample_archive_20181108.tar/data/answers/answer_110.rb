A = [1, 2, 3, 4]
B = [2, 3, 3, 4, 5, 6]
C = ['Beetlejuice']
D = [:a, :b, :c]
E = [:d, :e, :f]
F = ['a', 'b', 'c', 'd', 'e']
G = ['b', 'd']
p D + E
p A & B
p C * 3
p F - G

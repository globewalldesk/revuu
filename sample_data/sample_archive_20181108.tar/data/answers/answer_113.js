function funkShun() {
  console.log("I can't actually access your new property easily...");
}
funkShun.prop = "I am not a property."
funkShun();
console.log(funkShun.prop);
require 'date'
meths = DateTime.now.methods
p meths.count {|m| Time.new.respond_to? m}



puts ''
#####################################



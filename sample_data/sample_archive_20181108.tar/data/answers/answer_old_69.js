const words = {
  'fallacious': 'not logically valid',
  'omniscient': 'all-knowing',
  'axiomatic': 'taken for granted in a deductive system'
};

const {fallacious, omniscient, axiomatic} = words;

var multipleChoice = (a, b, c) =>
  console.log("What is the definition of 'fallacious'?\n(a) " + a + "\n(b) " +
    b + "\n(c) " + c);

multipleChoice(fallacious, omniscient, axiomatic);
console.log("")

// rewrite multipleChoice slightly here
multipleChoice = ({fallacious, omniscient, axiomatic}) =>  // edit this
  console.log("What is the definition of 'fallacious'?\n(a) " + fallacious +
    "\n(b) " + omniscient + "\n(c) " + axiomatic);

multipleChoice(words);
console.log("")

const motion = {
  start: { x: 0, y: 0},
  beginning: {x: 1, y: 3},
  middle: {x: 3, y: 10},
  almostend: {x: 6, y: 11},
  end: {x: 10, y: 12}
};

// startx and starty code

const {start: {x: startX, y: startY}} = motion;
console.log(startX, startY);

// x array code
const {
  beginning: {x: bx},
  middle: {x: mx},
  almostend: {x: ax},
  end: {x: ex}
} = motion;
const xs = [startX, bx, mx, ax, ex];
console.log(xs);

// destructure the x array two ways
const [first, second] = xs;
console.log(first, second);
const[one,, three,, five] = xs;
console.log(one, three, five);

// finally, use the rest operator on the x array
const [foo, bar, ...rest] = xs;
console.log(rest);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


const words = {
  'fallacious': 'not logically valid',
  'omniscient': 'all-knowing',
  'axiomatic': 'taken for granted in a deductive system'
};

const {'fallacious': f, 'omniscient': o, 'axiomatic': x} = words;

var multipleChoice = (a, b, c) =>
  console.log("What is the definition of 'fallacious'?\n(a) " + a + "\n(b) " +
    b + "\n(c) " + c);

multipleChoice(f,o,x);
console.log("")

// rewrite multipleChoice slightly here
multipleChoice = ({'fallacious':a, 'omniscient':b, 'axiomatic':c}) =>  // edit this
  console.log("What is the definition of 'fallacious'?\n(a) " + a + "\n(b) " +
    b + "\n(c) " + c);

multipleChoice(words);
console.log("")

const motion = {
  start: { x: 0, y: 0},
  beginning: {x: 1, y: 3},
  middle: {x: 3, y: 10},
  almostend: {x: 6, y: 11},
  end: {x: 10, y: 12}
};

// startx and starty code
const {start: {x: startX}, end: {y: startY}} = motion;
console.log(startX, startY);

// x array code
const {
  beginning:  {x: bX},
  middle:     {x: mX},
  almostend:  {x: aX},
  end:        {x: eX}
} = motion;
const xVals = [startX, bX, mX, aX, eX];
console.log(xVals);

// destructure the x array two ways
const [st, be] = xVals;
const [aa, , cc, , ee] = xVals
console.log(st, be);
console.log(aa, cc, ee);

// finally, use the rest operator on the x array
const [aaa, bbb, ...the_rest] = xVals;
console.log(the_rest);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


words = {
  'fallacious': 'not logically valid',
  'omniscient': 'all-knowing',
  'axiomatic': 'taken for granted in a deductive system'
};

const {fallacious: word1, omniscient: word2, axiomatic: word3} = words;

var multipleChoice = (a, b, c) =>
  console.log("What is the definition of 'fallacious'?\n(a) " + a + "\n(b) " +
    b + "\n(c) " + c);

multipleChoice(word1, word2, word3);

// rewrite multipleChoice slightly here
multipleChoice = ({fallacious: a, omniscient: b, axiomatic: c}) =>  // edit this
  console.log("What is the definition of 'fallacious'?\n(a) " + a + "\n(b) " +
    b + "\n(c) " + c);

multipleChoice(words);

const motion = {
  start: { x: 0, y: 0},
  beginning: {x: 1, y: 3},
  middle: {x: 3, y: 10},
  almostend: {x: 6, y: 11},
  end: {x: 10, y: 12}
};

// startx and starty code
const {start: {x: startX, y: startY}} = motion;
printCoords = (x,y) => console.log(x, y);
printCoords(startX, startY);

// x array code
const { beginning: {x: beginX},
        middle: {x: middleX},
        almostend: {x: almostendX},
        end: {x: endX}
      } = motion;
const xArray = [startX, beginX, middleX, almostendX, endX];
console.log(xArray);

// destructure the x array two ways
const [a, b] = xArray;
console.log(a, b);
const [x, , y, , z] = xArray;
console.log(x,y,z);

// finally, use the rest operator on the x array
const [p, q, ...the_rest] = xArray;
console.log(the_rest);



console.log(' ')
//////////////////////////////////////////////////////////////////////////



console.log("yo");
console.clear();
console.log("I cleared it!");
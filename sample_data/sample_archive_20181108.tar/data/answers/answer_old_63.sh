echo zipping up...
zip -r starters.zip ../starters
echo unzipping to new directory..
unzip -: starters.zip -d starters/
ls -lh starters.zip
ls -lh starters/
echo removing...
rm starters.zip
rm -rf starters/
echo proof it is gone...
ls -lh starters.zip
ls -lh starters/



echo '<--spacer-->'
#####################################


zip -r starters.zip ../starters
unzip -: starters.zip
ls -lhR starters*
rm starters.zip
rm -rf ./starters
ls -lhR starters*



echo '<--spacer-->'
#####################################


zip -v starters.zip ../starters/*
ls -ltr starters.zip
unzip -: starters.zip -d starters
ls -ltr starters/
rm -v starters.zip
rm -rvf starters



echo '<--spacer-->'
#####################################


zip starters.zip ../starters/*
ls -ltr starters.zip
unzip -: starters.zip -d starters
ls -ltr starters
rm starters.zip
rm -rf starters


echo '<--spacer-->'
#####################################


zip -r tester.zip ../starters
sleep 1
ls -ltr tester.zip
sleep 1
unzip -: tester.zip -d starters
sleep 1
ls -ltr starters
rm tester.zip
rm -rf starters


echo '<--spacer-->'
#####################################



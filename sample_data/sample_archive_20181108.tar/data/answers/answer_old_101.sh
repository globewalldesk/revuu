ls -lah /opt
sudo touch /opt/foo
ls -lah /opt
sudo rm /opt/foo
ls -lah /opt



echo '<--spacer-->'
#####################################



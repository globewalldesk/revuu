grep -i rose sonnets.txt | wc



echo '<--spacer-->'
#####################################


grep -i rose sonnets.txt | wc



echo '<--spacer-->'
#####################################



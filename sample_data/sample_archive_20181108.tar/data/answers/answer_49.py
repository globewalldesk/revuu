print "Hello world!";

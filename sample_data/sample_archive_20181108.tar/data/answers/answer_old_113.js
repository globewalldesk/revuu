function funkShun() {
  console.log("I can't actually access your new property easily...");
}
funkShun.fun = "Whee!"
funkShun();
console.log(funkShun.fun);



console.log(' ')
//////////////////////////////////////////////////////////////////////////



cd ../.. && tail -f yahoo.log

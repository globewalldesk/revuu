class SortedArray < Array
  def initialize(args)
    super(args)
    self.sort!
  end

  def double_elements
    self.map! {|x| x*2}
  end
end

arr = SortedArray.new([2, 1, 3])
p arr
p arr.reverse
p arr.double_elements
arrb = SortedArray.new(['3', 'b', 'z', 'C', '23'])
p arrb
p arrb.double_elements

echo No directories:
ls -ld */
echo Zipping...
zip -rq starters.zip "../starters"
echo Now there is a zip file
ls -l starters.zip
echo Unzipping...
unzip -:q starters.zip -d starters/
echo Now there is a starter directory
ls -ld starters/
echo with how many files?
ls -l | wc -l
echo Removing files and folder
rm starters.zip
rm -rf starters/
echo all gone!
ls -ld */

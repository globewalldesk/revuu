foo = :george
bar = foo
puts "#{foo.object_id} =? #{bar.object_id}" # Obvs true.
str = 'hi'
str2 = str
puts "#{str.object_id} =? #{str2.object_id}" # Thought false; but true.
str = 'yo'
puts str2
puts "#{str.object_id} =? #{str2.object_id}" # Not sure; but false.
str3 = 'hi'
str4 = 'hi'
puts "#{str3.object_id} =? #{str4.object_id}" # Obvs false.
arr = [1,2,3]
arr2 = arr
puts "#{arr.object_id} =? #{arr2.object_id}" # Obvs true.
arr[1] = 'a gazillion'
p arr2 # [1, 'a gazillion', 3]
hashy = {foo: 1, bar: 2}
hashy2 = hashy
puts "#{hashy.object_id} =? #{hashy.object_id}" # Obvs true.
hashy[:foo] = 123
p hashy2 # Defo changed
arr = [1,2,3]
arrdup = arr.dup
arrclone = arr.clone
arr[2] = 'a godawful lot'
p arr # changed
p arrdup # unchanged
p arrclone # unchanged



puts ''
#####################################


sim = :symbol
simeq = sim
print sim.object_id
print ' '
print simeq.object_id # Obv. the same
puts ''

str = 'yo'
str2 = str
print str.object_id
print ' '
print str2.object_id # Same
print ' '
str3 = 'yo'
print str3.object_id # Defo diff
puts ''

num = 1
num2 = num
print num.object_id
print ' '
print num2.object_id # Same
print ' '
num3 = 1
print num3.object_id # Same
puts ''

puts "arr:"
arr = [0, 1, 2]
arr2 = arr
print arr.object_id
print ' '
print arr2.object_id # Defo same
print ' '
arr3 = [0, 1, 2]
print arr3.object_id # Difo diff
puts ''

simd = sim.dup
simc = sim.clone
puts "#{simd.object_id} #{simc.object_id}" # Obvs same.

strd = str.dup
strc = str.clone
puts "#{strd.object_id} #{strc.object_id}" # ? Turns out to be diff!

arrd = arr.dup
arrc = arr.clone
puts "#{arrd.object_id} #{arrc.object_id}" # ?? Turns out to be diff!



puts ''
#####################################



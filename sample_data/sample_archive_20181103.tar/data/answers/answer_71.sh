echo "From fairest creatures we desire increase," > foo.txt
echo "That thereby beauty's rose might never die," >> foo.txt
cat foo.txt
rm foo.txt

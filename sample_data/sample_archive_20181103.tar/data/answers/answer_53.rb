a = :foo
b = a
puts "#{b.object_id == a.object_id}" # same obvs
s1 = 'string'
s2 = s1
puts "#{s1.object_id == s2.object_id}" # same
n1 = 1
n2 = n1
puts "#{n1.object_id == n2.object_id}" # same
a1 = [1, 2, 3]
a2 = a1
a2[2] = 30_000_000
p "Now a1 = #{a1}"
puts "#{a1.object_id == a2.object_id}" # same
h1 = {foo: 1, bar: 2}
h2 = h1
puts "#{h1.object_id == h2.object_id}" # same

s3 = 'string'
puts "#{s1.object_id == s3.object_id}" # diff
n3 = 1
puts "#{n1.object_id == n3.object_id}" # same
a3 = [1, 2, 3]
puts "#{a1.object_id == a3.object_id}" # diff
h3 = {foo: 1, bar: 2}
puts "#{h1.object_id == h3.object_id}" # diff

s1 = 'changed'
n1 = 2
a1 = []
h1 = {baz: 3}
puts "#{s1.object_id == s2.object_id}" # diff
p s1
p s2
puts "#{n1.object_id == n2.object_id}" # diff obvs
p n1
p n2
puts "#{a1.object_id == a2.object_id}" # diff
p a1
p a2
puts "#{h1.object_id == h2.object_id}" # diff NOTE: values same as orig
p h1
p h2

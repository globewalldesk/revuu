cd
pwd

tail -f yahoo.log
rm yahoo.log

echo "no directories or subdirectories"
ls -d */ */*/
echo ""
mkdir -p foo/bar/
echo "now there's some"
ls -d */ */*/
rm -rf foo/
echo ""
echo "no directories or subdirectories"
ls -d */ */*/

arr = Dir["*"]
p arr

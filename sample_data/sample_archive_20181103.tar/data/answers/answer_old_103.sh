find ../../* -name '*.rb' ! -name 'starter*' ! -name 'answer*'



echo '<--spacer-->'
#####################################



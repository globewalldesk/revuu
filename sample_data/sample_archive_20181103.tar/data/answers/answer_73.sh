echo "hello, world" > foo.txt
cat foo.txt > bar.txt
echo foo.txt:
cat foo.txt
echo bar.txt:
cat bar.txt
ls -lah foo.txt bar.txt
rm foo.txt bar.txt
ls -lah foo.txt bar.txt

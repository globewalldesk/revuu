
// SpaceShuttle:
var SpaceShuttle = function(name, targetPlanet) {return {name, targetPlanet}}

var ares = new SpaceShuttle("Ares", "Mars") // call it
console.log(`Shuttle ${ares.name} is going to ${ares.targetPlanet}.`)

// SpaceShuttle2:
class SpaceShuttle2 {
  constructor(targetPlanet, name) {
    this.name = name;
    this.targetPlanet = targetPlanet;
  }
}

const zeus = new SpaceShuttle2("Zeus", "Jupiter") // call it
console.log(`Shuttle ${zeus.name} is going to ${zeus.targetPlanet}.`)



console.log(' ')
//////////////////////////////////////////////////////////////////////////



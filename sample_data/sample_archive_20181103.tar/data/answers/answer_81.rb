class SortedArray < Array
  def initialize(args)
    super(args)
    self.sort!
  end
  def reverse
    self.reverse!
  end
end
sa = SortedArray.new(10) {|o| rand(o)}
p sa
p sa.reverse

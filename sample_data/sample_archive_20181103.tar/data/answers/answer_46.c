#include <stdio.h>
int main() {
  char c = 'a';
  int i = 1;
  float f = 1.234;
  double d = 123412312352352351235125323.12342314121;
  short int si = 100;
  long int li = 1000000000000000000;
  printf("%c %i %f\n", c, i, f);
  printf("%f %i %li\n", d, si, li);
}

pwd
cd ..
pwd
cd ..
pwd
cd ..
pwd
cd -

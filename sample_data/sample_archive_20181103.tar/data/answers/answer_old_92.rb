lines = File.readlines(__FILE__)
puts "The last line of this file is:\n#{lines[-1]}"
puts "This is a file I am enjoying reading, to be honest."
puts "And now you've come to the end of it. Too bad!"



puts ''
#####################################



numbers = []
three_ones = [1, 1, 1]
10.times do |i|
  numbers << i
  i += 1
end
print numbers #=> [1, 1, 1, 3, 5, 7, 9]
puts ''

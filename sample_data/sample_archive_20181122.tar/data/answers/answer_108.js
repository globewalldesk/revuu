console.log('foo');
console.clear();
console.log("cleared what was formerly printed");

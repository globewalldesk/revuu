arr = [1, 2, "foo", 3, 4, "bar", 5, 6, "baz"]
cuber = Proc.new {|n| n.class == Integer ? n**3 : n}
p arr.map(&cuber)
p cuber.call(3) # 27

arr = %w($0.99 $0.50 $9.99 $1.99 $5.00 $3.99 $10.01)
p arr.find_index('$1.99')
p arr.pop
p arr.shift
p arr.push('$4.00')
p arr.unshift('$0.01')

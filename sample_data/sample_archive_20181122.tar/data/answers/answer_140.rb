arr = ['eeeee!', 'bb', 'aaa', 'the eagle has landed', 'hello', 'zed', 'goll dang']
puts "length: " + arr.sort {|x,y| x.length <=> y.length}.inspect
puts "alpha: " + arr.sort {|x,y| x<=>y}.inspect
puts "number of e: " + arr.sort {|x| x.split('').count{|l| l == 'e'}}.inspect

#include <stdio.h>

int main() {
    printf("\n====Counter of Almost Everything====\n");
    int blanks, tabs, newlines, characters;
    blanks = 0;
    tabs = 0;
    newlines = 0;
    characters = 0;
    char c;
    while((c = getchar()) != EOF) {
        if(c == '\n') ++newlines;
        else if(c == '\t') ++tabs;
        else if(c == ' ') ++blanks;
        else characters++;
    }
    printf("\n=========================\n");
    printf("%d characters | %d newlines\n", characters, newlines);
    printf("%d tabs | %d spaces \n", tabs, blanks);
}

Car = Struct.new(:make, :model, :year)
mine = Car.new('Toyota', 'Highlander', '2018')
momold = Car.new('AMC', 'Eagle', '1982')
dadold = Car.new('Datsun', 'pickup', '1978')

def car_reporter(car)
  puts "Make: " + car.make
  puts "Model: " + car.model
  puts "Year: " + car.year
  puts ''
end

[mine, momold, dadold].each {|c| car_reporter(c)}

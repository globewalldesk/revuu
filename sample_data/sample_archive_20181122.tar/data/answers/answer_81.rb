class SortedArray < Array
  def initialize(arr)
    self << arr
    super
    self.sort!
  end
end
arr = SortedArray.new([5, 3, 6, 1, 8, 4])
p arr
p arr.reverse!
p arr.map {|n| n + 2}
p arr.class

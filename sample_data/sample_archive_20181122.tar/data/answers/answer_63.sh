ls -d */ */*/
zip -q starters.zip -r ../starters
unzip -q starters.zip -d starters
ls -d */ */*
ls starters/*
rm -rf starters.zip starters/
ls -d */ */*/

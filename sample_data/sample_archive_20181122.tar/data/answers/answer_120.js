str = 'hello world';
str = 'hello world';
console.log(str.substring(0,5)); // 'hello'
console.log(str.substr(0,5)); // 'hello'
console.log(str.substring(3,5)); // 'lo'
console.log(str.substr(3,2)); // 'lo'
console.log(str.substring(6)); // 'world'
console.log(str.substr(6,11)); // 'world'

 p Dir["*"]

echo no dirs
ls -dl */ */*/
mkdir -p foo/bar/
echo now two dirs
ls -dl */ */*/
rm -rf foo/
echo no dirs
ls -dl */ */*/



echo '<--spacer-->'
#####################################


ls -d */ */*/
mkdir -p foo/bar
ls -d */ */*/
rm -rf foo/
ls -d */ */*/



echo '<--spacer-->'
#####################################


echo "no directories or subdirectories"
ls -d */ */*/
echo ""
mkdir -p foo/bar/
echo "now there's some"
ls -d */ */*/
rm -rf foo/
echo ""
echo "no directories or subdirectories"
ls -d */ */*/



echo '<--spacer-->'
#####################################


ls -d */
mkdir -p foo/bar/
ls -d */
ls -d */*
rm -rf foo
ls -d */



echo '<--spacer-->'
#####################################



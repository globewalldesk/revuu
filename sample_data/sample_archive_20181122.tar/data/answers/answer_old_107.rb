system("psql") #  -d testdb -U lsanger -W



puts ''
#####################################



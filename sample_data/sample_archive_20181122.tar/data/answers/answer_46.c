#include <stdio.h>

int main() {
  char c    = 'a';
  int i     = 1;
  float f   = 1.1;
  double d  = 123456789.123456;
  short s   = 32767;
  long l    = 2147483647;
  printf("%c | %i | %f | %lf\n", c, i, f, d);
  printf("%i | %li\n", s, l);
}

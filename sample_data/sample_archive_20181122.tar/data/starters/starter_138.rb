def car_reporter(car)
  puts "Make: " + car.make
  puts "Model: " + car.model
  puts "Year: " + car.year
  puts ''
end

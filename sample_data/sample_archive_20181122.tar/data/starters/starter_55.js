const arr = [2, 4, 8, 16, 32];
const maximum = Math.max(arr);
console.log(maximum);
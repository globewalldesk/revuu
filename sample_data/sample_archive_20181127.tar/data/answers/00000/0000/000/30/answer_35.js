var glob = 'global scope';
function checkScope() {
"use strict";
  let i = "function scope";
  if (true) {
    let i = "block scope";
    console.log("i is: ", i);
  }
  console.log("i is: ", i);
  console.log("glob inside the function is: ", glob);
  return i;
}
checkScope();
console.log("glob outside the function is: ", glob);
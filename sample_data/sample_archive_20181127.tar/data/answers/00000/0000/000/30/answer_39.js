const obby = {one: 1, two: 2};
Object.freeze(obby);
console.log(obby.one);
obby.one = 'one';
console.log(obby.one);

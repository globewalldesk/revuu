puts "Encyclopaedias make me feel so anaemic that I need anaesthesia.".
  gsub!('ae', 'e');



puts ''
#####################################


str = "Encyclopaedias make me feel so anaemic that I need anaesthesia."
puts str.gsub!('ae', 'e')



###########################################################################



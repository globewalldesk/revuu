dog_breeds = {
  'Lassie' => 'Collie',
  'Rex' => 'German Shepherd',
  'Bobo' => 'Poodle'
}
dog_breeds.default = 'mutt'
names = ['Lassie', 'Bobo', 'Sheba', 'Foxy', 'Rex']
names.each {|nm| puts "#{nm}: #{dog_breeds[nm]}"}

friends = ['Jack', 'Jill', 'Sam']

def yo(greeting, jack, jill, sam)
  [jack, jill, sam].each { |friend| puts "#{greeting}, #{friend}!" }
end

# Call yo
yo("Greetings", *friends)
arr = ['a', 'b', 'c', 'd']
first, *the_rest = arr
puts "I really like #{first}, but as to #{the_rest.join(", ")}...they're OK."

require 'date'
now = DateTime.now
p now.to_s
fut = now + 7
puts "In a week it will be #{fut.strftime("%-m/%-d/%Y")}."
twohours = now + (2/24.0)
puts "In two hours it will be #{twohours.strftime("%l:%M %p")}."

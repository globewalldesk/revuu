const factorial = (arr) =>
  arr.reduce((x,y) =>
    x * y);

arr = [5, 4, 3, 2, 1];
console.log(factorial(arr));



console.log(' ')
//////////////////////////////////////////////////////////////////////////


const factorial = (arr) =>
  arr.reduce((x,y) => x * y)

const arr = [5, 4, 3, 2, 1];
console.log(factorial(arr));


console.log(' ')
//////////////////////////////////////////////////////////////////////////


const factorial = (arr) =>
  arr.reduce((x,y) => x * y)

arr = [1, 2, 3, 4, 5];
console.log(factorial(arr));


console.log(' ')
//////////////////////////////////////////////////////////////////////////


const factorial = (arr) =>
  arr.reduce((x,y) => x * y)
arr = [5,4,3,2,1];
console.log(factorial(arr));


//////////////////////////////////////////////////////////////////////////



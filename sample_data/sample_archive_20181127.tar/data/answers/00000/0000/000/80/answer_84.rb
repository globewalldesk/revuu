require 'date'
p (Time.instance_methods & DateTime.instance_methods).length

nums = Hash.new {|hash,key| hash[key] = 1}
1000000.times {num = rand(10)+1; nums[num] += 1}
puts "oh no" if nums.keys.any? {|k| k.class != Integer}
nums.keys.sort.each {|k| percent = (nums[k]/10000.0).round(2); puts "#{k}: #{nums[k]} (#{percent}%)"}

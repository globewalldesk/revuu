str = "Hello, world!"
 p str.split
 p str.split()
# p str.split('')
# p str.split(//)
p str.split(' ')

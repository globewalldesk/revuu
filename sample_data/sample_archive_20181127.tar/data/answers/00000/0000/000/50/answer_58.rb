class Integer
  def factorial_minus_triangle
    [*(1..self)].reduce(:*) - [*(1..self)].reduce(:+)
  end
end

p 4.respond_to? :factorial_minus_triangle

arr = []
1.upto(10) {|x| arr << x.factorial_minus_triangle}
p arr

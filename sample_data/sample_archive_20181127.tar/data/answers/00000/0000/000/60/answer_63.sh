ls -lh
zip -q starters.zip -r ../../../../../starters
ls -lh
unzip -q starters.zip -d starters
find starters/* -name starter_*
rm starters.zip
rm -rf starters
ls -lh

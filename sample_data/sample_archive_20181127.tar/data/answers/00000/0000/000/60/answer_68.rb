def triple
  3 * yield
end

p triple {9} # 27

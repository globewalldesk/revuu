ls -d */ */*/
mkdir -p foo/bar
ls -d */ */*/
rm -rf foo/
ls -d */ */*/

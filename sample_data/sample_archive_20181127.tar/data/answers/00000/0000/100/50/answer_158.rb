lengths = Hash.new do |hash,key|
  hash[key] = key.length
end
lengths['a'] = 1
lengths['foobar']
lengths['Jehosaphat']
p lengths

foods = Hash.new {|h,k| h[k] = []}
foods['p'] << 'pie' << 'pasta'
foods['a'] << 'apple' << 'apricot'
p foods

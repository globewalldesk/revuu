class Person
  attr_accessor :name, :age, :occupation

  def initialize(name, data)
    @name = name
    @age = data[:age]
    @occupation = data[:occupation]
  end

  def resume
    puts "Name: " + @name
    puts "Age: " + @age.to_s
    puts "Occupation: " + @occupation
  end
end

dude = Person.new("Lebowski", occupation: 'Dude', age: 48)

dude.resume



puts ''
#####################################



def get_ten
  nums = []
  10.times {nums << rand(10) + 1} # Get ten random integers.
  nums
end

class Array
  def average
    begin
      self.reduce(:+) / self.size.to_f
    rescue StandardError => err
      puts "Your array contained a non-number: #{err}"
    end
  end
end

counts = []
10.times {counts << get_ten.count{|n| n.odd?}}
p counts.average

counts = []
100.times {counts << get_ten.count{|n| n.odd?}}
p counts.average

counts = []
1000.times {counts << get_ten.count{|n| n.odd?}}
p counts.average

counts = []
10000.times {counts << get_ten.count{|n| n.odd?}}
p counts.average

p ['a', 2, 3, 4].average

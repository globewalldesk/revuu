#include <stdio.h>

int main() {
  double nc;
  int c;
  nc = 0;
  while ((c = getchar()) != EOF) {++nc;};
  printf("\n==============\n%.0f characters\n", nc);
}

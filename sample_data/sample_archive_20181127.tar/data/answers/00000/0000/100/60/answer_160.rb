arr = [1, 'a', 2, 'b', 3, 'c']
p arr.map(&:next)
p arr.find_all {|n| n.class == Integer}


module Bipedal
  def two_legs(name)
    puts "#{name} has exactly two limbs used for walking."
  end
end

class Person
  def two_legs(name)
    puts "#{name} has two human legs."
  end
end

class Boy < Person
  include Bipedal
  Bipedal.send(:remove_method, :two_legs)
  # Another possibility
  # Boy.superclass.instance_method(:two_legs).bind(self).call(@name)

  attr_accessor :name
  def initialize(name)
    @name = name
  end

  def two_legs
    super(@name)
  end
end

eddie = Boy.new('Eddie')
eddie.two_legs

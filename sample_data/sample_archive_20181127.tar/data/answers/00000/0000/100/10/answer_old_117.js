const h = require("./helpers.js");

var text = "Domo arigato!";
h.report("Before defining functions...");

// useless() goes here.

function getText() {
  h.report("In getText function...");
  return text;
}

function useless(funk) {
  h.report("I'm in useless(), dudez!");
  return funk();
}

h.report("Before making all the calls...");

// Make the following true!
h.assert(useless(getText) === text, "The useless function works: " +
  useless(getText));

h.report("After the calls have been made. Done!")



console.log(' ')
//////////////////////////////////////////////////////////////////////////


const h = require("./helpers.js");

var text = "Domo arigato!";
h.report("Before defining functions...");

// useless() goes here.
function useless(funk) {
  h.report("In useless function...")
  return funk();
}

function getText() {
  h.report("In getText function...");
  return text;
}

h.report("Before making all the calls...");

// Make the following true!
h.assert(useless(getText) === text, "The useless function works: " + useless(getText));

h.report("After the calls have been made. Done!")



console.log(' ')
//////////////////////////////////////////////////////////////////////////


const h = require("./helpers.js");

var text = "Domo arigato!";
h.report("Before defining functions...");

function useless(funk) {
  h.report("I'm in the useless function...");
  return funk();
}

function getText() {
  h.report("In getText function...");
  return text;
}

h.report("Before making all the calls...");

// Make the following true!
h.assert(useless(getText) === text, "The useless function works: " + useless(getText));

h.report("After the calls have been made. Done!")


console.log(' ')
//////////////////////////////////////////////////////////////////////////



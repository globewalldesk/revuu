function funkShun() {
  console.log("I can't actually access your new property easily...");
}
funkShun.prop = "Foo Bar";
funkShun();
console.log(funkShun.prop);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


function funkShun() {
  console.log("I can't actually access your new property easily...");
}
funkShun.prop = "foobar";
funkShun();
console.log(funkShun.prop);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


function funkShun() {
  console.log("I can't actually access your new property easily...");
}
funkShun.prop = "I am not a property."
funkShun();
console.log(funkShun.prop);


console.log(' ')
//////////////////////////////////////////////////////////////////////////


function funkShun() {
  console.log("I can't actually access your new property easily...");
}
funkShun.fun = "Whee!"
funkShun();
console.log(funkShun.fun);



console.log(' ')
//////////////////////////////////////////////////////////////////////////



module KlassModule
  def speak
    puts 'Woof! Woof!'
  end
end

class Klass
  include KlassModule
end

Klass.new.speak

count = 0

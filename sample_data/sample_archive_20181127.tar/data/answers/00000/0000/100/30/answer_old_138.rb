Car = Struct.new(:make, :model, :year)

def car_reporter(*cars)
  cars.each do |car|
    puts "Make: " + car.make
    puts "Model: " + car.model
    puts "Year: " + car.year
  end
end

mine = Car.new('Toyota', 'Highlander', '2018')
mikes = Car.new('Chevy', 'Suburban', '1992')
dads = Car.new('Datsun', 'Pickup', '1978')

car_reporter(mine, mikes, dads)
puts ''



puts ''
#####################################


Car = Struct.new(:make, :model, :year)
mine = Car.new('Toyota', 'Highlander', '2018')
momold = Car.new('AMC', 'Eagle', '1982')
dadold = Car.new('Datsun', 'pickup', '1978')

def car_reporter(car)
  puts "Make: " + car.make
  puts "Model: " + car.model
  puts "Year: " + car.year
  puts ''
end

[mine, momold, dadold].each {|c| car_reporter(c)}



puts ''
#####################################



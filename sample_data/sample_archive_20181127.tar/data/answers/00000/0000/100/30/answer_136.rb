leaders = {
  Pericles: 'Athens',
  "Marcus Aurelius": 'Rome',
  "Genghis Khan": 'Mongolia',
  "George Washington": 'United States',
  Hitler: 'Germany',
  "Pol Pot": 'Cambodia'
}
leaders.delete(:"Genghis Khan")
leaders.delete(:Hitler)
leaders.delete(:"Pol Pot")
p leaders

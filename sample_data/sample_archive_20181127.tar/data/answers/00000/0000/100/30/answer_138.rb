Car = Struct.new(:make, :model, :year)
def car_reporter(car)
  puts "Make: " + car.make
  puts "Model: " + car.model
  puts "Year: " + car.year
  puts ''
end
mine = Car.new('Toyota', 'Highlander', "2018")
fred = Car.new('StoneAge', 'Footer', "12456 BC")
george = Car.new('Jetter', 'Jet', "12352")
[mine, fred, george].each {|x| car_reporter(x)}

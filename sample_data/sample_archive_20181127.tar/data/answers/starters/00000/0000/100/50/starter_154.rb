class Person
  attr_accessor :name, :age, :nationality

  def initialize(name, #FINISH THIS )
    @name = name
    # FINISH THIS
  end

  def profile
    puts "Name: " + @name
    puts "Sex: " + @sex
    puts "Nationality: " + @nationality
  end
end

# Create...

# Call...

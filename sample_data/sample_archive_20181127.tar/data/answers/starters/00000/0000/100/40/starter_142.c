#include <stdio.h>

int main() {
  double nc;
  printf("\n==============\n%.0f characters\n", nc);
}
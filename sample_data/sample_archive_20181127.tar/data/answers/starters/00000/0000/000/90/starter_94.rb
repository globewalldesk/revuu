class Animal
  attr_reader :name, :living

  def initialize(name)
    @name = name
    @living = true
  end

  def makes_noise
    puts "#{@name} growls!"
  end
end
leo = Animal.new('Leo')
leo.makes_noise

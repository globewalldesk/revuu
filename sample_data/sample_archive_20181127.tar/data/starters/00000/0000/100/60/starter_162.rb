arr = [1, 2, 3]
p arr
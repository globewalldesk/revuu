module Bipedal
  def two_legs(name)
    "#{name} has exactly two limbs used for walking."
  end
end

class Person
  def two_legs(name)
    "#{name} has two human legs."
  end
end

class Boy < Person
  include Bipedal
end

const h = require("../../../../helpers.js");

var text = "Domo arigato!";
h.report("Before defining functions...");

// useless() goes here.

function getText() {
  h.report("In getText function...");
  return text;
}

h.report("Before making all the calls...");

// Make the following true!
h.assert(useless(getText) === text, "The useless function works: " + useless(getText));

h.report("After the calls have been made. Done!")

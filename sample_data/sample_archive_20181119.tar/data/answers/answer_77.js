const person = {
  name: 'John Doe',
  sayHello() {
    return `Hello! My name is ${this.name}.`;
  }
};
console.log(person.sayHello());

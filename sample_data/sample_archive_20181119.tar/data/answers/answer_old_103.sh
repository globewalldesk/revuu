find ../.. -name '*.rb' ! -name 'answer*' ! -name 'starter*'


echo '<--spacer-->'
#####################################


find ../.. -name '*.rb' ! -name 'answer*' ! -name 'starter*'



echo '<--spacer-->'
#####################################


find ../../* -name '*.rb' ! -name 'answer*' ! -name 'starter*'



echo '<--spacer-->'
#####################################


find ../../* -name '*.rb' ! -name 'starter*' ! -name 'answer*'



echo '<--spacer-->'
#####################################



module KlassModule
  def speak
    puts 'Woof! Woof!'
  end
end

class Klass
  extend KlassModule
end

Klass.speak



puts ''
#####################################


module KlassModule
  def speak
    puts 'Woof! Woof!'
  end
end

class Klass
  extend KlassModule
end

Klass.speak



puts ''
#####################################



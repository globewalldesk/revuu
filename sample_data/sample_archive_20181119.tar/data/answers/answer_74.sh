tail -f wiki.log

class Integer
  def factorial_minus_triangle
    [*(1..self)].reduce(:*) - [*(1..self)].reduce(:+)
  end
end
p 4.factorial_minus_triangle
1.upto(10) {|n| p n.factorial_minus_triangle}

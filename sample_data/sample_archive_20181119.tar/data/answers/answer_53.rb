# Predict what will be printed after each #
puts "\nSymbols"
sym1 = :s
sym2 = sym1
p sym2.object_id == sym1.object_id # true (numerically identical objects)

puts "\nStrings"
st1 = 'fun'
st2 = st1
p st2.object_id == st1.object_id  # true (ditto, but can be changed)

puts "\nSame string object?"
st3 = 'fun'
p st3.object_id == st1.object_id  # false (I think an identical string
                                  # does not make an identical ID, unlike
                                  # numbers and symbols)
st1 << 'k'
p st2                             # "funk" (changed BECAUSE #push deep copy)
p st2.object_id == st1.object_id  # true (still same reference)
st1 = 'funk'
p st2.object_id == st1.object_id  # false (reassignment changes reference!)

puts "\nIntegers"
n1 = 1
n2 = n1
p n2.object_id == n1.object_id    # true (literally numerically identical)

puts "\nArrays"
a1 = [1, 2]
a2 = a1
p a2.object_id == a1.object_id    # true (until a2 is changed)

puts "\nSame array object?"
a1 << 3
p a2                              # [1, 2, 3]
p a2.object_id == a1.object_id    # true (still a deep copy for now; but
                                  # this is because #push was used)
a1 = [4, 5]
p a2                              # [1, 2, 3] (a1 was reassigned!)
p a2.object_id == a1.object_id    # false (reassignment)

puts "\nDup'ing"
newarr1 = ['a', 'b', 'c']
newarr2 = newarr1.dup
p newarr2 == newarr1              # true (for now)
newarr1 << 'd'
p newarr2 == newarr1              # false (#dup breaks deep copy/#push identity)
p newarr2                         # ['a', 'b', 'c']

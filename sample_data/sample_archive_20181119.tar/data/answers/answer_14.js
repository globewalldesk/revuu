console.log("Band-Aid\u00AE 98.6\u00B0 F"); // Unicode, is hex too, 4 chars
console.log("Band-Aid\xAE 98.6\xB0 F"); // HeX code, 2 chars (up to ascii 256)

const R = Math.random();
console.log(R);

const UNTOUCHABLE = ['a', 'b', 'c'];
try {
  UNTOUCHABLE = [1, 2, 3];
} catch(err) {
  console.log("Oops: " + err)
}

UNTOUCHABLE[0] = 1;
UNTOUCHABLE[1] = 2;
UNTOUCHABLE[2] = 3;
console.log(UNTOUCHABLE);

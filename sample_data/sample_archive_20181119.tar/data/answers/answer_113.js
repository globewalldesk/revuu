function funkShun() {
  console.log("I can't actually access your new property easily...");
}
funkShun.prop = "foobar";
funkShun();
console.log(funkShun.prop);

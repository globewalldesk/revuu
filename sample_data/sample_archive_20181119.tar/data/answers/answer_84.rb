require 'date'
dt_methods = DateTime.new.methods
t_methods = Time.new.methods
p (t_methods & dt_methods).length

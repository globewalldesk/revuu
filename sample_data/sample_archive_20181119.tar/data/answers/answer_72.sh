ls -rtl ..*/
ls -ratl ..
ls -hartl ..
ls -hartl ../*.json
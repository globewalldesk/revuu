require 'json'
config = {'lang' => 'Ruby', 'text_editor' => 'Pico'}
File.write("config.json", config.to_json)
settings = JSON.parse(File.read("config.json"))
puts settings['lang']
system('rm config.json')

#include <stdio.h>

int main() {
    printf("%d\n", EOF);
}

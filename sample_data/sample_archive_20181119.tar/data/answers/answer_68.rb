def triple
  3 * yield
end

p triple {12} # 36

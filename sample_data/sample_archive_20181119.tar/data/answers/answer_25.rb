dog_breeds = {
  'Lassie' => 'Collie',
  'Rex' => 'German Shepherd',
  'Bobo' => 'Poodle'
}
dog_breeds.default = 'mutt';

['Lassie', 'Rex', 'Fifi', 'Rover', 'Bobo'].each do |nm|
  puts "#{nm}: #{dog_breeds[nm]}"
end

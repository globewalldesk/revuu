friends = ['Jack', 'Jill', 'Sam']

def yo(yo, *friends)
  friends.each { |friend| puts "#{yo}, #{friend}!" }
end

# Call yo
yo("Hello", *friends)

arr = ['a', 'b', 'c', 'd']
first, *the_rest = arr
puts "I really like #{first}, but as to #{the_rest.join(', ')}...they're OK."

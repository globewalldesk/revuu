ps aux | grep ruby

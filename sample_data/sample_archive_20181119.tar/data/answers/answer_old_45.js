const countArgs = (...x) => console.log("You passed " + x.length + " arguments to this function.")

countArgs(1, 2, 3, 5, 6);


console.log(' ')
//////////////////////////////////////////////////////////////////////////



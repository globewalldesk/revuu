// Define SpaceShuttle
function SpaceShuttle(name, targetPlanet) {
  this.name = name;
  this.targetPlanet = targetPlanet;
}
const aphro = new SpaceShuttle('Aphrodite', 'Venus'); // call it
console.log(`Shuttle ${aphro.name} is going to ${aphro.targetPlanet}.`);

// Define SpaceShuttle2
function SpaceShuttle2(name, targetPlanet) {
  return {
    name: name,
    targetPlanet: targetPlanet
  }
}
const ares = new SpaceShuttle2('Ares', 'Mars'); // call it
console.log(`Shuttle ${ares.name} is going to ${ares.targetPlanet}.`);

// Define SpaceShuttle3
function SpaceShuttle3(name, targetPlanet) {return {name, targetPlanet}}
var zeus = new SpaceShuttle3('Zeus', 'Jupiter'); // call it
console.log(`Shuttle ${zeus.name} is going to ${zeus.targetPlanet}.`);

// Define SpaceShuttle4
class SpaceShuttle4 {
  constructor(name, targetPlanet) {return {name, targetPlanet}}
}
var cronos = new SpaceShuttle4('Cronos', 'Saturn'); // call it
console.log(`Shuttle ${cronos.name} is going to ${cronos.targetPlanet}.`);


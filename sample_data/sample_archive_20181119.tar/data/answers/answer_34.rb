size = File.stat("../../revuu.rb").size
puts "revuu.rb:"
puts "  bytes: #{size}"
puts "  kb: #{(size/1024.0)}"
puts "  kb: #{(size/1024.0).round(2)}"

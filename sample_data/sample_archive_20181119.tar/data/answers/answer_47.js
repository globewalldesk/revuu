const plain = Array(10)
const arr = [...Array(10).keys()];
const newArr = [...new Array(10).keys()];
const newerArr = Array.from(new Array(10).keys());
console.log(plain);
console.log(arr);
console.log(newArr);
console.log(newerArr);

h = {}
az = [*('a'..'z')]
az.each_with_index {|l, i| h[l.to_sym] = i+1}
p h
h.select! {|k,v| v % 3 == 0}
p h
p h.keys

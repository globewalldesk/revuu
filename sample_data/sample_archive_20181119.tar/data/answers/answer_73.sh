echo "hello, world" > foo.txt
cat foo.txt > copy.txt
echo file contents:
cat foo.txt
cat copy.txt
ls -l foo.txt copy.txt
rm foo.txt copy.txt
ls -l foo.txt copy.txt

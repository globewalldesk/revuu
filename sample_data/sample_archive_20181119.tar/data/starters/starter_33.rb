config = {'lang' => 'Ruby', 'text_editor' => 'Pico'}

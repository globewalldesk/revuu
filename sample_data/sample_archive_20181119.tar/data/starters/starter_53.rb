# Predict what will be printed after each #
puts "\nSymbols"
sym1 = :s
sym2 = sym1
p sym2.object_id == sym1.object_id #

puts "\nStrings"
st1 = 'fun'
st2 = st1
p st2.object_id == st1.object_id  #

puts "\nSame string object?"
st3 = 'fun'
p st3.object_id == st1.object_id  #
st1 << 'k'
p st2                             #
p st2.object_id == st1.object_id  #
st1 = 'funk'
p st2.object_id == st1.object_id  #

puts "\nIntegers"
n1 = 1
n2 = n1
p n2.object_id == n1.object_id    #

puts "\nArrays"
a1 = [1, 2]
a2 = a1
p a2.object_id == a1.object_id    #

puts "\nSame array object?"
a1 << 3
p a2                              #
p a2.object_id == a1.object_id    #
a1 = [4, 5]
p a2                              #
p a2.object_id == a1.object_id    #

puts "\nDup'ing"
newarr1 = ['a', 'b', 'c']
newarr2 = newarr1.dup
p newarr2 == newarr1              #
newarr1 << 'd'
p newarr2 == newarr1              #
p newarr2                         #

dog_breeds = {
  'Lassie' => 'Collie',
  'Rex' => 'German Shepherd',
  'Bobo' => 'Poodle'
}

arr = [*(1..5)]
arr2 = (1...6).to_a
prc = Proc.new {|arr|
  for n in arr
    puts n * 3
  end
}
prc.call(arr);
prc.call(arr2);

const arr = [1, 2, 3];
arr[1] = 1000;
console.log(arr);

require 'date'
p (DateTime.new.methods & Time.new.methods).length

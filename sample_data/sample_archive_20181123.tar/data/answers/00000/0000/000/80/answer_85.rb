numfreq = {}
1_000_000.times do
  n = rand(10) + 1
  numfreq[n] ? numfreq[n] += 1 : numfreq[n] = 1
end
1.upto(10) do |n|
  printf "%2d: %.4f\n", n, (numfreq[n]/100000.0).round(4)
end

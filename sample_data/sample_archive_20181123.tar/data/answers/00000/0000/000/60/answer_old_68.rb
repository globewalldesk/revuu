def triple
  3 * yield
end

p triple {12} # 36



puts ''
#####################################


def triple
  3 * yield
end

puts triple {5} # Predict output. 15



puts ''
#####################################



az = [*('a'..'g')]
nums = [*(1..10)]
class Array
  def map_odd
    self.map.each_with_index {|x, i| i.odd? ? yield(x) : x}
  end
end
p az.map_odd {|x| x.upcase}
p nums.map_odd {|x| x*2}

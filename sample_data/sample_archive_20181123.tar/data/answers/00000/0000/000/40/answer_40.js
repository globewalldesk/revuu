const loveMyFunction = () => "This is really nice function, isn't it?";
console.log(loveMyFunction());
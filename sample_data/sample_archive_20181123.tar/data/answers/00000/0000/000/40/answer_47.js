tenEmpty = new Array(10);
console.log(tenEmpty);
onetoten = [...Array(10).keys()]
console.log(onetoten);
onetotenNew = [...new Array(10).keys()]
console.log(onetotenNew);
nudderOnetoten = Array.from(Array(10).keys())
console.log(nudderOnetoten);

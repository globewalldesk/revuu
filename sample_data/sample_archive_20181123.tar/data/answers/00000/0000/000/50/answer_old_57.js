//const a = 1;
//const b = 2;
//const c = 3;
const [a,b,c] = [1,2,3];
const arr = [a, b, c];
console.log(arr);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


//const a = 1;
//const b = 2;
//const c = 3;
const [a, b, c] = [1,2,3];
const arr = [a, b, c];
console.log(arr);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


//const a = 1;
//const b = 2;
//const c = 3; 
const [a, b, c] = [1,2,3]
const arr = [a, b, c];
console.log(arr);


console.log(' ')
//////////////////////////////////////////////////////////////////////////


const [a, b, c] = [1, 2, 3];
const arr = [a, b, c];
console.log(arr);



console.log(' ')
//////////////////////////////////////////////////////////////////////////



# Predict what will be printed after each #
puts "\nSymbols"
sym1 = :s
sym2 = sym1
p sym2.object_id == sym1.object_id # true (numerically identical objects)

puts "\nStrings"
st1 = 'fun'
st2 = st1
p st2.object_id == st1.object_id  # true (ditto, but can be changed)

puts "\nSame string object?"
st3 = 'fun'
p st3.object_id == st1.object_id  # false (I think an identical string
                                  # does not make an identical ID, unlike
                                  # numbers and symbols)
st1 << 'k'
p st2                             # "funk" (changed BECAUSE #push deep copy)
p st2.object_id == st1.object_id  # true (still same reference)
st1 = 'funk'
p st2.object_id == st1.object_id  # false (reassignment changes reference!)

puts "\nIntegers"
n1 = 1
n2 = n1
p n2.object_id == n1.object_id    # true (literally numerically identical)

puts "\nArrays"
a1 = [1, 2]
a2 = a1
p a2.object_id == a1.object_id    # true (until a2 is changed)

puts "\nSame array object?"
a1 << 3
p a2                              # [1, 2, 3]
p a2.object_id == a1.object_id    # true (still a deep copy for now; but
                                  # this is because #push was used)
a1 = [4, 5]
p a2                              # [1, 2, 3] (a1 was reassigned!)
p a2.object_id == a1.object_id    # false (reassignment)

puts "\nDup'ing"
newarr1 = ['a', 'b', 'c']
newarr2 = newarr1.dup
p newarr2 == newarr1              # true (for now)
newarr1 << 'd'
p newarr2 == newarr1              # false (#dup breaks deep copy/#push identity)
p newarr2                         # ['a', 'b', 'c']



puts ''
#####################################


# Predict what will be printed after each #
puts "\nSymbols"
sym1 = :s
sym2 = sym1
p sym2.object_id == sym1.object_id # true

puts "\nStrings"
st1 = 'fun'
st2 = st1
p st2.object_id == st1.object_id  # true

puts "\nSame string object?"
st3 = 'fun'
p st3.object_id == st1.object_id  # false
st1 << 'k'
p st2                             # 'funk'
p st2.object_id == st1.object_id  # true
st1 = 'funk'
p st2.object_id == st1.object_id  # false

puts "\nIntegers"
n1 = 1
n2 = n1
p n2.object_id == n1.object_id    # true

puts "\nArrays"
a1 = [1, 2]
a2 = a1
p a2.object_id == a1.object_id    # true

puts "\nSame array object?"
a1 << 3
p a2                              # [1,2,3]
p a2.object_id == a1.object_id    # true
a1 = [4, 5]
p a2                              # [1,2,3]
p a2.object_id == a1.object_id    # false

puts "\nDup'ing"
newarr1 = ['a', 'b', 'c']
newarr2 = newarr1.dup
p newarr2 == newarr1              # true
newarr1 << 'd'
p newarr2 == newarr1              # false
p newarr2                         # ['a', 'b', 'c']



puts ''
#####################################


a = :foo
b = a
puts "#{b.object_id == a.object_id}" # same obvs
s1 = 'string'
s2 = s1
puts "#{s1.object_id == s2.object_id}" # same
n1 = 1
n2 = n1
puts "#{n1.object_id == n2.object_id}" # same
a1 = [1, 2, 3]
a2 = a1
a2[2] = 30_000_000
p "Now a1 = #{a1}"
puts "#{a1.object_id == a2.object_id}" # same
h1 = {foo: 1, bar: 2}
h2 = h1
puts "#{h1.object_id == h2.object_id}" # same

s3 = 'string'
puts "#{s1.object_id == s3.object_id}" # diff
n3 = 1
puts "#{n1.object_id == n3.object_id}" # same
a3 = [1, 2, 3]
puts "#{a1.object_id == a3.object_id}" # diff
h3 = {foo: 1, bar: 2}
puts "#{h1.object_id == h3.object_id}" # diff

s1 = 'changed'
n1 = 2
a1 = []
h1 = {baz: 3}
puts "#{s1.object_id == s2.object_id}" # diff
p s1
p s2
puts "#{n1.object_id == n2.object_id}" # diff obvs
p n1
p n2
puts "#{a1.object_id == a2.object_id}" # diff
p a1
p a2
puts "#{h1.object_id == h2.object_id}" # diff NOTE: values same as orig
p h1
p h2



puts ''
#####################################


foo = :george
bar = foo
puts "#{foo.object_id} =? #{bar.object_id}" # Obvs true.
str = 'hi'
str2 = str
puts "#{str.object_id} =? #{str2.object_id}" # Thought false; but true.
str = 'yo'
puts str2
puts "#{str.object_id} =? #{str2.object_id}" # Not sure; but false.
str3 = 'hi'
str4 = 'hi'
puts "#{str3.object_id} =? #{str4.object_id}" # Obvs false.
arr = [1,2,3]
arr2 = arr
puts "#{arr.object_id} =? #{arr2.object_id}" # Obvs true.
arr[1] = 'a gazillion'
p arr2 # [1, 'a gazillion', 3]
hashy = {foo: 1, bar: 2}
hashy2 = hashy
puts "#{hashy.object_id} =? #{hashy.object_id}" # Obvs true.
hashy[:foo] = 123
p hashy2 # Defo changed
arr = [1,2,3]
arrdup = arr.dup
arrclone = arr.clone
arr[2] = 'a godawful lot'
p arr # changed
p arrdup # unchanged
p arrclone # unchanged



puts ''
#####################################


sim = :symbol
simeq = sim
print sim.object_id
print ' '
print simeq.object_id # Obv. the same
puts ''

str = 'yo'
str2 = str
print str.object_id
print ' '
print str2.object_id # Same
print ' '
str3 = 'yo'
print str3.object_id # Defo diff
puts ''

num = 1
num2 = num
print num.object_id
print ' '
print num2.object_id # Same
print ' '
num3 = 1
print num3.object_id # Same
puts ''

puts "arr:"
arr = [0, 1, 2]
arr2 = arr
print arr.object_id
print ' '
print arr2.object_id # Defo same
print ' '
arr3 = [0, 1, 2]
print arr3.object_id # Difo diff
puts ''

simd = sim.dup
simc = sim.clone
puts "#{simd.object_id} #{simc.object_id}" # Obvs same.

strd = str.dup
strc = str.clone
puts "#{strd.object_id} #{strc.object_id}" # ? Turns out to be diff!

arrd = arr.dup
arrc = arr.clone
puts "#{arrd.object_id} #{arrc.object_id}" # ?? Turns out to be diff!



puts ''
#####################################



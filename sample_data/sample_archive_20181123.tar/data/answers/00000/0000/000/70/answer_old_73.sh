echo "hello, world" > foo.txt
cat foo.txt > bar.txt
echo foo.txt:
cat foo.txt
echo bar.txt:
cat bar.txt
ls -lah foo.txt bar.txt
rm foo.txt bar.txt
ls -lah foo.txt bar.txt



echo '<--spacer-->'
#####################################


echo "hello, world" > foo.txt
cat foo.txt > bar.txt
echo here is foo
cat foo.txt
echo here is bar
cat bar.txt
ls -lah *.txt
qrm foo.txt bar.txt
ls -lah *.txt



echo '<--spacer-->'
#####################################



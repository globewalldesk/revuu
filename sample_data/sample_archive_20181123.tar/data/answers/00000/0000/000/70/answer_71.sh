echo "From fairest creature we desire increase" > shake.txt
echo "That thereby beauty's rose might never die," >> shake.txt
cat shake.txt
rm shake.txt
ls shake.txt

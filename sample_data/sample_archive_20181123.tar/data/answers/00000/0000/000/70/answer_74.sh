tail -f yahoo.log

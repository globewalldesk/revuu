ls -lh /opt
sudo touch /opt/foo
ls -lh /opt
sudo rm /opt/foo
ls -lh /opt

cd
pwd
cdr
pwd
cd ~
pwd

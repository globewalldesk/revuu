ls -ld */ */*/
mkdir -p foo/bar
ls -ld */ */*/
rm -rf foo/*
ls -ld */ */*/
rm -rf foo
ls -ld */ */*/

arr = (1..10).to_a
evens, odds = arr.partition{|x| x.even?}
p evens, odds

def title_case(str)
  ary = str.split(" ")
  ary.map! do |word|
    if ['the', 'a', 'an', 'of', 'and', 'on', 'in', 'over'].include? word
      word
    else
      word.capitalize
    end
  end
  ary.join(" ")[0].upcase + ary.join(" ")[1..-1]
end

def camel_case(str)
  ary = str.split(" ")
  ary.map!(&:capitalize)
  ary.join('')
end

def toggle_case(str)
  str = title_case(str)
  ary = str.split('')
  ary.map! {|x| x.upcase == x ? x.downcase : x.upcase}
  ary.join('')
end

books = ['the mill on the floss', 'war and peace', 'anna karenina', 'red and black',
         'catcher in the rye', 'of mice and men', 'the bridge of san luis rey']

books.each do |str|
  puts "#{str}:"
  meths = [-> {title_case(str)}, -> {camel_case(str)}, -> {toggle_case(str)}]
  meths.each do |meth|
    puts "  #{meth.call}"
  end
  puts ''
end



puts ''
#####################################


def title_case(str)
  ary = str.split(" ")
  ary.map! do |word|
    if ['the', 'a', 'an', 'of', 'and', 'on', 'in', 'over'].include? word
      word
    else
      word.capitalize
    end
  end
  ary.join(" ")[0].upcase + ary.join(" ")[1..-1]
end

def camel_case(str)
  ary = str.split(" ")
  ary.map!(&:capitalize)
  ary.join('')
end

def toggle_case(str)
  str = title_case(str)
  ary = str.split('')
  ary.map! {|x| x.upcase == x ? x.downcase : x.upcase}
  ary.join('')
end

books = ['the mill on the floss', 'war and peace', 'anna karenina', 'red and black',
         'catcher in the rye', 'of mice and men', 'the bridge over the river kwai']

books.each do |book|
  lambdas = [-> {title_case(book)}, -> {camel_case(book)}, -> {toggle_case(book)}]
  lambdas.each do |l|
    puts l.call
  end
  puts ''
end


puts ''
#####################################



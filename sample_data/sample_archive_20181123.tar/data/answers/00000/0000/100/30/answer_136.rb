leaders = {
  Pericles: 'Athens',
  "Marcus Aurelius": 'Rome',
  "Genghis Khan": 'Mongolia',
  "George Washington": 'United States',
  Hitler: 'Germany',
  "Pol Pot": 'Cambodia'
}
p leaders
#leaders.delete(:"Genghis Khan")
#leaders.delete(:Hitler)
#leaders.delete(:"Pol Pot")
leaders.reject!{|k,v| [:"Genghis Khan", :Hitler, :"Pol Pot"].include? k }
p leaders

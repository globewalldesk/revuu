arr = [0, 1, 2, 3, 4]
p arr[0]
p arr[-1]
p arr.first
p arr.last

#include <stdio.h>

int main() {
  double nc;
  int c;
  for(nc = 0; (c = getchar()) != EOF; ++nc);
  printf("\n==============\n%.0f characters\n", nc);
}

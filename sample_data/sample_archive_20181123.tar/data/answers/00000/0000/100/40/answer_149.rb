none_over_eight = 0
any_under_three = 0
nums = Hash.new(0)
1000000.times do
  ten = [*(1..10)].map{|x| rand(10)+1 }
  none_over_eight += 1 if ten.none?{|x|nums[x]+=1;x>8}
  any_under_three += 1 if ten.any?{|x|x<3}
end
puts none_over_eight
puts any_under_three
p nums

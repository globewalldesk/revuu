mountains = {
  'Mount Everest' => 29029,
  'K2' => 28251,
  'Kangchenjunga' => 28169,
  'Lhotse' => 27940,
  'Makalu' => 27838,
  'Cho Oyo' => 26864,
  'Dhaulagiri I' => 26795
}

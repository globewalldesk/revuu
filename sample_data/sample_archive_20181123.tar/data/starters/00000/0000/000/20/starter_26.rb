names = [
  { firstname: 'John', lastname: 'Doe' },
  { firstname: 'Jane', lastname: 'Roe' },
  { firstname: 'Jack', lastname: 'Sprat' },
  { firstname: 'Holly', lastname: 'Golightly' },
  { firstname: 'Santa', lastname: 'Claus' }
]

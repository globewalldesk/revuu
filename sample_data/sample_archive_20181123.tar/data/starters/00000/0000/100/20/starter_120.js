str = 'hello world';
str = 'hello world';
console.log(); // 'hello'
console.log(); // 'hello'
console.log(); // 'lo'
console.log(); // 'lo'
console.log(); // 'world'
console.log(); // 'world'

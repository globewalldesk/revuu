str = "hello world"
# Replace the following with something even shorter.
p str.chars

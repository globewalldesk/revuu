ls -d */ */*/
zip -q starters.zip -r ../starters
unzip -q starters.zip -d starters
ls -d */ */*
ls starters/*
rm -rf starters.zip starters/
ls -d */ */*/



echo '<--spacer-->'
#####################################


ls starters starters/*
zip -rq starters.zip "../starters"
ls starters starters/*
unzip -q starters.zip -d ./starters
ls starters/*
rm starters.zip
rm -rf starters
ls starters starters/*



echo '<--spacer-->'
#####################################


echo zipping starters.zip
zip -rq starters.zip "../starters"
ls -lh starters.zip
unzip -:q starters.zip -d starters
ls -d starters.zip starters/
ls -l starters/* | wc -l
rm -rf starters.zip 
rm -rf starters
ls -lh starters.zip starters/ starters/*


echo '<--spacer-->'
#####################################


echo No directories:
ls -ld */
echo Zipping...
zip -rq starters.zip "../starters"
echo Now there is a zip file
ls -l starters.zip
echo Unzipping...
unzip -:q starters.zip -d starters/
echo Now there is a starter directory
ls -ld starters/
echo with how many files?
ls -l | wc -l
echo Removing files and folder
rm starters.zip
rm -rf starters/
echo all gone!
ls -ld */



echo '<--spacer-->'
#####################################


echo zipping up...
zip -r starters.zip ../starters
echo unzipping to new directory..
unzip -: starters.zip -d starters/
ls -lh starters.zip
ls -lh starters/
echo removing...
rm starters.zip
rm -rf starters/
echo proof it is gone...
ls -lh starters.zip
ls -lh starters/



echo '<--spacer-->'
#####################################


zip -r starters.zip ../starters
unzip -: starters.zip
ls -lhR starters*
rm starters.zip
rm -rf ./starters
ls -lhR starters*



echo '<--spacer-->'
#####################################


zip -v starters.zip ../starters/*
ls -ltr starters.zip
unzip -: starters.zip -d starters
ls -ltr starters/
rm -v starters.zip
rm -rvf starters



echo '<--spacer-->'
#####################################


zip starters.zip ../starters/*
ls -ltr starters.zip
unzip -: starters.zip -d starters
ls -ltr starters
rm starters.zip
rm -rf starters


echo '<--spacer-->'
#####################################


zip -r tester.zip ../starters
sleep 1
ls -ltr tester.zip
sleep 1
unzip -: tester.zip -d starters
sleep 1
ls -ltr starters
rm tester.zip
rm -rf starters


echo '<--spacer-->'
#####################################



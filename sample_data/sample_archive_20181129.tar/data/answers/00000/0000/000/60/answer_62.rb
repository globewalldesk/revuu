az = [*('a'..'g')]
nums = [*(1..10)]

class Array
  def map_odd
    self.map.each_with_index do |el, i|
      i.odd? ? yield(el) : el
    end
  end
end

p az.map_odd {|x| x.upcase}
p nums.map_odd {|n| n * 2}

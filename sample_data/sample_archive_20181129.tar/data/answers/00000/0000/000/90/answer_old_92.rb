arr = File.readlines(__FILE__)
puts "Here's the last line:"
p arr[-1]
puts 'This is a file I am enjoying reading, to be honest.'
puts 'And now you have come to the end of it. Too bad!'



puts ''
#####################################


arr = File.readlines(__FILE__)
p arr[-1]
puts "This is a file I am enjoying reading, to be honest."
puts "And now you've come to the end of it. Too bad!"



puts ''
#####################################


lines = File.readlines(__FILE__)
puts lines[-1].inspect
puts "This is a file I am enjoying reading, to be honest."
puts "And now you've come to the end of it. Too bad!"



puts ''
#####################################


lines = File.readlines(__FILE__)
puts "The last line of this file is:\n#{lines[-1]}"
puts "This is a file I am enjoying reading, to be honest."
puts "And now you've come to the end of it. Too bad!"



puts ''
#####################################



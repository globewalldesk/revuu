const [a, b, c] = [1, 2, 3];
const arr = [a, b, c];
console.log(arr);

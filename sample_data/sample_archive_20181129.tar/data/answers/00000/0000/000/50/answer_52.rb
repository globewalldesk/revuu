arr1 = Array.new(10)
arr2 = Array.new(10, true)
arr3 = Array.new(10) {|x| x}
p arr1
p arr2
p arr3

class SortedArray < Array
  def initialize(arr)
    self << arr
    super
    self.sort!
  end
end
arr = SortedArray.new([5, 3, 6, 1, 8, 4])
p arr
p arr.reverse!
p arr.map {|n| n + 2}
p arr.class



puts ''
#####################################


class SortedArray < Array
  def initialize(args)
    super(args)
    self.sort!
  end

  def double_elements
    self.map! {|x| x*2}
  end
end

arr = SortedArray.new([2, 1, 3])
p arr
p arr.reverse
p arr.double_elements
arrb = SortedArray.new(['3', 'b', 'z', 'C', '23'])
p arrb
p arrb.double_elements



puts ''
#####################################


class SortedArray < Array
  def initialize(args)
    super(args)
    self.sort!
  end
  def reverse
    self.reverse!
  end
end
sa = SortedArray.new(10) {|o| rand(o)}
p sa
p sa.reverse



puts ''
#####################################



less ../../../../sonnets.txt

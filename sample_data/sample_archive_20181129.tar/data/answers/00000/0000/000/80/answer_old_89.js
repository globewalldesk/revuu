'use strict';
let obj = {foo: 1, bar: 2};
console.log(`Before any change, obj.foo = ${obj.foo}`)
obj.foo = 10000;
console.log(`After first change attempt, obj.foo = ${obj.foo}`)
Object.freeze(obj);
try {
  obj.foo = 100;
} catch (err) {
  console.log("Oops: " + err)
}
console.log(`After second change attempt, obj.foo = ${obj.foo}`)



console.log(' ')
//////////////////////////////////////////////////////////////////////////


'use strict';
let obj = {foo: 1, bar: 2};
console.log(`Before any change, obj.foo = ${obj.foo}`)
obj.foo = 10000;
console.log(`After first change attempt, obj.foo = ${obj.foo}`)
Object.freeze(obj);
try {
  obj.foo = 100;
} catch (err) {
  console.log("Oops: " + err)
}
console.log(`After second change attempt, obj.foo = ${obj.foo}`)



console.log(' ')
//////////////////////////////////////////////////////////////////////////


'use strict';
let obj = {foo: 1, bar: 2};
console.log(`Before any change, obj.foo = ${obj.foo}`)
obj.foo = 10000;
console.log(`After first change attempt, obj.foo = ${obj.foo}`)
Object.freeze(obj);
try {
  obj.foo = 100;
} catch (err) {
  console.log("Oops: " + err)
}
console.log(`After second change attempt, obj.foo = ${obj.foo}`)



console.log(' ')
//////////////////////////////////////////////////////////////////////////


'use strict';
let obj = {foo: 1, bar: 2};
console.log(`Before any change, obj.foo = ${obj.foo}`)
obj.foo = 10000;
console.log(`After first change attempt, obj.foo = ${obj.foo}`)
Object.freeze(obj);
try {
  obj.foo = 100;
} catch (err) {
  console.log("Oops: " + err)
}
console.log(`After second change attempt, obj.foo = ${obj.foo}`)



console.log(' ')
//////////////////////////////////////////////////////////////////////////


'use strict';
let obj = {foo: 1, bar: 2};
console.log(`Before any change, obj.foo = ${obj.foo}`)
obj.foo = 10000;
console.log(`After first change attempt, obj.foo = ${obj.foo}`)
Object.freeze(obj);
try {
  obj.foo = 100;
} catch (err) {
  console.log("Oops: " + err)
}
console.log(`After second change attempt, obj.foo = ${obj.foo}`)



console.log(' ')
//////////////////////////////////////////////////////////////////////////



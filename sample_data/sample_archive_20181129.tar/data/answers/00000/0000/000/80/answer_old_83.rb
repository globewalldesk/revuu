str = "Hello, world!"
p str.split
p str.split()
# p str.split('')
# p str.split(//)
p str.split(' ')



puts ''
#####################################


str = "Hello, world!"
p str.split
p str.split()
# p str.split('')
# p str.split(//)
p str.split(' ')



puts ''
#####################################


str = "Hello, world!"
p str.split
p str.split()
# p str.split('')
# p str.split(//)
p str.split(' ')



puts ''
#####################################



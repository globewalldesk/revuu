str = 'hxexlxlxox xwxoxrxlxdx'
str.length.times do |n|
  print str[n] unless n.odd?
end
puts ''

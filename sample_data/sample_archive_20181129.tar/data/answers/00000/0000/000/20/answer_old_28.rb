friends = ['Jack', 'Jill', 'Sam']

def yo(yo, *friends)
  friends.each { |friend| puts "#{yo}, #{friend}!" }
end

# Call yo
yo("Hello", *friends)

arr = ['a', 'b', 'c', 'd']
first, *the_rest = arr
puts "I really like #{first}, but as to #{the_rest.join(', ')}...they're OK."



puts ''
#####################################


friends = ['Jack', 'Jill', 'Sam']

def yo(greet, jack, jill, sam)
  [jack, jill, sam].each { |friend| puts "#{greet}, #{friend}!" }
end
yo("Yo", *friends)

arr = ['a', 'b', 'c', 'd']

first, *the_rest = arr
puts "I really like #{first}, but as to #{the_rest.join(", ")}...they're OK."



puts ''
#####################################


def yo(greet, *friends)
  friends.each { |friend| puts "#{greet}, #{friend}!" }
end
friends = ['Jack', 'Jill', 'Sam']
yo("Yo", *friends)

first, *the_rest = ['a', 'b', 'c', 'd']
puts "I really like #{first}, but as to #{the_rest.join(', ')}...they're OK."


puts ''
#####################################


friends = ['Jack', 'Jill', 'Sam']
def yo(greet, *friends)
  friends.each { |friend| puts "#{greet}, #{friend}!" }
end
yo("Hi", *friends)

arr = ['a', 'b', 'c', 'd']
first, *the_rest = arr
puts "I really like #{first}, but as to #{the_rest.join(', ')}...they're OK."


#####################################


friends = ['Jack', 'Jill', 'Sam']
def yo(greet, *friends) # This assigns greet and doesn't care how many are left;
                        # it collects them all together into a single array.
  friends.each { |friend| puts "#{greet}, #{friend}!" }
end
yo('Yo', *friends); # Here, you're passing each item individually; four args.

arr = ['a', 'b', 'c', 'd']
first, *the_rest = arr      # Again, this collects the_rest into an array.

puts "I like #{first}, but as to #{the_rest.join(', ')}...they're OK."



#####################################



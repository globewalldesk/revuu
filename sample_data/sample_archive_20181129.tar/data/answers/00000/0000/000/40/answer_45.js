// Rewrite this Ruby in JavaScript.
function countArgs(...args) {
  console.log(`You passed ${args.length} to this function.`);
}
countArgs(1, 2, 3, 4, 5);

//def count_args(*args)
//  puts "You passed #{args.length} to this function."
//end

const [x, y, z] = [1, 2, 3];
const foo = [x, y, z];
console.log(foo);
foo[0] = 100; // works
console.log(foo);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


const FRED = 1;
const JOE = 2;
const BOB = 3;
const ARR = [FRED, JOE, BOB];
console.log(ARR);
ARR[2] = 42; // Should work
console.log(ARR); 


console.log(' ')
//////////////////////////////////////////////////////////////////////////


const a = 'a';
const b = 'b';
const c = 'c';
const arr = [a, b, c];
console.log(arr);
arr[0] = 'z';
console.log(arr);


//////////////////////////////////////////////////////////////////////////



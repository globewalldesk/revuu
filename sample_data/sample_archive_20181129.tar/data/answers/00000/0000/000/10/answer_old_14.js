console.log("Band-Aid\u00AE 98.6\u00B0 F"); // Unicode, is hex too, 4 chars
console.log("Band-Aid\xAE 98.6\xB0 F"); // HeX code, 2 chars (up to ascii 256)



console.log(' ')
//////////////////////////////////////////////////////////////////////////


console.log("Band-Aid\u00AE 98.6\u00B0F"); // Unicode = 16-bit hex
console.log("Band-Aid\xAE 98.6\xB0F");     // Hex = 8-bit hex
console.log("\u0048\u0049");
console.log("\x48\x49");



console.log(' ')
//////////////////////////////////////////////////////////////////////////


console.log("Band-aid\u00AE 98.6\u00B0");
console.log("Band-aid\xAE 98.6\xB0");
console.log("\u0068\u0069");
console.log("\x68\x69");



console.log(' ')
//////////////////////////////////////////////////////////////////////////


console.log(
  "Band-Aid\u00AE",
  "Band-Aid\xAE",
  "98.6 F\u00B0",
  "98.6 F\xB0",
  "\u0048\u0069\u0021",
  "\x48\x69\x21"
);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


console.log("Band-Aid\u00ae, Band-Aid\xAE, 98\u00B0 F., 98\xB0 F.");
console.log("\u0068\u0069, \x68\x69");



//////////////////////////////////////////////////////////////////////////



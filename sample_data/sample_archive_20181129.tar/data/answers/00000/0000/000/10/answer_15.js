['99', '2.3', '2.3a', 'xyz'].forEach((s) =>
  console.log(`${s} ${isNaN(s) ? 'is not' : 'is'} numeric.`)
);

console.log();

['99', '2.3', '2.3a', 'xyz'].forEach((s) =>
  console.log(`'${s}' ${Number.isInteger(s) ? 'is' : 'is not'} an integer.`)
);

console.log();

[99, 2.3, '2.3a', 'xyz'].forEach((s) =>
  console.log(`${s} ${Number.isInteger(s) ? 'is' : 'is not'} an integer.`)
);

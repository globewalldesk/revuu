arr = [*(1..5)]
arr2 = (1...6).to_a
prc = Proc.new {|arr|
  for n in arr
    puts n * 3
  end
}
prc.call(arr);
prc.call(arr2);



puts ''
#####################################


nums = *(1..5)

def printo(arr)
  for n in arr
    print("#{n * 3} ")
  end
end
printo(nums)
puts ''
nums = (1...6).to_a
printo(nums)
puts ''


puts ''
#####################################


arr = (1..5).to_a
for i in arr
  print (i * 3).to_s + ' '
end
puts ''
arr2 = (1...6).to_a
for i in arr2
  print "#{i * 3} "
end



#####################################



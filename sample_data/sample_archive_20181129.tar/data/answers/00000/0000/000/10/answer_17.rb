numbers = []
three_ones = [1, 1, 1]
10.times do |i|
  break if i == 10
  next if i.even?
  numbers << i
  redo if i == 1 and numbers != three_ones
  i += 1
end
puts numbers.inspect #=> [1, 1, 1, 3, 5, 7, 9]

# redo; next; break

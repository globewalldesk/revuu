console.log("Band-Aid\u00AE 98.6\u00B0F");
console.log("Band-Aid\xAE 98.6\xB0F")
console.log("\u0068\u0069 \x68\x69")

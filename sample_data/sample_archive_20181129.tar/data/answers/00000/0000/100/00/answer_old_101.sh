ls -lh /opt
sudo touch /opt/foo
ls -lh /opt
sudo rm /opt/foo
ls -lh /opt



echo '<--spacer-->'
#####################################


echo Listing opt:
ls /opt
echo Creating foo...
sudo touch /opt/foo
echo Listing opt with foo:
ls -l /opt
echo Removing foo...
sudo rm /opt/foo
echo Listing opt for the last time...
ls -l /opt



echo '<--spacer-->'
#####################################


ls -lah /opt
sudo touch /opt/foo
ls -lah /opt
sudo rm /opt/foo
ls -lah /opt



echo '<--spacer-->'
#####################################



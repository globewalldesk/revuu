lengths = Hash.new do |hash,key|
  key = key.to_s
  hash[key] = key.length
end
lengths[:foo] = :bar
lengths['Jehosaphat']
lengths['baz'] = 3
lengths[:xyzpdq]
p lengths

foods = Hash.new do |hash,food|
  hash[food] = []
end

#foods = Hash.new([])

foods['a']
foods['c'] << 'carrot' << 'cucumber' << 'cake'
foods['m'] << 'milk' << 'mango' << 'malted milk balls'

p foods

foods = Hash.new do |hash,food|
  key = food[0].to_s.downcase
  key == food ? hash[key] = [] : hash[key] << food
end

foods['a']
foods['apple']
foods['avocado']
foods['alfredo sauce']
foods['barbeque']
foods['Cheetos']
foods['chocolate']
p foods

# Three arrays made different ways...
a = *('a'..'z')
b = ('a'..'z').to_a
c = Array('a'..'z')
p a, b, c

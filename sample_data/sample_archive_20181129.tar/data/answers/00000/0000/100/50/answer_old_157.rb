str = 'a m a n a p l a n a c a n a l p a n a m a!'
class String
  alias :backwards! :reverse!
end
puts str.backwards!



puts ''
#####################################



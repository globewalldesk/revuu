arr = ['eeeee!', 'bb', 'aaa', 'the eagle has landed', 'hello', 'zed', 'goll dang']

puts arr.min_by {|x| x.length}
puts arr.min_by {|x| x}
puts arr.min_by {|x| x.split('').count('e')}
puts
puts arr.max_by {|x| x.length}
puts arr.max_by {|x| x}
puts arr.max_by {|x| x.split('').count('e')}
puts
p arr.minmax {|x| x.length}
p arr.minmax {|x,y| x <=> y}
p arr.minmax {|x| x.split('').count('e')}
puts
p arr.sort {|x,y| x.length <=> y.length}
p arr.sort {|x,y| x <=> y}
p arr.sort {|x,y| x.split('').count('e') <=> y.split('').count('e')}

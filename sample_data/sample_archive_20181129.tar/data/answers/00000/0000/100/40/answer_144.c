#include <stdio.h>

int main() {
    printf("'%c'\"%s\"", '\n', "\n");
}

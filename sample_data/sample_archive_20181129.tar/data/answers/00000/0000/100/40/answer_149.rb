none_over_eight = 0
any_under_three = 0
nums = Hash.new(0)
1000000.times do
  ten = [*(1..10)].map{|x| rand(10)+1 }
  ten.each {|n| nums[n] += 1 }
  none_over_eight += 1 if ten.none? {|n| n > 8}
  any_under_three += 1 if ten.any? {|n| n < 3}
end
puts none_over_eight
puts any_under_three
p nums

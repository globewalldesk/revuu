do {
  num = Math.random();
  console.log(num);
} while (num < 0.95)

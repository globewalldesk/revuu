def encode(str)
  str.each_char.map {|c| [c.ord * 3].pack('U') }.join
end

def decode(str)
  str.each_char.map {|c| [c.ord / 3].pack('U') }.join
end

str = "The quick brown fox jumped over the lazy dog."
puts str
encoded_str = encode(str)
puts encoded_str
decoded_str = decode(encoded_str)
puts decoded_str

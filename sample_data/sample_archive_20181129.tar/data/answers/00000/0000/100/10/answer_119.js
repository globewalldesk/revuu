console.log(23%10)

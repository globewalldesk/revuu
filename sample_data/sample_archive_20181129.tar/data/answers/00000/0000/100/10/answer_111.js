const a = () => console.log("Foo bar a!");
const b = () => console.log("Foo bar b!");
const square = (x) => console.log(x * x);
const funks = [a, b, square];
funks.forEach((funk) => funk(3));

const ninjaFunction =
  () => console.log("Dude like this is totally a NINJA function!");

function call(funk) {
  funk();
}

call(ninjaFunction);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


const ninjaFunction = 
  () => console.log("Dude like this is totally a NINJA function!");

function call(funk) {
  funk();
}

call(ninjaFunction);


console.log(' ')
//////////////////////////////////////////////////////////////////////////


const ninjaFunction = () =>
  console.log("Dude like this is totally a NINJA function!");

const call = (funk) => funk();

call(ninjaFunction);



console.log(' ')
//////////////////////////////////////////////////////////////////////////



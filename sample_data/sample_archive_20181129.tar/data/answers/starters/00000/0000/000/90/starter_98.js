// Define SpaceShuttle
const aphro = new SpaceShuttle('Aphrodite', 'Venus'); // call it
console.log(`Shuttle ${aphro.name} is going to ${aphro.targetPlanet}.`);

// Define SpaceShuttle2
const ares = new SpaceShuttle2('Ares', 'Mars'); // call it
console.log(`Shuttle ${ares.name} is going to ${ares.targetPlanet}.`);

// Define SpaceShuttle3
var zeus = new SpaceShuttle3('Zeus', 'Jupiter'); // call it
console.log(`Shuttle ${zeus.name} is going to ${zeus.targetPlanet}.`);

// Define SpaceShuttle4
var cronos = new SpaceShuttle4('Cronos', 'Saturn'); // call it
console.log(`Shuttle ${cronos.name} is going to ${cronos.targetPlanet}.`);

dog_breeds = {
  'Lassie' => 'Collie',
  'Rex' => 'German Shepherd',
  'Bobo' => 'Poodle'
}
names = ['Lassie', 'Bobo', 'King', 'Rover', 'Rex']

# Three arrays made different ways...
a =
b =
c =
p a, b, c

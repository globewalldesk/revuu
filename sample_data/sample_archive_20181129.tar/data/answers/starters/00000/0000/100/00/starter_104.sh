cd ..
cd ..
cd ..
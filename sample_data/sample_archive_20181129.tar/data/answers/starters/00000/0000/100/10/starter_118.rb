module KlassModule
  def speak
    puts 'Woof! Woof!'
  end
end

class Klass
end
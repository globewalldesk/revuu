def get_ten
  nums = []
  10.times {nums << rand(10) + 1} # Get ten random integers.
  nums
end

# Add here

counts = []
10.times {counts << get_ten.count{|n| n.odd?}}
p counts.average

counts = []
100.times {counts << get_ten.count{|n| n.odd?}}
p counts.average

counts = []
1000.times {counts << get_ten.count{|n| n.odd?}}
p counts.average

counts = []
10000.times {counts << get_ten.count{|n| n.odd?}}
p counts.average
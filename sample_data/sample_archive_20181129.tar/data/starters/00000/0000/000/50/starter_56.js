const Faves = { fruit: 'apple', music: 'Irish trad', prog_lang: 'Ruby' };
console.log(`My favorite fruit is ${Faves.fruit}; music, ${Faves.music};`);
console.log(`programming language, ${Faves.prog_lang}.`);

"Encyclopaedias make me feel so anaemic that I need anaesthesia."

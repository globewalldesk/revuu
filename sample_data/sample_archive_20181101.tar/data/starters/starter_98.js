// Define SpaceShuttle:


var zeus = // call it
console.log(`Shuttle ${zeus.name} is going to ${zeus.targetPlanet}.`)

// Define SpaceShuttle2:


const ares = // call it
console.log(`Shuttle ${ares.name} is going to ${ares.targetPlanet}.`)

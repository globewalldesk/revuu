class Book {
  constructor(fullname) {
    this.fullname = fullname;
  }
}
const epic = new Book('Jack London');
console.log(epic.fullname);
epic.fullname = 'Leo Tolstoy';
console.log(epic.fullname);

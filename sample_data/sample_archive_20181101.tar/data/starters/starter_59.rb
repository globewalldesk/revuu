a = 1
a = a || 25
b = b || 25
puts a, b #=> 1, 25

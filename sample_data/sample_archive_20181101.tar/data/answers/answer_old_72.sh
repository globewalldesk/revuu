ls -rtl
ls -ratl
ls -hartl
ls *.java
ls !(answer_*)



echo '<--spacer-->'
#####################################



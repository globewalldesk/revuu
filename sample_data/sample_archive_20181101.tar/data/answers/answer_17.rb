numbers = []
three_ones = [1, 1, 1]
10.times do |i|
  numbers << i
  i += 1
end
print numbers
puts ''

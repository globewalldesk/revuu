const [x, y, z] = [1, 2, 3];
const foo = [x, y, z];
console.log(foo);
foo[0] = 100; // works
console.log(foo);

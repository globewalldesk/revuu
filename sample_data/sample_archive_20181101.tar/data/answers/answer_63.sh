echo zipping up...
zip -r starters.zip ../starters
echo unzipping to new directory..
unzip -: starters.zip -d starters/
ls -lh starters.zip
ls -lh starters/
echo removing...
rm starters.zip
rm -rf starters/
echo proof it is gone...
ls -lh starters.zip
ls -lh starters/

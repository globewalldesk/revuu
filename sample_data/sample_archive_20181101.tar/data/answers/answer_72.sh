echo "reversed time with details:"
ls -rtl ..
echo "same with hidden folders"
ls -artl ..
echo "with KB"
ls -hartl ..
echo "same, just .rb"
ls -hartl ../*.json

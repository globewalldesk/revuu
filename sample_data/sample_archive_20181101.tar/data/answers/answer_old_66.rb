cube = Proc.new {|x| x.class == Integer ? x**3 : x}
arr = [1, 2, "foo", 3, 4, "bar", 5, 6, "baz"]
p arr.collect! &cube
p cube.call(4)



puts ''
#####################################



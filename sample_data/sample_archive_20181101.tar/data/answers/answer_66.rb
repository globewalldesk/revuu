arr = [1, 2, "foo", 3, 4, "bar", 5, 6, "baz"]
cuber = Proc.new {|x| x.class == Integer ? x**3 : x}
p arr.collect(&cuber)
p cuber.call(4)

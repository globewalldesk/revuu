class Animal
  attr_reader :name, :living

  def initialize(name)
    @name = name
    @living = true
  end

  def makes_noise
    puts "#{@name} growls!"
  end
end
leo = Animal.new('Leo')
leo.makes_noise

class Cat < Animal
  def makes_noise
    super
    puts "Then it purrs."
  end
end

felix = Cat.new('Fel')
felix.makes_noise

p felix.instance_variables

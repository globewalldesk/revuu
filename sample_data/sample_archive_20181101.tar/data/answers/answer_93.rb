a = nil
until a == 'q'
  print "Enter a numeric sort of string for fun! "
  a = gets.chomp
  puts a == a.to_i.to_s ? "Looks like an integer." :
    a == 'q' ? "Quitting." : "Hmm, not an integer."
end

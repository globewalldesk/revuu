class Book {
  constructor(fullname) {
    this.fullname = fullname;
  }
}
const epic = new Book('Jack London');
console.log(epic.fullname);
epic.fullname = 'Leo Tolstoy';
console.log(epic.fullname);

class Volume {
  constructor(firstname, lastname) {
    this._firstname = firstname;
    this._lastname = lastname;
  }
  set firstname(name) {
    this._firstname = name;
  }
  set lastname(name) {
    this._lastname = name;
  }
  get fullname() {
    return (this._firstname + ' ' + this._lastname);
  }
}

const book = new Volume('Fyodor', 'Dostoyevsky');
console.log(book.fullname);
book.firstname = 'Ayn';
book.lastname = 'Rand';
console.log(book.fullname);

ls -d */
mkdir -p foo/bar/
ls -d */
ls -d */*
rm -rf foo
ls -d */

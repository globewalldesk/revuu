friends = ['Jack', 'Jill', 'Sam']

def yo(greet, jack, jill, sam)
  [jack, jill, sam].each { |friend| puts "#{greet}, #{friend}!" }
end
yo("Yo", *friends)

arr = ['a', 'b', 'c', 'd']

first, *the_rest = arr
puts "I really like #{first}, but as to #{the_rest.join(", ")}...they're OK."

arr = (1..5).to_a
for i in arr
  print (i * 3).to_s + ' '
end
puts ''
arr2 = (1...6).to_a
for i in arr2
  print "#{i * 3} "
end



#####################################



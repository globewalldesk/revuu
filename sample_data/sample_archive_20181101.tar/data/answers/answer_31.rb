puts "Acme Products".center(75)
puts "The top products for you!".center(75, '=+')

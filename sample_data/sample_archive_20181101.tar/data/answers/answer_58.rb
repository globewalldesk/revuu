class Integer
  def factorial_minus_triangle
    (1..self).reduce(:*) - (1..self).reduce(:+)
  end
end

p 3.respond_to? :factorial_minus_triangle

p [*(1..10)].map!(&:factorial_minus_triangle)

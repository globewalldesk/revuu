arr = [*(-10..10)]
neg = []
zero = []
pos = []
arr.each do |x|
  case x <=> 0
  when -1
    neg << x
  when 0
    zero << x
  when 1
    pos << x
  end
end
puts "Negative: #{neg.inspect}"
puts "Zero: #{zero.inspect}"
puts "Positive: #{pos.inspect}"

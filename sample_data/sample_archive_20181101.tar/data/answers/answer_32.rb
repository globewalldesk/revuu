puts "#{8212.chr('utf-8')} \u2014 #{[8212].pack('U')}"

zip -v starters.zip ../starters/*
ls -ltr starters.zip
unzip -: starters.zip -d starters
ls -ltr starters/
rm -v starters.zip
rm -rvf starters

def triple
  3 * yield
end

puts triple {5} # Predict output. 15

console.log("whoo!");
console.clear();
console.log("Cleared it.");

cd ../.. && tail -f yahoo.log



echo '<--spacer-->'
#####################################


tail -f yahoo.log
rm yahoo.log



echo '<--spacer-->'
#####################################


tail -f yahoo.log



echo '<--spacer-->'
#####################################


tail -f yahoo.log



echo '<--spacer-->'
#####################################



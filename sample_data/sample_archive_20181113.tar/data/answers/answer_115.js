const h = require("./helpers.js");

h.assert("Frege named the true", "Frege had it", "Frege blew");
h.assert(false, "Yay");
h.report("Whoa");

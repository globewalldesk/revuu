const h = require("./helpers.js");

h.assert(true === true, "True is true.", "True is not true.")
h.assert(true == 'true', "True is true.", "True is not 'true'.")


console.log(' ')
//////////////////////////////////////////////////////////////////////////


const h = require("./helpers.js");

h.assert(true, "True! True!")
h.assert(1 + 1 == 3);


console.log(' ')
//////////////////////////////////////////////////////////////////////////


var h = require('./helpers.js');

h.assert(1 + 1 == 2, "One and one are two!");
h.assert(typeof 'yo' == Number, null, "Yo isn't a number.")


console.log(' ')
//////////////////////////////////////////////////////////////////////////



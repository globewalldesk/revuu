echo no dirs
ls -dl */ */*/
mkdir -p foo/bar/
echo now two dirs
ls -dl */ */*/
rm -rf foo/
echo no dirs
ls -dl */ */*/

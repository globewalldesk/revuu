p Array.new(10)
p Array.new(10, true)
p Array.new(10) {|n| n}


puts ''
#####################################


puts Array.new(10).inspect
puts Array.new(10, true).inspect
puts Array.new(10) {|x| x }.inspect



puts ''
#####################################


arr1 = Array.new(10)
p arr1
arr2 = Array.new(10, true)
p arr2
arr3 = Array.new(10) {|x| x }
p arr3



puts ''
#####################################



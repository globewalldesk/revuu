const str = "Foo bar";
const n = 1;
const arr = [1, 2, 3];
const obj = {'a': 1, 'b': true, c() {console.log("foo bar!")}};
const bool = true;
console.log(typeof str);  // String
console.log(typeof n);    // Number
console.log(typeof arr);  // Object
console.log(typeof obj);  // Object
console.log(typeof bool); // Boolean




console.log(' ')
//////////////////////////////////////////////////////////////////////////



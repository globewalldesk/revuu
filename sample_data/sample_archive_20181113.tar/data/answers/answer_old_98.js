// Define SpaceShuttle
const SpaceShuttle = function(name, targetPlanet) {
  this.name = name;
  this.targetPlanet = targetPlanet;
}
const aphro = new SpaceShuttle('Aphrodite', 'Venus'); // call it
console.log(`Shuttle ${aphro.name} is going to ${aphro.targetPlanet}.`);

// Define SpaceShuttle2
const SpaceShuttle2 = function(name, targetPlanet) {
  return {
    name: name,
    targetPlanet: targetPlanet
  }
}
const ares = new SpaceShuttle2('Ares', 'Mars'); // call it
console.log(`Shuttle ${ares.name} is going to ${ares.targetPlanet}.`);

// Define SpaceShuttle3
function SpaceShuttle3 (name, targetPlanet) {return {name, targetPlanet}}
var zeus = new SpaceShuttle3('Zeus', 'Jupiter'); // call it
console.log(`Shuttle ${zeus.name} is going to ${zeus.targetPlanet}.`);

// Define SpaceShuttle4
class SpaceShuttle4 {
  constructor (name, targetPlanet) {return {name, targetPlanet}}
};
var cronos = new SpaceShuttle4('Cronos', 'Saturn'); // call it
console.log(`Shuttle ${cronos.name} is going to ${cronos.targetPlanet}.`);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


// Define SpaceShuttle:
const SpaceShuttle = function(foo, bar) {
  this.name = foo;
  this.targetPlanet = bar;
}
const venus = new SpaceShuttle('Aphrodite', 'Venus'); // call it
console.log(`Shuttle ${venus.name} is going to ${venus.targetPlanet}.`)

// Define SpaceShuttle2:
function SpaceShuttle2(name, planet) {
  return {
    name: name,
    targetPlanet: planet
  }
}
const ares = new SpaceShuttle2('Ares', 'Mars'); // call it
console.log(`Shuttle ${ares.name} is going to ${ares.targetPlanet}.`)

// Define SpaceShuttle3:
function SpaceShuttle3(name, targetPlanet) {return {name, targetPlanet}}
var zeus = new SpaceShuttle3('Zeus', 'Jupiter'); // call it
console.log(`Shuttle ${zeus.name} is going to ${zeus.targetPlanet}.`)

// Define SpaceShuttle4:
class SpaceShuttle4 {constructor(name, targetPlanet) {return {name, targetPlanet}}}
var merc = new SpaceShuttle4('Hermes', 'Mercury');
console.log(`Shuttle ${merc.name} is going to ${merc.targetPlanet}.`)



console.log(' ')
//////////////////////////////////////////////////////////////////////////



// SpaceShuttle:
var SpaceShuttle = function(name, targetPlanet) {return {name, targetPlanet}}

var ares = new SpaceShuttle("Ares", "Mars") // call it
console.log(`Shuttle ${ares.name} is going to ${ares.targetPlanet}.`)

// SpaceShuttle2:
class SpaceShuttle2 {
  constructor(targetPlanet, name) {
    this.name = name;
    this.targetPlanet = targetPlanet;
  }
}

const zeus = new SpaceShuttle2("Zeus", "Jupiter") // call it
console.log(`Shuttle ${zeus.name} is going to ${zeus.targetPlanet}.`)



console.log(' ')
//////////////////////////////////////////////////////////////////////////



freq = {}
10.times {|n| freq[n+1] = 0}
p freq
1_000_000.times do |x|
  n = rand(10) + 1
  break unless n.is_a? Integer
  freq[n] += 1
end
freq.sort_by {|k,v| k}.each {|a| puts "#{a[0]}: #{((a[1]/1_000_000.0)*100).round(3)}"}



puts ''
#####################################



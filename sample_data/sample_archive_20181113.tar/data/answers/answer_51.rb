az = [*('a'..'z')]
az.sort!{|x,y| x<=>y}
p az[0] # 'a'
az.sort!{|x,y| y<=>x}
p az[0] # 'z'
az.sort!
p az[0] # 'a'
p 'a' <=> 'z' # -1 because 'a' is lower-value than 'z'
arr = []
32.upto(126) do |n|; arr << n.chr; end;
p arr
puts "this should be the same:"
p arr.sort!
p 32.chr <=> 126.chr # -1 The lower-valued item goes first.

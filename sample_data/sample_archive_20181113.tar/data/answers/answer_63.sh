echo zipping starters.zip
zip -rq starters.zip "../starters"
ls -lh starters.zip
unzip -:q starters.zip -d starters
ls -d starters.zip starters/
ls -l starters/* | wc -l
rm -rf starters.zip 
rm -rf starters
ls -lh starters.zip starters/ starters/*
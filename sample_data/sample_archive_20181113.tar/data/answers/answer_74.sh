tail -f goog.log

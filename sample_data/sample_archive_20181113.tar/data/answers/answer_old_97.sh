history > history.txt
grep curl history.txt
grep grep history.txt
rm history.txt



echo '<--spacer-->'
#####################################



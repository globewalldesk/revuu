str = "hello world"
# Replace the following with something even shorter.
p str.split('')
p str.chars
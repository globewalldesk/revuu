var h = require('./helper_functions.js');

h.assert(true, "You have named the true!");
h.report("Reporting for duty!");
const two = function(x) {
  if (typeof x == 'number') {
    return (x * 2);
  } else if (typeof x == 'string') {
    return x += x;
  }
}

const antiCapitalize = function(str) {
  str = str.toUpperCase();
  stry = str.split('');
  stry[stry.length - 1] = stry[stry.length - 1].toLowerCase();
  return stry.join('');
}

const isPal = (x) => x == x.split('').reverse().join('');

const ary = [two, antiCapitalize, isPal];
ary.forEach((fun) => console.log(fun('five')));



console.log(' ')
//////////////////////////////////////////////////////////////////////////



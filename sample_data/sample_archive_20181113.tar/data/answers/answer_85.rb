n_stats = Array.new(11,0)
10_000_000.times do
  n = rand(10) + 1
  n_stats[n] += 1
  puts "Non-integer spotted: #{n}" unless n.class == Integer
end
1.upto(10) do |n|
  puts "#{n}: #{n_stats[n]} (#{((n_stats[n]/10_000_000.0)*100).round(3)}%)"
end

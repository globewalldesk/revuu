pwd
cd ..
pwd
cd ..
pwd
cd ..
pwd
cd -



echo '<--spacer-->'
#####################################


pwd
cd ..
pwd
cd ..
pwd
cd ..
pwd
cd -



echo '<--spacer-->'
#####################################



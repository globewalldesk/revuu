const plusTwo = (x) => x + 2
const timesTwo = (x) => x * 2
const divByTwo = (x) => x / 2
const fnArr = [plusTwo, timesTwo, divByTwo];
fnArr.forEach((fn) => console.log(fn(6)));
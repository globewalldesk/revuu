console.log([...Array(10).keys()]);
console.log([...new Array(10).keys()]);
console.log(Array.from(Array(10).keys()));

const a = 1;
const b = 2;
const c = 3; 
const arr = [a, b, c];
console.log(arr);
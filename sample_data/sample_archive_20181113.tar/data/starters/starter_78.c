#include <stdio.h>
int main() {
    float fahr;

    for (fahr = 0; fahr <= 300; fahr = fahr + 20)
        printf("%f\t%f\n", fahr, (5.0/9) * (fahr-32));
}
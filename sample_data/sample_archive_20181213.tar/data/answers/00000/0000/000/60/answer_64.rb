files = Dir["*"]
p files

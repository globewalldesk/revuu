arr = [1, 2, "foo", 3, 4, "bar", 5, 6, "baz"]

cube = Proc.new {|n| n.class == (Integer || Float) ? n**3 : n}
p arr.map(&cube)
puts cube.call(3)

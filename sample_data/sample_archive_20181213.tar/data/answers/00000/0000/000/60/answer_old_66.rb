arr = [1, 2, "foo", 3, 4, "bar", 5, 6, "baz"]

cuber = Proc.new {|x| x.class == Integer ? x**3 : x }

p arr.map(&cuber)

p cuber.call(10)



puts ''
#####################################


arr = [1, 2, "foo", 3, 4, "bar", 5, 6, "baz"]
cuber = Proc.new {|n| n.class == Integer ? n**3 : n}
p arr.map(&cuber)
p cuber.call(3) # 27



puts ''
#####################################


arr = [1, 2, "foo", 3, 4, "bar", 5, 6, "baz"]
cuber = Proc.new { |x| x.class == Integer ? x**3 : x }
p arr.map(&cuber)
# & alone is for Procs; that's how you pass procs as arguments.
# &:upcase is passes 'upcase' as a proc; but to do that, it first has to have
#     a reference to the upcase method, thus :upcase.
# :cuber is for a few built-in Ruby methods that already act as procs, like :+
#     You need ':' because allows us to pass the method as an object.
p cuber.call(10)



puts ''
#####################################


arr = [1, 2, "foo", 3, 4, "bar", 5, 6, "baz"]
cuber = Proc.new {|x| x.class == Integer ? x**3 : x}
p arr.map!(&cuber)
p cuber.call(3) #27



puts ''
#####################################


arr = [1, 2, "foo", 3, 4, "bar", 5, 6, "baz"]
cuber = Proc.new {|x| x.class == Integer ? x**3 : x}
p arr.collect(&cuber)
p cuber.call(4)



puts ''
#####################################


cube = Proc.new {|x| x.class == Integer ? x**3 : x}
arr = [1, 2, "foo", 3, 4, "bar", 5, 6, "baz"]
p arr.collect! &cube
p cube.call(4)



puts ''
#####################################



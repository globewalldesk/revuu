arr = *('a'..'g')
p arr.map(&:next)

numstrs = ['1', '2', '3', '4', '5', '6', '2']
puts numstrs.map(&:to_i).reduce(:+)

ls -lh
echo "Zipping..."
zip -q starters.zip -r ../../../../../starters
ls -lh
echo "Unzipping..."
unzip -q starters.zip -d starters
find starters/* -name starter_* | wc -l
ls -ls */ */*/
echo "Removing..."
rm -rf starters
rm starters.zip
ls -lh
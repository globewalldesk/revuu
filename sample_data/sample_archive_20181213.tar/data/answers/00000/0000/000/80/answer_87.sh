grep -i "rose" sonnets.txt | wc -l

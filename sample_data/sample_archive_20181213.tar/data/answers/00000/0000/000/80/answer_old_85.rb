nums = Hash.new {|hash,key| hash[key] = 1}
1000000.times {num = rand(10)+1; nums[num] += 1}
puts "oh no" if nums.keys.any? {|k| k.class != Integer}
nums.keys.sort.each {|k| percent = (nums[k]/10000.0).round(2); puts "#{k}: #{nums[k]} (#{percent}%)"}



puts ''
#####################################


numfreq = {}
1_000_000.times do
  n = rand(10) + 1
  numfreq[n] ? numfreq[n] += 1 : numfreq[n] = 1
end
1.upto(10) do |n|
  printf "%2d: %.4f\n", n, (numfreq[n]/100000.0).round(4)
end



puts ''
#####################################


n_stats = Array.new(11,0)
10_000_000.times do
  n = rand(10) + 1
  n_stats[n] += 1
  puts "Non-integer spotted: #{n}" unless n.class == Integer
end
1.upto(10) do |n|
  puts "#{n}: #{n_stats[n]} (#{((n_stats[n]/10_000_000.0)*100).round(3)}%)"
end



puts ''
#####################################


freq = {}
10.times {|n| freq[n+1] = 0}
p freq
1_000_000.times do |x|
  n = rand(10) + 1
  break unless n.is_a? Integer
  freq[n] += 1
end
freq.sort_by {|k,v| k}.each {|a| puts "#{a[0]}: #{((a[1]/1_000_000.0)*100).round(3)}"}



puts ''
#####################################



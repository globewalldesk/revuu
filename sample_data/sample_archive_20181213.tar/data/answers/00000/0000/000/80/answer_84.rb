require 'date'

p (DateTime.instance_methods & Time.instance_methods).count

grep -i 'rose' sonnets.txt | wc -l



echo '<--spacer-->'
#####################################


grep -i 'rose' "./sonnets.txt" | wc -l



echo '<--spacer-->'
#####################################


grep -i 'rose' sonnets.txt | wc -w


echo '<--spacer-->'
#####################################


grep -i rose sonnets.txt | wc



echo '<--spacer-->'
#####################################


grep -i rose sonnets.txt | wc



echo '<--spacer-->'
#####################################



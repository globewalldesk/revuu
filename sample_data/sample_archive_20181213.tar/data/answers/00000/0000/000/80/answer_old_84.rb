require 'date'
p (Time.instance_methods & DateTime.instance_methods).length



puts ''
#####################################


require 'date'
p (DateTime.new.methods & Time.new.methods).length



puts ''
#####################################


require 'date'
dt_methods = DateTime.new.methods
t_methods = Time.new.methods
p (t_methods & dt_methods).length



puts ''
#####################################


require 'date'
meths = DateTime.now.methods
p meths.count {|m| Time.new.respond_to? m}



puts ''
#####################################



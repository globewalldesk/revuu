require 'colorize'
puts "I am the first line.".colorize(:green)
puts "I am the second line.".colorize(background: :red)
puts "I am the third line.".colorize(:black).colorize(background: :white)

mountains = {
  'Mount Everest' => 29029,
  'K2' => 28251,
  'Kangchenjunga' => 28169,
  'Lhotse' => 27940,
  'Makalu' => 27838,
  'Cho Oyo' => 26864,
  'Dhaulagiri I' => 26795
}
def display_duples(darr, label)
  puts label
  header = sprintf("%-18s %s", "Mountain", "Height (ft.)")
  puts header
  puts '+' * header.length
  darr.each do |d|
    puts sprintf("%-18s %i", d[0], d[1])
  end
end

marr = mountains.sort_by do |k,v|
  k
end
display_duples(marr.reverse, "Sorted by name")
puts

marr = mountains.sort_by do |k,v|
  v
end
display_duples(marr, "Sorted by height")
puts

marr = mountains.sort
display_duples(marr, "Sorted by name")
puts

marr = mountains.sort do |x,y|
  x[1] <=> x[1]
end
display_duples(marr, "Sorted by height")

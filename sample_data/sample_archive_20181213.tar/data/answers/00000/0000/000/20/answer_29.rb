str = ''
'hxexlxlxox xwxoxrxlxdx'.split('').each_with_index do |c,i|
  str << c if i.even?
end
puts str

orig = 'hxexlxlxox xwxoxrxlxdx'
orig.length.times do |n|
  print orig[n] if n.even?
end
puts

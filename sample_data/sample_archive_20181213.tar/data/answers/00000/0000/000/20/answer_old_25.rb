dog_breeds = {
  'Lassie' => 'Collie',
  'Rex' => 'German Shepherd',
  'Bobo' => 'Poodle'
}
dog_breeds.default = 'mutt'
names = ['Lassie', 'Bobo', 'Sheba', 'Foxy', 'Rex']
names.each {|nm| puts "#{nm}: #{dog_breeds[nm]}"}



puts ''
#####################################


dog_breeds = {
  'Lassie' => 'Collie',
  'Rex' => 'German Shepherd',
  'Bobo' => 'Poodle'
}
dog_breeds.default = 'mutt';

['Lassie', 'Rex', 'Fifi', 'Rover', 'Bobo'].each do |nm|
  puts "#{nm}: #{dog_breeds[nm]}"
end



puts ''
#####################################


dog_breeds = {Lassie: 'Collie', Rex: 'German Shepherd', Bobo: 'Poodle'}
dog_breeds.default = 'mutt'
['Lassie', 'Fifi', 'Bobo', 'Rex', 'Happy'].each do |name|
  puts "#{name}: #{dog_breeds[name.to_sym]}"
end



puts ''
#####################################


dog_breeds = {
  'Fido' => 'poodle',
  'Rover' => 'golden retriever',
  'Lucky' => 'black lab'
}
dog_breeds.default = 'mutt'
%w[Fido Funny Rover Lucky Bozo].each do |name|
  puts "#{name}: #{dog_breeds[name]}"
end


puts ''
#####################################


dog_breeds = {Lassie:  'collie', Rex: 'German shepherd', Fido: 'cocker spaniel'}
dog_breeds.default = 'mutt'
names = [:Lassie, :Peaches, :Rex, :Old_Yeller, :Fido]
names.each do |name|
  puts "#{name.to_s}: #{dog_breeds[name]}"
end



#####################################



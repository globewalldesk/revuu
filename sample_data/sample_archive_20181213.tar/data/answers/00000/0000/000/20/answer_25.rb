dog_breeds = {
  'Lassie' => 'Collie',
  'Rex' => 'German Shepherd',
  'Bobo' => 'Poodle'
}
names = ['Lassie', 'Bobo', 'King', 'Rover', 'Rex']
dog_breeds.default = 'mutt'

names.each do |name|
  puts "#{name}: #{dog_breeds[name]}"
end

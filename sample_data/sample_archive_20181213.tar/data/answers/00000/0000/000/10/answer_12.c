#include <stdio.h>
int main() {
    float fahr, celsius;
    int lower, upper, step;
    lower = -20;    /* lower limit of temperature table */
    upper = 120;  /* upper limit */
    step = 10;    /* step size */

    fahr = lower;
    printf("F\t\tC\n");
    for (fahr = -20; fahr <= 120; fahr = fahr+10) {
        celsius = (5.0/9) * (fahr-32);
        printf("%f\t%f\n", fahr, celsius);
    }
}

arr = *(1..5)         # inclusive
for n in arr do
  print "#{n*3} "
end

puts

arr2 = (1...6).to_a   # exclusive
p arr2

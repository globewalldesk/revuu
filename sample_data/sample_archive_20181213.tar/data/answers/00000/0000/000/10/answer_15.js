['99', '2.3', '23a', 'xyz'].forEach(function(x) {
  const addition = isNaN(x) ? 'is not' : 'is';
  console.log(`${x} ${addition} numeric.`);
});

[99, 2.3, '2.3a', 'xyz'].forEach(function(x) {
  const intg = Number.isInteger(x) ? 'is' : 'is not';
  console.log(`${x} ${intg} an integer.`);
});

a = nil
until a == 'q'
  print "Enter a numeric sort of string for fun! "
  a = gets.chomp
  puts a.to_i.to_s == a ? "#{a} is an integer." : "'#{a}' ain't an integer."
end

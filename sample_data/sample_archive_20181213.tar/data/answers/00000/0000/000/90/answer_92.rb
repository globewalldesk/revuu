arr = File.readlines(__FILE__)
puts arr[-1].inspect
puts 'This is a file I am enjoying reading, to be honest.'
puts 'And now you have come to the end of it. Too bad!'

ping yahoo.com > yahoo.log


echo '<--spacer-->'
#####################################



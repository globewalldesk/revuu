class Animal
  attr_reader :name, :living

  def initialize(name)
    @name = name
    @living = true
  end

  def makes_noise
    puts "#{@name} growls!"
  end
end

class Lion < Animal
  def eats
    puts "#{@name} eats!"
  end
end

leo = Animal.new('Leo')
leo.makes_noise

lambert = Lion.new('Lambert')
lambert.makes_noise
lambert.eats
puts "Is #{lambert.name} living? #{lambert.living.to_s.capitalize}."
p lambert.instance_variables

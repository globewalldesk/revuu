puts "Acme Products".center(75)
puts "The top products for you!".center(75, '=+')



puts ''
#####################################


acme = 'Acme Products'
tag = 'The top products for you!'
puts acme.center(75)
puts tag.center(75, '+=')


puts ''
#####################################



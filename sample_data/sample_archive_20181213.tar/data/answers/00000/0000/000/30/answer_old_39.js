const obby = {one: 1, two: 2};
Object.freeze(obby);
console.log(obby.one);
obby.one = 'one';
console.log(obby.one);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


'use strict';
let obj = {foo: 1, bar: 2};
console.log(`Before any change, obj.foo = ${obj.foo}`)
obj.foo = 10000;
console.log(`After first change attempt, obj.foo = ${obj.foo}`)
Object.freeze(obj);
try {
  obj.foo = 100;
} catch (err) {
  console.log("Oops: " + err)
}
console.log(`After second change attempt, obj.foo = ${obj.foo}`)



console.log(' ')
//////////////////////////////////////////////////////////////////////////


const eddie = {name: 'Edward William Sanger', age: 7, sex: 'male'};
console.log("Name: " + eddie.name);
console.log("Age: " + eddie.age);
console.log("Sex: " + eddie.sex);
console.log("Making change...")
eddie.age = 8;
Object.freeze(eddie);
console.log("Name: " + eddie.name);
console.log("Age: " + eddie.age);
console.log("Sex: " + eddie.sex);
console.log("Attempting another change...");
eddie.age = 9;
console.log("Results:");
console.log("Name: " + eddie.name);
console.log("Age: " + eddie.age);
console.log("Sex: " + eddie.sex);



console.log(' ')
//////////////////////////////////////////////////////////////////////////


const BUILDING = {
  name: 'Empire State Building', location: 'New York City'
}
Object.freeze(BUILDING);
console.log(BUILDING.location);
BUILDING.location = 'Palookaville';
console.log(BUILDING.location);


console.log(' ')
//////////////////////////////////////////////////////////////////////////


const FUN_OBJECT = {
  name: 'George',
  favorite_activity: 'being held and cuddled by the abominable snowman'
}
console.log(FUN_OBJECT.name + "'s favorite activity is " + FUN_OBJECT.favorite_activity + ".");
Object.freeze(FUN_OBJECT);
FUN_OBJECT.favorite_activity = 'bowling';
console.log(FUN_OBJECT.name + "'s favorite activity is still " + FUN_OBJECT.favorite_activity + ".");



//////////////////////////////////////////////////////////////////////////



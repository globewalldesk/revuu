size = File.stat("../../../../../../revuu.rb").size
puts size.to_s + " bytes"
puts (size/1024).to_s + " KB"
puts (size/1024.0).to_s + " KB"
puts ((size/1024.0).round(2)).to_s + " KB"
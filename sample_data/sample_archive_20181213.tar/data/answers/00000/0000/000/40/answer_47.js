const tenEmpty = Array(10);
console.log(tenEmpty);
tenEmpty[3] = 'three';
console.log(tenEmpty);
const onetoten = [...Array(10).keys()];
console.log(onetoten);
const onetotenNew = [...new Array(10).keys()];
console.log(onetotenNew);
const nudderOnetoten = Array.from(Array(10).keys())
console.log(nudderOnetoten);

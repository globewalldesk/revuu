const loveMyFunction = () => "This is really nice function, isn't it?";
console.log(loveMyFunction());


console.log(' ')
//////////////////////////////////////////////////////////////////////////


const LoveMyFunction = () => {
  return "This is really nice function, isn't it?"
}
console.log(LoveMyFunction());


//////////////////////////////////////////////////////////////////////////



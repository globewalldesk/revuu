class Integer
  def factorial_minus_triangle
    [*(1..self)].reduce(:*) - [*(1..self)].reduce(:+)
  end
end
puts 5.respond_to? :factorial_minus_triangle
1.upto(10).each {|n| print n.factorial_minus_triangle.to_s + " "}

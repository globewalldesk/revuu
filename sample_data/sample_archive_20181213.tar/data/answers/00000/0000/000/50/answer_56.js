const Faves = { fruit: 'apple', music: 'Irish trad', prog_lang: 'Ruby' };
const {fruit, music, prog_lang} = Faves;
console.log(`My favorite fruit is ${fruit}; music, ${music};`);
console.log(`programming language, ${prog_lang}.`);

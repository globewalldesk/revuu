p Array.new(10)
p Array.new(10, true)
p Array.new(10) {|x| rand(10)+1}

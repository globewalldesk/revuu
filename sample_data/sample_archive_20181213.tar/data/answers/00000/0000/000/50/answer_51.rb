az = *('a'..'z')
az.sort!{ |x,y| x <=> y }
puts az[0] # a
az.sort!{ |y,x| x <=> y }
puts az[0] # z
puts 'a' <=> 'b' # -1 because 'a' is lower valued than 'b'
32.upto(126) do |n|
  print "#{n.chr} "
end
puts
puts 32.chr <=> 126.chr # -1 because ditto.
# lower-valued items go first.

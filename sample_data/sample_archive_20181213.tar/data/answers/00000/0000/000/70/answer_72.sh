cd ../../../../..
echo ls -rtl ----------------------
ls -rtl
echo ls -hrtl ---------------------
ls -hrtl
echo ls -hrtl *.json --------------
ls -hrtl *.json

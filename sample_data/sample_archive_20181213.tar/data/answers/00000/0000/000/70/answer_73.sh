echo "hello, world" > foo.txt
cat foo.txt > bar.txt
cat foo.txt
cat bar.txt
ls -lh
rm foo.txt bar.txt
ls -lh
pwd

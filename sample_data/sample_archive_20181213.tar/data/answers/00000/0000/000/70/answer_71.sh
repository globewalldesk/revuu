echo "From fairest creatures we desire increase," > shake.txt
echo "That thereby beauty's rose might never die," >> shake.txt
echo "Here's the file\n===="
cat shake.txt
echo "===="
ls -lh
echo "deleting..."
rm shake.txt
echo "is it gone?"
ls -lh

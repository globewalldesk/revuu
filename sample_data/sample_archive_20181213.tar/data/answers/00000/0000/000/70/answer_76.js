const createCar = (make, model, year) => {return { make, model, year }};
console.log(createCar('Toyota', 'Highlander', 2018)); // returns a proper object

ls -rtl ..*/
ls -ratl ..
ls -hartl ..
ls -hartl ../*.json


echo '<--spacer-->'
#####################################


echo ''
ls -lrt ..
echo ''
ls -lart ..
echo ''
ls -larth ..
echo ''
ls -larth ../*.json
echo ''
ls -larthR ../../*/*.rb



echo '<--spacer-->'
#####################################


echo "reversed time with details:"
ls -rtl ..
echo "same with hidden folders"
ls -artl ..
echo "with KB"
ls -hartl ..
echo "same, just .rb"
ls -hartl ../*.json



echo '<--spacer-->'
#####################################


ls -rtl
ls -ratl
ls -hartl
ls *.java
ls !(answer_*)



echo '<--spacer-->'
#####################################



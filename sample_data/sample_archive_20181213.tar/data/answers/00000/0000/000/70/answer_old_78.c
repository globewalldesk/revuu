#include <stdio.h>
#define MIN   0
#define MAX   300
#define STEP  20

int main() {
    float fahr;

    for (fahr = MIN; fahr <= MAX; fahr = fahr + STEP)
        printf("%f\t%f\n", fahr, (5.0/9) * (fahr-32));
}

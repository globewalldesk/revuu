arr = ['eeeee!', 'bb', 'aaa', 'the eagle has landed', 'hello', 'zed', 'goll dang']

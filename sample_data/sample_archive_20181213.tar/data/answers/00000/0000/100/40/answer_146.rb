system("psql tqsql")

ARR = [1, 2, 3]
p ARR
ARR[0] = 4
ARR[1] = 5
ARR[2] = 6
p ARR
ARR.freeze
begin
  p ARR << 7
rescue RuntimeError => err
  puts "#{err.class}: rescued error '#{err.message}'"
ensure
  puts "ARR = #{ARR.inspect}"
end

let randy = 1;
do {
  randy = Math.random();
  console.log(randy);
} while (randy < 0.95)

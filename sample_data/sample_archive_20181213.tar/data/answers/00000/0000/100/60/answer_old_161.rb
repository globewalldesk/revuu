module Bipedal
  def two_legs(name)
    puts "#{name} has exactly two limbs used for walking."
  end
end

class Person
  def two_legs(name)
    puts "#{name} has two human legs."
  end
end

class Boy < Person
  include Bipedal
  attr_accessor :name
  def initialize(name)
    @name = name
  end

  # (2) Add a basic #two_legs method calling super. What will be printed?
  def two_legs
    method(:two_legs).super_method.super_method.call(@name)
  end

  # (3) Add clever #two_legs method for Boy that will call the *other* version.
end

# (1a) Make a Boy & call two_legs on it.
henry = Boy.new('Henry')
henry.two_legs # still two limbs version



puts ''
#####################################


module Bipedal
  def two_legs(name)
    "#{name} has exactly two limbs used for walking."
  end
end

class Person
  attr_accessor :name
  def initialize(name)
    @name = name
  end
  def two_legs(name)
    "#{name} has two human legs."
  end
end

class Boy < Person
  include Bipedal

  def two_legs
    super(@name)
#    method(:two_legs).super_method.super_method.call(@name)
  end
end

henry = Boy.new('Henry')
puts henry.two_legs



puts ''
#####################################


module Bipedal
  def two_legs(name)
    puts "#{name} has exactly two limbs used for walking."
  end
end

class Person
  def two_legs(name)
    puts "#{name} has two human legs."
  end
end

class Boy < Person
  include Bipedal
  # One possibility
  # Bipedal.send(:remove_method, :two_legs)
  # Another possibility
  # Boy.superclass.instance_method(:two_legs).bind(self).call(@name)

  attr_accessor :name
  def initialize(name)
    @name = name
  end

  def two_legs
    method(:two_legs).super_method.super_method.call(@name)
  end
end

eddie = Boy.new('Eddie')
eddie.two_legs



puts ''
#####################################



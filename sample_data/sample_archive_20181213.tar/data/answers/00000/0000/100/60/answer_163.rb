def encode(str)
  # Iterate over each char of string; get the next char code; add 1;
  # return the string from that code.
  str.each_char.map{|c| (c.ord+1).chr}.join
end

def decode(str)
  str.each_char.map{|c| (c.ord-1).chr}.join
end

str = "The quick brown fox jumped over the lazy dog."
puts str
encoded_str = encode(str)
puts encoded_str
decoded_str = decode(encoded_str)
puts decoded_str

arr = [1, 4, 'four', 6, 2, 7, 11, 'foo?']

arr = arr.map(function(x) {
  switch(x) {
  case 1:
    return 'one';
    break;
  case 2:
    return 'two';
    break;
  case 3:
    return 'three';
    break;
  case 4:
  case 5:
  case 6:
  case 7:
    return 'more'
    break;
  default:
    return 'Foo!';
  };
});
console.log(arr);



console.log(' ')
//////////////////////////////////////////////////////////////////////////



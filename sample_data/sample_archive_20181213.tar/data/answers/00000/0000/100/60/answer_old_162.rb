ARR = [1, 2, 3]
p ARR
ARR[0] = 4
ARR[1] = 5
ARR[2] = 6
p ARR
ARR.freeze
begin
  ARR << 7
rescue RuntimeError => err
  puts "#{err.class}: #{err.message}"
ensure
  p ARR
end



puts ''
#####################################


ARR = [1, 2, 3]
p ARR
ARR[0] = 4
ARR[1] = 5
ARR[2] = 6
p ARR
ARR.freeze
puts ARR.frozen?
begin
  ARR[0] = 7
rescue StandardError => e
  puts "Didn't work: #{e.class} reported '#{e}'"
ensure
  p ARR
end



puts ''
#####################################



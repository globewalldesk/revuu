myf   =  1.9
yourf = -1.9

p myf.to_i    # 1
p yourf.to_i  # -1

puts sprintf("%f", myf);      # 1.900
puts sprintf("%f", yourf);    # -1.900
puts sprintf("%i", myf);      # 1  (might round to 2)
puts sprintf("%i", yourf);    # -1 (might round to -2)
puts sprintf("%.0f", myf);    # 2  (defo rounds)
puts sprintf("%.0f", yourf);  # -2 (ditto)

myf   =  1.9
yourf = -1.9
p myf.to_i    # 1 (chops at decimal; doesn't round)
p yourf.to_i  # -1

puts sprintf("%f %f", myf, yourf)   # 1.9000 -1.9000
puts sprintf("%i %i", myf, yourf)   # 1 -1
puts sprintf("%.0f %.0f", myf, yourf) # 2 -2 (Rounds!)



puts ''
#####################################


myf   =  1.9
yourf = -1.9
puts myf
puts yourf
puts myf.to_i # 1
puts yourf.to_i # -1
puts sprintf("%f and %f", myf, yourf)   # 1.9000 and -1.9000
puts sprintf("%i and %i", myf, yourf)   # 1 and -1
puts sprintf("%1.0f and %1.0f", myf, yourf)   # 2 and -2



puts ''
#####################################



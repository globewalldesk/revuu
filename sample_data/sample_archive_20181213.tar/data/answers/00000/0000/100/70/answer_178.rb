employees = %w{Jones Smith Abbott Collins Howard Iverson Zemba Evans O'Toole
               Miller Sanger Davidson Reed Johnson Franke Culbertson Collins
               Duck Edwards Forsythe Williams Sharon}
c_to_e = employees.find_all{|x| x.between?('C', 'E')}
p c_to_e.sort

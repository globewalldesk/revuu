const george = {
  name: 'George Washington',
  accomplishments: ['first prez', 'first general'],
  print() {
    for (i in this) {
      console.log(`${i}: ${this[i]}`);
    }
  }
};
george.print();

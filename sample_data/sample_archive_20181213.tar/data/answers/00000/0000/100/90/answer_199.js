function Rectangle(height, width) { return { height, width,
  calcArea() {
    return (height * width);
  }
}}
const rect = new Rectangle(6, 4);
console.log(rect.calcArea());

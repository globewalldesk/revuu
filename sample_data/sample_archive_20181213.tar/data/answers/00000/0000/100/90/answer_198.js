const Prez = function(name, accomplishments) {return {
  name,
  accomplishments,
  print() {
    for (i in this) {
      console.log(`${i}: ${this[i]}`);
    }
  }}
};
george = new Prez("George Washington", ['this', 'that']);
george.print();

trump = new Prez("Donald Trump", ['pissing people off', 'deregulating']);
trump.print();

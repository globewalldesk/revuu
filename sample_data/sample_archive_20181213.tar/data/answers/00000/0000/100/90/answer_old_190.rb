arr = %w(foo bar baz) # Also called a percent string.
p arr



puts ''
#####################################



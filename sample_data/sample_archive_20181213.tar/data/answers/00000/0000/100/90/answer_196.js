let johnDoe = {};
johnDoe.firstName = 'John';
johnDoe.lastName = 'Doe';
johnDoe.greet = function() {
  console.log("Hi, I'm " + this.firstName + " " + this.lastName + ".")
}
for (i in johnDoe) {
  console.log(`${i}: ${johnDoe[i]}`);
}

console.log(johnDoe);

let usa = 'u.s.a.';
let poet = 'E.E. Cummings';
let title = 'the big sleep';
usa = usa.toUpperCase();
poet = poet.toLowerCase();
title = title.split(" ")
             .map((w) => w[0].toUpperCase() + w.slice(1))
             .join(" ");
console.log(usa);
console.log(poet);
console.log(title);

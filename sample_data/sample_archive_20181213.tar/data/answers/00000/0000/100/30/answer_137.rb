arr = [0, 1, 2, 3, 4]
p arr.first
p arr.last

nums = []
10.times {nums << rand(10) + 1} # Get ten random integers.
p nums.count(&:odd?)

arr = [1, '1', 2, '2', 3, '3']
p arr.collect(&:next)
p arr.select {|n| n.class == Integer}

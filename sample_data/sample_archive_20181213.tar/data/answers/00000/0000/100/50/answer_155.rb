def get_ten
  nums = []
  10.times {nums << rand(10) + 1} # Get ten random integers.
  nums
end

class Array
  def average
    self.reduce(:+) / self.count.to_f
  end
end

counts = []
10.times {counts << get_ten.count{|n| n.odd?}}
p counts.average

counts = []
100.times {counts << get_ten.count{|n| n.odd?}}
p counts.average

counts = []
1000.times {counts << get_ten.count{|n| n.odd?}}
p counts.average

counts = []
10000.times {counts << get_ten.count{|n| n.odd?}}
p counts.average

counts = []
1_000_000.times {counts << get_ten.count{|n| n.odd?}}
p counts.average

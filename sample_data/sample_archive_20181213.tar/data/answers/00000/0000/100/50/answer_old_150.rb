# Three arrays made different ways...
a = *('a'..'z')
b = ('a'..'z').to_a
c = Array('a'..'z')
p a, b, c



puts ''
#####################################


# Three arrays made different ways...
a = *('a'..'z')
b = ('a'..'z').to_a
c = Array('a'..'z')
p a, b, c



puts ''
#####################################


# Three arrays made different ways...
a = *('a'..'z')
b = ('a'..'z').to_a
c = Array('a'..'z')
p a, b, c



puts ''
#####################################


a = *('a'..'z')
b = Array('a'..'z')
c = ('a'..'z').to_a
p a, b, c



puts ''
#####################################



# Three arrays made different ways...
a = *('a'..'z')
b = Array('a'..'z')
c = ('a'..'z').to_a
p a, b, c

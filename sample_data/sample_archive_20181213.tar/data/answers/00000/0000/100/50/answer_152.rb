h = {:jn2938=>2945, :ko2887=>9855, :zr7002=>1563, :dd6985=>6851, :ss5916=>8100,
     :sl4516=>8410, :ne1544=>2925, :lr6471=>588, :oi5989=>5353, :kn7646=>4380,
     :ep8806=>7307, :gq7330=>7541, :wb0276=>8196, :ol2354=>3402, :by2966=>1876,
     :xp0812=>3371, :kx3788=>4601, :hz7977=>4932, :qx1781=>1030, :fb6662=>5559}

[:as3452, :nd6435, :ol2354].each do |k|
  puts "#{k} is in hash: " + h.has_key?(k).to_s
end
puts

[7253, 8100, 236].each do |v|
  puts "#{v} is a hash value: " + h.has_value?(v).to_s
end
puts

h.merge!({foo: :bar})
p h.keys
puts

p h.values
puts

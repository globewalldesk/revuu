class Person
  attr_accessor :name, :age, :nationality

  def initialize(name, age:, nationality: 'American')
    @name = name
    @age = age
    @nationality = nationality
  end

  def profile
    puts "Name: " + @name
    puts "Age: " + @age
    puts "Nationality: " + @nationality
  end
end

# Create...
mama = Person.new('Rita', age:'not telling', nationality:'none of your business')
papa = Person.new('Larry', age:'50')

# Call...
mama.profile
papa.profile

lengths = Hash.new do |hash,key|
  key.class == String ? (hash[key] = key.length) : (hash[key.to_s] = key.length)
end

lengths[:cool] = true
lengths[1] = 'one'
lengths['abc'] = 3
lengths['foobar']
lengths['Jehosaphat']
p lengths

foods = Hash.new do |hash,food|
  hash[food[0].downcase] = []
end

foods['b'] << 'banana'
foods['b'] << 'butter'
foods['d'] << 'dill pickle'
foods['d'] << 'donut'
p foods

foods = Hash.new do |hash,food|
  key = food[0].to_s.downcase
  key == food ? hash[key] = [] : hash[key] << food
end
foods['a']
foods['banana']
foods['butter']
foods['dill pickle']
foods['donut']
foods['McMuffin']
p foods

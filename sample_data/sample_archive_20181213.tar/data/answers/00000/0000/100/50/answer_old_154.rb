class Person
  attr_accessor :name, :age, :nationality

  def initialize(name, sex:, nationality: 'American')
    @name = name
    @sex = sex
    @nationality = nationality
  end

  def profile
    puts "Name: " + @name
    puts "Sex: " + @sex
    puts "Nationality: " + @nationality
  end
end

# Create...
fred = Person.new("Fred Flintstone", sex: 'male', nationality: "Venusian")

# Call...
fred.profile



puts ''
#####################################


class Person
  attr_accessor :name, :sex, :nationality

  def initialize(name, sex:, nationality: 'American')
    @name = name
    @sex = sex
    @nationality = nationality
  end

  def profile
    puts "Name: " + @name
    puts "Sex: " + @sex
    puts "Nationality: " + @nationality
  end
end

larry = Person.new('Sanger', sex: 'male', nationality: "Martian")
larry.profile



puts ''
#####################################



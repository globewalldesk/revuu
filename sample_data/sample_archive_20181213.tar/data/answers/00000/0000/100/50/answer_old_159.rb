arr = [1, 'a', 2, 'b', 3, 'c']
p arr.collect(&:next)
p arr.select {|n| n.class == Integer}



puts ''
#####################################



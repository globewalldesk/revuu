#include <stdio.h>

int main() {
    int c, first;
    while ((c = getchar()) != EOF) {
        /* Print a newline after the user's input. */
        if(first == 0) {
            printf("\n");
            first = 1;
        }
        if (c == '\t' || c == ' ' )
            c = '\n';
        putchar(c);
    }
}

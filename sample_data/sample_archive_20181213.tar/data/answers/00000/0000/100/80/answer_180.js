const Bob = {
  name: 'Bob',
  occupation: 'bobbing for apples',
  salary: 'ten bob a week'
}

console.log(`${Bob['name']}'s name is ${Bob['name']}. His main job is`);
console.log(`${Bob['occupation']}, which he does for ${Bob['salary']}.`);

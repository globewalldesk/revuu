function funkShun() {
  console.log("I can't actually access your new property easily...");
}
funkShun.meaning = 42;
funkShun();
console.log(funkShun.meaning);

function foo() {return 'foo'};
function say_foo() {return 'foobar'};
function conditional_foo() {
  return Math.floor(Math.random()*10+1) > 5 ? 'foo' : 'bar'};
 const farr = [foo, say_foo, conditional_foo];
 farr.forEach(f => console.log(f()));

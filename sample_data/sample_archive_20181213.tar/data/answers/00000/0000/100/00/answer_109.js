const str = "Foo bar";
const n = 1;
const arr = [1, 2, 3];
const obj = {'a': 1, 'b': true, c() {console.log("foo bar!")}};
const bool = true;
console.log(typeof str); // string
console.log(typeof n); // integer (maybe number, but I think integer--nope, number)
console.log(typeof arr); // object
console.log(typeof obj); // object
console.log(typeof bool); // boolean
console.log(typeof obj.c); // function

// add one here
const ans = typeof str;
console.log(ans); // string

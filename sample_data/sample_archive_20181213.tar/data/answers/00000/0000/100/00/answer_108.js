function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function sleepy() {
  console.log("Yoo!!");
  await sleep(2000);
  console.clear();
  console.log("Cleared!");
}
sleepy();

let str = "abcde";
let strnum = "abc123";
let numstr = "123abc";
let fltstr = "9.85x";
let flt = "9.85";
let flt2 = 9.99;
let int = 1;

// Part A: convert to float
console.log(parseFloat(str));     // NaN
console.log(parseFloat(strnum));  // NaN
console.log(parseFloat(numstr));  // 123
console.log(parseFloat(fltstr));  // 9.85
console.log(parseFloat(flt));     // 9.85
console.log(parseFloat(flt2));    // 9.99
console.log(parseFloat(int));     // 1

// Part B: convert to integer
console.log(parseInt(str));     // NaN
console.log(parseInt(strnum));  // NaN
console.log(parseInt(numstr));  // 123
console.log(parseInt(fltstr));  // 9
console.log(parseInt(flt));     // 9
console.log(parseInt(flt2));    // 9
console.log(parseInt(int));     // 1



console.log(' ')
//////////////////////////////////////////////////////////////////////////



require 'minitest/autorun'
require './app'
include DatePrettifier

class AppTest < Minitest::Test
end

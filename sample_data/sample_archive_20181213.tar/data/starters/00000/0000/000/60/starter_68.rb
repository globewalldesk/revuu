def triple
  3 * # something
end

p triple {} # Predict output.

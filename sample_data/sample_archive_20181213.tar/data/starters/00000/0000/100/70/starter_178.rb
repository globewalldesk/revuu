employees = %w{Jones Smith Abbott Collins Howard Iverson Zemba Evans O'Toole
               Miller Sanger Davidson Reed Johnson Franke Culbertson Collins
               Duck Edwards Forsythe Williams Sharon}

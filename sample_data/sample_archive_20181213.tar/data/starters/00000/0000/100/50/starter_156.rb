str1 = "Revuu is the best!"
str2 = "Version 3.3"
#include <stdio.h>

/* count digits, white space, others  */
int main() {
    int c, i, nwhite, ndigits, nother;

    nwhite = nother = ndigits = 0;
    for (i = 0; i < 10; ++i) {
        ndigit[i] = 0;
    }
    while ((c = getchar()) != EOF)
        if(c >= '0' && c <= '9') {
            ++ndigit[c-'0'];
            ++ndigits;
        } else if(c == ' ' || c == '\n' || c == '\t') {
            ++nwhite;
        } else {
            ++nother;
        }
    printf("\n==================================\ndigits = ");
    for(i = 0; i < 10; ++i)
        printf(" %d", ndigit[i]);
    printf(", total count = %d, white space = %d, other = %d\n",
        ndigits, nwhite, nother);
}

let num = '123';
let abc = 'abc';
const george = {
  name: 'George Washington',
  accomplishments: ['first prez', 'first general'],
  print() {
    console.log(this);
  }
};
module Bipedal
  def two_legs(name)
    puts "#{name} has exactly two limbs used for walking."
  end
end

class Person
  def two_legs(name)
    puts "#{name} has two human legs."
  end
end

class Boy < Person
  include Bipedal
  attr_accessor :name
  def initialize(name)
    @name = name
  end

  # (2) Add a basic #two_legs method calling super. What will be printed?
  # (3) Add clever #two_legs method for Boy that will call the *other* version.
end

# (1a) Make a Boy & call two_legs on it.
# (1b) What will be printed?

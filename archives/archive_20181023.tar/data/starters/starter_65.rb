str = "hello world"
p str.split('')
arr1 = Array.new(10)
p arr1
arr2 = Array.new(10, true)
p arr2
arr3 = Array.new(10) {|x| x }
p arr3



puts ''
#####################################



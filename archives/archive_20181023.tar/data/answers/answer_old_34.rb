puts(File.stat('../revuu.rb').size)


puts ''
#####################################


puts File.stat("../revuu.rb").size


#####################################



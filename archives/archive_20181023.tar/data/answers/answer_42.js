const factorial = (arr) =>
  arr.reduce((x,y) => x * y)

arr = [1, 2, 3, 4, 5];
console.log(factorial(arr));
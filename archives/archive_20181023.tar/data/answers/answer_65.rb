str = "hello world"
p str.split('')
p str.chars
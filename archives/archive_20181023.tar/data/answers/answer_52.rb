puts Array.new(10).inspect
puts Array.new(10, true).inspect
puts Array.new(10) {|x| x }.inspect

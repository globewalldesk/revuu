friends = ['Jack', 'Jill', 'Sam']

def yo(???)
  ???.each { |friend| puts "???, #{friend}!" }
end

arr = ['a', 'b', 'c', 'd']


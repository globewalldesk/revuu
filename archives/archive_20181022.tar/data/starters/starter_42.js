const factorial = function(arr) {
  return arr.reduce(function(x,y) {
    return x * y
  });
}

arr = [5, 4, 3, 2, 1]

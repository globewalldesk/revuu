const hello = (x='John Doe') => console.log("Hello, " + x + ".");
hello("George Washington");
hello();
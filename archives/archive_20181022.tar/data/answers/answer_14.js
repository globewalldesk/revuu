console.log("Band-aid\u00AE 98.6\u00B0");
console.log("Band-aid\xAE 98.6\xB0");
console.log("\u0068\u0069");
console.log("\x68\x69");

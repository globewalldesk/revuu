s = 'hxexlxlxox xwxoxrxlxdx'
s.length.times do |count|
  print s[count] if count.even?
end
puts ''

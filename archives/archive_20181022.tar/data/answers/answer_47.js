console.log([...Array(10).keys()])

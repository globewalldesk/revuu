puts (File.stat("../revuu.rb").size)
puts (File.stat("../revuu.rb").size / 1024.0)
puts (File.stat("../revuu.rb").size / 1024.0).round(2)
